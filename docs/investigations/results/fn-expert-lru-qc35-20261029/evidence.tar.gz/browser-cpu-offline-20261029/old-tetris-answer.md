Here's a complete, self-contained Tetris. Save it as an `.html` file and open it in any modern browser.

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TETRIS — Block Drop</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root{
    --bg:#070b16; --panel:#0e1526; --panel2:#0a1120;
    --line:rgba(120,150,210,.14); --line2:rgba(120,150,210,.28);
    --text:#e9eefb; --muted:#8593b4; --muted2:#5f6d90;
    --cyan:#22d3ee; --blue:#3b82f6; --amber:#fbbf24; --green:#34d399; --red:#f43f5e;
    --mono:'Chakra Petch',ui-monospace,monospace;
    --sans:'Space Grotesk',system-ui,sans-serif;
  }
  *{box-sizing:border-box}
  html,body{margin:0}
  body{
    font-family:var(--sans); color:var(--text); background:var(--bg);
    min-height:100vh; overflow-x:hidden; -webkit-font-smoothing:antialiased;
  }

  /* ---------- ambient background ---------- */
  .bg{position:fixed; inset:0; z-index:-2; overflow:hidden;
    background:
      radial-gradient(1200px 820px at 12% -12%, rgba(34,211,238,.12), transparent 60%),
      radial-gradient(1000px 720px at 102% 112%, rgba(251,191,36,.10), transparent 55%),
      radial-gradient(900px 900px at 92% -8%, rgba(59,130,246,.10), transparent 60%),
      linear-gradient(180deg,#0a1122,#070b16 55%,#05080f);
  }
  .bg::before{content:''; position:absolute; inset:-2px;
    background-image:
      linear-gradient(rgba(120,150,210,.05) 1px,transparent 1px),
      linear-gradient(90deg,rgba(120,150,210,.05) 1px,transparent 1px);
    background-size:46px 46px;
    -webkit-mask-image:radial-gradient(circle at 50% 38%,#000,transparent 82%);
            mask-image:radial-gradient(circle at 50% 38%,#000,transparent 82%);
    animation:drift 42s linear infinite;
  }
  @keyframes drift{to{background-position:46px 46px,46px 46px}}
  .bg::after{content:''; position:absolute; inset:0;
    background:radial-gradient(120% 90% at 50% 40%,transparent 55%,rgba(0,0,0,.55));}
  .floaters{position:fixed; inset:0; z-index:-1; pointer-events:none; overflow:hidden}
  .floaters span{position:absolute; width:16px; height:16px; border-radius:3px;
    opacity:.10; animation:floatUp linear infinite}
  @keyframes floatUp{
    0%{transform:translateY(20px) rotate(0); opacity:0}
    12%{opacity:.12} 88%{opacity:.12}
    100%{transform:translateY(-112vh) rotate(220deg); opacity:0}
  }

  /* ---------- layout ---------- */
  .wrap{max-width:1180px; margin:0 auto; padding:26px 20px 40px}
  .topbar{display:flex; justify-content:space-between; align-items:flex-end;
    gap:20px; flex-wrap:wrap; margin-bottom:22px}
  .brand{display:flex; align-items:center; gap:16px}
  .logo{width:46px; height:46px; flex:none; filter:drop-shadow(0 6px 14px rgba(0,0,0,.5))}
  .logo rect{transform-box:fill-box; transform-origin:center; animation:pop 3.4s ease-in-out infinite}
  .logo rect:nth-child(2){animation-delay:.15s} .logo rect:nth-child(3){animation-delay:.3s}
  .logo rect:nth-child(4){animation-delay:.45s} .logo rect:nth-child(5){animation-delay:.6s}
  .logo rect:nth-child(6){animation-delay:.75s} .logo rect:nth-child(7){animation-delay:.9s}
  .logo rect:nth-child(8){animation-delay:1.05s} .logo rect:nth-child(9){animation-delay:1.2s}
  @keyframes pop{0%,100%{transform:scale(1)}50%{transform:scale(1.14)}}
  .brand h1{font-family:var(--mono); font-weight:700; font-size:clamp(30px,5vw,46px);
    letter-spacing:.14em; margin:0; line-height:.95;
    background:linear-gradient(180deg,#fff,#a9c4ff); -webkit-background-clip:text;
    background-clip:text; color:transparent}
  .brand p{margin:5px 0 0; color:var(--muted); font-size:13px; letter-spacing:.02em}
  .topbar .meta{display:flex; gap:10px; flex-wrap:wrap}
  .chip{display:flex; flex-direction:column; gap:2px; padding:8px 14px; border-radius:12px;
    background:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,.01));
    border:1px solid var(--line)}
  .chip span{font-size:10px; letter-spacing:.18em; text-transform:uppercase; color:var(--muted2)}
  .chip b{font-family:var(--mono); font-size:18px; font-weight:700; color:var(--text)}

  .game{display:grid; grid-template-columns:236px minmax(0,1fr) 236px; gap:22px;
    align-items:start; justify-content:center}
  .col{display:flex; flex-direction:column; gap:16px}
  .col.center{align-items:center}

  .panel{background:linear-gradient(180deg,var(--panel),var(--panel2));
    border:1px solid var(--line); border-radius:16px; padding:16px;
    box-shadow:0 18px 40px -24px rgba(0,0,0,.8), inset 0 1px 0 rgba(255,255,255,.04)}
  .panel h2{margin:0 0 12px; font-family:var(--mono); font-size:11px; font-weight:600;
    letter-spacing:.22em; text-transform:uppercase; color:var(--muted);
    display:flex; align-items:center; gap:8px}
  .panel h2::before{content:''; width:6px; height:6px; border-radius:2px; background:var(--cyan);
    box-shadow:0 0 10px var(--cyan)}

  /* score */
  .score .big{font-family:var(--mono); font-weight:700; font-size:clamp(34px,4vw,46px);
    line-height:1; letter-spacing:.02em; color:#fff; text-shadow:0 0 22px rgba(34,211,238,.35)}
  .score .big.bump{animation:bump .3s ease}
  @keyframes bump{0%{transform:scale(1)}40%{transform:scale(1.12)}100%{transform:scale(1)}}
  .score .sub{margin-top:6px; color:var(--muted); font-size:12px; letter-spacing:.04em}
  .score .sub b{color:var(--amber); font-family:var(--mono)}

  /* stats */
  .stats{display:grid; grid-template-columns:1fr 1fr; gap:10px}
  .stat{background:rgba(255,255,255,.02); border:1px solid var(--line); border-radius:12px; padding:10px 12px}
  .stat span{display:block; font-size:10px; letter-spacing:.16em; text-transform:uppercase; color:var(--muted2)}
  .stat b{font-family:var(--mono); font-size:22px; font-weight:700}
  .stat.wide{grid-column:1/-1}

  /* next queue */
  .next .slots{display:flex; flex-direction:column; gap:10px}
  .slot{display:flex; align-items:center; gap:12px; padding:8px; border-radius:12px;
    background:rgba(255,255,255,.02); border:1px solid var(--line)}
  .slot canvas{width:74px; height:52px; flex:none}
  .slot .tag{font-family:var(--mono); font-size:11px; letter-spacing:.14em; color:var(--muted)}
  .slot:first-child{border-color:var(--line2); background:rgba(34,211,238,.06)}
  .slot:first-child .tag{color:var(--cyan)}

  /* board */
  .board-wrap{position:relative; width:min(300px,86vw); aspect-ratio:10/20;
    border-radius:16px; padding:10px;
    background:linear-gradient(180deg,#0c1424,#080d1a);
    border:1px solid var(--line2);
    box-shadow:0 30px 70px -30px rgba(0,0,0,.9), inset 0 0 0 1px rgba(255,255,255,.03),
      0 0 60px -20px rgba(34,211,238,.25)}
  .board-wrap::before{content:''; position:absolute; inset:10px; border-radius:8px;
    box-shadow:inset 0 0 40px rgba(0,0,0,.6); pointer-events:none; z-index:2}
  #board{display:block; width:100%; height:100%; border-radius:8px}
  .board-wrap.shake{animation:shake .32s cubic-bezier(.36,.07,.19,.97)}
  @keyframes shake{10%{transform:translate(-3px,2px)}30%{transform:translate(4px,-2px)}
    50%{transform:translate(-4px,1px)}70%{transform:translate(3px,2px)}100%{transform:translate(0,0)}}

  .overlay{position:absolute; inset:10px; border-radius:8px; z-index:3;
    display:flex; flex-direction:column; align-items:center; justify-content:center; gap:14px;
    text-align:center; padding:20px;
    background:radial-gradient(120% 120% at 50% 30%,rgba(8,12,22,.72),rgba(5,8,15,.94));
    backdrop-filter:blur(3px); -webkit-backdrop-filter:blur(3px);
    opacity:0; visibility:hidden; transition:opacity .3s ease, visibility .3s}
  .overlay.show{opacity:1; visibility:visible}
  .overlay h3{margin:0; font-family:var(--mono); font-weight:700; letter-spacing:.14em;
    font-size:clamp(22px,4vw,30px)}
  .overlay p{margin:0; color:var(--muted); font-size:13px; max-width:220px; line-height:1.5}
  .overlay .ov-score{font-family:var(--mono); font-size:15px; color:var(--muted)}
  .overlay .ov-score b{color:#fff; font-size:26px; display:block; margin-top:2px}
  .overlay .ov-score.newbest b{color:var(--amber)}
  .ov-btn{margin-top:4px}

  /* controls */
  .controls{display:flex; flex-direction:column; gap:8px}
  .ctrl{display:flex; align-items:center; justify-content:space-between; gap:10px;
    padding:8px 10px; border-radius:10px; background:rgba(255,255,255,.02);
    border:1px solid var(--line); transition:.18s}
  .ctrl:hover{background:rgba(34,211,238,.06); border-color:var(--line2); transform:translateX(2px)}
  .ctrl .k{display:flex; gap:5px}
  .ctrl .lbl{font-size:12px; color:var(--muted)}
  kbd{font-family:var(--mono); font-size:11px; font-weight:600; color:var(--text);
    background:linear-gradient(180deg,#1a2438,#111a2c); border:1px solid var(--line2);
    border-bottom-width:2px; border-radius:6px; padding:3px 7px; min-width:22px; text-align:center}

  /* buttons */
  .btn{font-family:var(--mono); font-weight:600; letter-spacing:.06em; cursor:pointer;
    color:var(--text); background:linear-gradient(180deg,#182338,#0f1728);
    border:1px solid var(--line2); border-radius:12px; padding:11px 16px; font-size:13px;
    transition:transform .12s ease, box-shadow .2s, background .2s, border-color .2s}
  .btn:hover{transform:translateY(-2px); border-color:var(--cyan);
    box-shadow:0 10px 24px -12px rgba(34,211,238,.6)}
  .btn:active{transform:translateY(0)}
  .btn.primary{background:linear-gradient(180deg,#22d3ee,#0ea5b7); color:#04121a; border-color:transparent;
    box-shadow:0 12px 26px -12px rgba(34,211,238,.7)}
  .btn.primary:hover{box-shadow:0 16px 34px -12px rgba(34,211,238,.85)}
  .btn.danger:hover{border-color:var(--red); box-shadow:0 10px 24px -12px rgba(244,63,94,.6)}
  .btn-row{display:flex; gap:10px}
  .btn-row .btn{flex:1}
  .ov-btn{padding:12px 22px; font-size:14px}

  /* touch */
  .touch{display:none; margin-top:16px; width:min(300px,86vw)}
  .touch .row{display:flex; gap:10px; margin-bottom:10px}
  .touch button{flex:1; font-family:var(--mono); font-size:18px; padding:16px 0; border-radius:12px;
    background:linear-gradient(180deg,#182338,#0f1728); border:1px solid var(--line2); color:var(--text);
    cursor:pointer; touch-action:manipulation; user-select:none}
  .touch button:active{background:rgba(34,211,238,.18); border-color:var(--cyan)}
  .touch .wide{flex:2}

  .reveal{opacity:0; transform:translateY(16px); animation:reveal .7s cubic-bezier(.2,.7,.2,1) forwards}
  @keyframes reveal{to{opacity:1; transform:none}}

  @media (max-width:920px){
    .game{grid-template-columns:1fr; justify-items:center}
    .col{width:min(360px,92vw)}
    .col.center{order:-1}
    .stats{grid-template-columns:repeat(4,1fr)}
    .next .slots{flex-direction:row; flex-wrap:wrap; justify-content:center}
    .slot{flex:1 1 100px}
    .touch{display:block}
  }
  @media (max-width:520px){ .stats{grid-template-columns:1fr 1fr} }
</style>
</head>
<body>
  <div class="bg"></div>
  <div class="floaters" id="floaters"></div>

  <div class="wrap">
    <header class="topbar reveal">
      <div class="brand">
        <svg class="logo" viewBox="0 0 46 46" aria-hidden="true">
          <rect x="2"  y="2"  width="13" height="13" rx="3" fill="#22d3ee"/>
          <rect x="17" y="2"  width="13" height="13" rx="3" fill="#3b82f6"/>
          <rect x="32" y="2"  width="13" height="13" rx="3" fill="#fbbf24"/>
          <rect x="2"  y="17" width="13" height="13" rx="3" fill="#34d399"/>
          <rect x="17" y="17" width="13" height="13" rx="3" fill="#f43f5e"/>
          <rect x="32" y="17" width="13" height="13" rx="3" fill="#a855f7"/>
          <rect x="2"  y="32" width="13" height="13" rx="3" fill="#fb923c"/>
          <rect x="17" y="32" width="13" height="13" rx="3" fill="#22d3ee"/>
          <rect x="32" y="32" width="13" height="13" rx="3" fill="#3b82f6"/>
        </svg>
        <div>
          <h1>TETRIS</h1>
          <p>Stack, rotate, clear — chase the perfect line.</p>
        </div>
      </div>
      <div class="meta">
        <div class="chip"><span>Best</span><b id="bestChip">0</b></div>
        <div class="chip"><span>Level</span><b id="levelChip">1</b></div>
        <div class="chip"><span>Lines</span><b id="linesChip">0</b></div>
      </div>
    </header>

    <main class="game">
      <!-- LEFT -->
      <aside class="col left">
        <section class="panel score reveal" style="animation-delay:.05s">
          <h2>Score</h2>
          <div class="big" id="score">0</div>
          <div class="sub">Best <b id="best">0</b></div>
        </section>
        <section class="panel reveal" style="animation-delay:.1s">
          <h2>Stats</h2>
          <div class="stats">
            <div class="stat"><span>Level</span><b id="level">1</b></div>
            <div class="stat"><span>Lines</span><b id="lines">0</b></div>
            <div class="stat"><span>Time</span><b id="time">0:00</b></div>
            <div class="stat"><span>Clears</span><b id="clears">0</b></div>
            <div class="stat wide"><span>Last clear</span><b id="lastclear" style="font-size:16px">—</b></div>
          </div>
        </section>
        <section class="panel reveal" style="animation-delay:.15s">
          <h2>Controls</h2>
          <div class="controls">
            <div class="ctrl"><span class="lbl">Move</span><span class="k"><kbd>←</kbd><kbd>→</kbd></span></div>
            <div class="ctrl"><span class="lbl">Soft drop</span><span class="k"><kbd>↓</kbd></span></div>
            <div class="ctrl"><span class="lbl">Hard drop</span><span class="k"><kbd>Space</kbd></span></div>
            <div class="ctrl"><span class="lbl">Rotate</span><span class="k"><kbd>↑</kbd><kbd>X</kbd></span></div>
            <div class="ctrl"><span class="lbl">Rotate CCW</span><span class="k"><kbd>Z</kbd></span></div>
            <div class="ctrl"><span class="lbl">Hold</span><span class="k"><kbd>C</kbd></span></div>
            <div class="ctrl"><span class="lbl">Pause</span><span class="k"><kbd>P</kbd></span></div>
          </div>
        </section>
      </aside>

      <!-- CENTER -->
      <section class="col center">
        <div class="board-wrap reveal" id="boardWrap" style="animation-delay:.08s">
          <canvas id="board"></canvas>
          <div class="overlay" id="overlay">
            <h3 id="ovTitle">TETRIS</h3>
            <p id="ovText">Press Enter or tap to start. Clear lines to score.</p>
            <div class="ov-score" id="ovScore" hidden></div>
            <button class="btn primary ov-btn" id="ovBtn">Start Game</button>
          </div>
        </div>
        <div class="touch" id="touch">
          <div class="row">
            <button data-act="left">◀</button>
            <button data-act="rotate">⟳</button>
            <button data-act="right">▶</button>
          </div>
          <div class="row">
            <button data-act="hold">HOLD</button>
            <button data-act="soft" class="wide">SOFT ▼</button>
            <button data-act="hard">DROP</button>
          </div>
        </div>
      </section>

      <!-- RIGHT -->
      <aside class="col right">
        <section class="panel next reveal" style="animation-delay:.05s">
          <h2>Next</h2>
          <div class="slots" id="nextSlots"></div>
        </section>
        <section class="panel reveal" style="animation-delay:.1s">
          <h2>Hold</h2>
          <canvas id="hold" style="width:100%; height:70px; display:block"></canvas>
        </section>
        <section class="panel reveal" style="animation-delay:.15s">
          <h2>Game</h2>
          <div class="btn-row">
            <button class="btn" id="pauseBtn">Pause</button>
            <button class="btn danger" id="restartBtn">Restart</button>
          </div>
        </section>
      </aside>
    </main>
  </div>

<script>
"use strict";
/* ============================================================
   TETRIS — single-file implementation
   ============================================================ */

/* ---------- constants ---------- */
const COLS = 10, ROWS = 20, CELL = 30;
const LOCK_DELAY = 500, MAX_LOCK_RESETS = 15;
const DAS = 150, ARR = 40, SOFT_DROP_MS = 45, CLEAR_MS = 380;
const NEXT_COUNT = 5;

const COLORS = {
  I:'#22d3ee', O:'#fbbf24', T:'#a855f7', S:'#34d399',
  Z:'#f43f5e', J:'#3b82f6', L:'#fb923c'
};
const CLEAR_NAMES = ['','Single','Double','Triple','TETRIS!'];

/* Tetromino shapes per rotation state (0..3). Each is a list of [x,y] cells. */
const SHAPES = {
  I:[[[0,1],[1,1],[2,1],[3,1]],[[2,0],[2,1],[2,2],[2,3]],[[0,2],[1,2],[2,2],[3,2]],[[1,0],[1,1],[1,2],[1,3]]],
  O:[[[1,0],[2,0],[1,1],[2,1]],[[1,0],[2,0],[1,1],[2,1]],[[1,0],[2,0],[1,1],[2,1]],[[1,0],[2,0],[1,1],[2,1]]],
  T:[[[1,0],[0,1],[1,1],[2,1]],[[1,0],[1,1],[2,1],[1,2]],[[0,1],[1,1],[2,1],[1,2]],[[1,0],[0,1],[1,1],[1,2]]],
  S:[[[1,0],[2,0],[0,1],[1,1]],[[1,0],[1,1],[2,1],[2,2]],[[1,1],[2,1],[0,2],[1,2]],[[0,0],[0,1],[1,1],[1,2]]],
  Z:[[[0,0],[1,0],[1,1],[2,1]],[[2,0],[1,1],[2,1],[1,2]],[[0,1],[1,1],[1,2],[2,2]],[[1,0],[0,1],[1,1],[0,2]]],
  J:[[[0,0],[0,1],[1,1],[2,1]],[[1,0],[2,0],[1,1],[1,2]],[[0,1],[1,1],[2,1],[2,2]],[[1,0],[1,1],[0,2],[1,2]]],
  L:[[[2,0],[0,1],[1,1],[2,1]],[[1,0],[1,1],[1,2],[2,2]],[[0,1],[1,1],[2,1],[0,2]],[[0,0],[1,0],[1,1],[1,2]]]
};
/* SRS wall-kick tables (offsets tried in order). */
const KICKS_JLSTZ = {
  '0>1':[[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],
  '1>0':[[0,0],[1,0],[1,1],[0,-2],[1,-2]],
  '1>2':[[0,0],[1,0],[1,1],[0,-2],[1,-2]],
  '2>1':[[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],
  '2>3':[[0,0],[1,0],[1,-1],[0,2],[1,2]],
  '3>2':[[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
  '3>0':[[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
  '0>3':[[0,0],[1,0],[1,-1],[0,2],[1,2]]
};
const KICKS_I = {
  '0>1':[[0,0],[-2,0],[1,0],[-2,1],[1,-2]],
  '1>0':[[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
  '1>2':[[0,0],[-1,0],[2,0],[-1,-2],[2,1]],
  '2>1':[[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
  '2>3':[[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
  '3>2':[[0,0],[-2,0],[1,0],[-2,1],[1,-2]],
  '3>0':[[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
  '0>3':[[0,0],[-1,0],[2,0],[-1,-2],[2,1]]
};

/* ---------- DOM ---------- */
const boardCanvas = document.getElementById('board');
const ctx = boardCanvas.getContext('2d');
const holdCanvas = document.getElementById('hold');
const holdCtx = holdCanvas.getContext('2d');
const nextCanvases = [];
const nextSlots = document.getElementById('nextSlots');
for (let i=0;i<NEXT_COUNT;i++){
  const slot = document.createElement('div'); slot.className='slot';
  const c = document.createElement('canvas');
  const tag = document.createElement('span'); tag.className='tag';
  tag.textContent = i===0 ? 'NEXT' : '·'+i;
  slot.append(c, tag); nextSlots.append(slot);
  nextCanvases.push(c);
}
const el = {
  score:document.getElementById('score'), best:document.getElementById('best'),
  bestChip:document.getElementById('bestChip'), level:document.getElementById('level'),
  levelChip:document.getElementById('levelChip'), lines:document.getElementById('lines'),
  linesChip:document.getElementById('linesChip'), time:document.getElementById('time'),
  clears:document.getElementById('clears'), lastclear:document.getElementById('lastclear'),
  overlay:document.getElementById('overlay'), ovTitle:document.getElementById('ovTitle'),
  ovText:document.getElementById('ovText'), ovScore:document.getElementById('ovScore'),
  ovBtn:document.getElementById('ovBtn'), pauseBtn:document.getElementById('pauseBtn'),
  restartBtn:document.getElementById('restartBtn'), boardWrap:document.getElementById('boardWrap')
};

/* ---------- state ---------- */
let grid, current, holdType, canHold, bag, queue;
let score, lines, level, clears, best;
let state = 'start';           // start | playing | paused | clearing | gameover
let dropInterval, dropTimer, lockTimer, lockResets, lockActive;
let clearingRows = [], clearTimer = 0, clearFlash = 0;
let particles = [];
let elapsed = 0, lastTime = 0;
let keys = {left:false,right:false,down:false};
let dasTimer = 0, dasDir = 0, arrTimer = 0;

/* ---------- helpers ---------- */
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
function hexToRgb(h){h=h.replace('#','');return{r:parseInt(h.slice(0,2),16),g:parseInt(h.slice(2,4),16),b:parseInt(h.slice(4,6),16)};}
function shade(hex,amt){const c=hexToRgb(hex);const f=amt<0?0:255;const p=Math.abs(amt);
  return `rgb(${Math.round(c.r+(f-c.r)*p)},${Math.round(c.g+(f-c.g)*p)},${Math.round(c.b+(f-c.b)*p)})`;}
function roundRect(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);
  c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}

/* ---------- canvas sizing ---------- */
function setupCanvas(canvas, cssW, cssH){
  const dpr = Math.min(window.devicePixelRatio||1, 2);
  canvas.width = Math.round(cssW*dpr); canvas.height = Math.round(cssH*dpr);
  const c = canvas.getContext('2d'); c.setTransform(dpr,0,0,dpr,0,0);
  canvas._cssW = cssW; canvas._cssH = cssH;
}
function resize(){
  const rect = boardCanvas.getBoundingClientRect();
  setupCanvas(boardCanvas, rect.width, rect.height);
  const hr = holdCanvas.getBoundingClientRect();
  setupCanvas(holdCanvas, hr.width, hr.height);
  nextCanvases.forEach(c=>{const r=c.getBoundingClientRect(); setupCanvas(c, r.width, r.height);});
}

/* ---------- 7-bag randomizer ---------- */
function refillBag(){
  const types = ['I','O','T','S','Z','J','L'];
  for (let i=types.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[types[i],types[j]]=[types[j],types[i]];}
  bag.push(...types);
}
function nextType(){ if(bag.length<7) refillBag(); return bag.shift(); }
function ensureQueue(){ while(queue.length < NEXT_COUNT+1) queue.push(nextType()); }

/* ---------- piece ---------- */
function makePiece(type){
  return { type, rot:0, x:3, y:(type==='I'?-1:0) };
}
function cellsOf(p){ return SHAPES[p.type][p.rot]; }
function collides(p, dx, dy, rot){
  const cells = SHAPES[p.type][rot];
  for (const [cx,cy] of cells){
    const x = p.x+dx+cx, y = p.y+dy+cy;
    if (x<0 || x>=COLS || y>=ROWS) return true;
    if (y>=0 && grid[y][x]) return true;
  }
  return false;
}
function spawn(){
  ensureQueue();
  const type = queue.shift(); ensureQueue();
  current = makePiece(type);
  lockTimer = 0; lockResets = 0; lockActive = false;
  if (collides(current,0,0,current.rot)) gameOver();
  renderNext();
}
function move(dx){
  if (state!=='playing') return;
  if (!collides(current,dx,0,current.rot)){ current.x+=dx; resetLock(); }
}
function rotate(dir){
  if (state!=='playing') return;
  const from = current.rot, to = (from+dir+4)%4;
  const table = current.type==='I' ? KICKS_I : KICKS_JLSTZ;
  const kicks = table[from+'>'+to];
  for (const [kx,ky] of kicks){
    if (!collides(current,kx,-ky,to)){ current.x+=kx; current.y-=ky; current.rot=to; resetLock(); return; }
  }
}
function softDrop(){
  if (state!=='playing') return;
  if (!collides(current,0,1,current.rot)){ current.y++; score+=1; dropTimer=0; resetLock(); }
  else { lockTimer = LOCK_DELAY; lockActive = true; }
}
function hardDrop(){
  if (state!=='playing') return;
  let d=0; while(!collides(current,0,d+1,current.rot)) d++;
  current.y += d; score += d*2; lockPiece();
}
function resetLock(){
  if (lockActive && lockResets < MAX_LOCK_RESETS){ lockTimer = 0; lockResets++; }
}
function lockPiece(){
  for (const [cx,cy] of cellsOf(current)){
    const x=current.x+cx, y=current.y+cy;
    if (y>=0 && y<ROWS && x>=0 && x<COLS) grid[y][x]=current.type;
  }
  current = null;
  const full=[]; for(let r=0;r<ROWS;r++) if(grid[r].every(c=>c)) full.push(r);
  if (full.length){ startClear(full); }
  else { spawn(); }
}
function startClear(rows){
  clearingRows = rows; clearTimer = CLEAR_MS; clearFlash = 0; state='clearing';
  const n = rows.length;
  score += [0,100,300,500,800][n] * level;
  lines += n; clears++;
  level = Math.floor(lines/10)+1;
  dropInterval = Math.max(70, 1000 - (level-1)*80);
  el.lastclear.textContent = CLEAR_NAMES[n];
  if (n===4) shake();
  spawnParticles(rows);
  updateHUD();
}
function finishClear(){
  for (const r of clearingRows){ grid.splice(r,1); grid.unshift(new Array(COLS).fill(null)); }
  clearingRows = []; state='playing'; spawn();
}
function hold(){
  if (state!=='playing' || !canHold) return;
  const cur = current.type;
  if (holdType){ const t=holdType; holdType=cur; current=makePiece(t); }
  else { holdType=cur; spawn(); }
  canHold=false; lockTimer=0; lockResets=0; lockActive=false;
  renderHold();
}
function gameOver(){
  state='gameover';
  if (score>best){ best=score; localStorage.setItem('tetris.best', best); }
  updateHUD();
  showOverlay('GAME OVER', 'The stack reached the top.', true);
}

/* ---------- particles ---------- */
function spawnParticles(rows){
  const colors = rows.map(r=>{
    const set=new Set(grid[r].filter(Boolean));
    return set.size? [...set][Math.floor(Math.random()*set.size)] : '#fff';
  });
  for (const r of rows){
    for (let x=0;x<COLS;x++){
      const col = COLORS[grid[r][x]] || '#fff';
      for (let k=0;k<2;k++){
        particles.push({
          x:(x+0.5)*CELL, y:(r+0.5)*CELL,
          vx:(Math.random()-0.5)*160, vy:-Math.random()*180-40,
          life:1, size:CELL*(0.18+Math.random()*0.22), color:col
        });
      }
    }
  }
  if (particles.length>420) particles.splice(0, particles.length-420);
}
function updateParticles(dt){
  for (let i=particles.length-1;i>=0;i--){
    const p=particles[i];
    p.vy += 620*dt; p.x += p.vx*dt; p.y += p.vy*dt; p.life -= dt*1.6;
    if (p.life<=0) particles.splice(i,1);
  }
}
function drawParticles(){
  for (const p of particles){
    ctx.globalAlpha = Math.max(0,p.life);
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x-p.size/2, p.y-p.size/2, p.size, p.size);
  }
  ctx.globalAlpha = 1;
}

/* ---------- drawing ---------- */
function drawBlock(c, x, y, size, color, opts={}){
  const pad = Math.max(1, size*0.06);
  const bx=x+pad, by=y+pad, bw=size-pad*2, bh=size-pad*2, r=Math.max(2,size*0.16);
  const g=c.createLinearGradient(bx,by,bx,by+bh);
  g.addColorStop(0, shade(color,0.30)); g.addColorStop(0.5,color); g.addColorStop(1, shade(color,-0.22));
  c.fillStyle=g; roundRect(c,bx,by,bw,bh,r); c.fill();
  c.fillStyle='rgba(255,255,255,0.22)'; roundRect(c,bx+1,by+1,bw-2,bh*0.34,r*0.8); c.fill();
  c.strokeStyle='rgba(0,0,0,0.35)'; c.lineWidth=1; roundRect(c,bx+0.5,by+0.5,bw-1,bh-1,r); c.stroke();
  if (opts.glow){ c.save(); c.shadowColor=color; c.shadowBlur=size*0.5; c.fillStyle=color;
    roundRect(c,bx,by,bw,bh,r); c.fill(); c.restore(); }
  if (opts.alpha!=null){ c.globalAlpha=opts.alpha; c.fillStyle='#fff'; roundRect(c,bx,by,bw,bh,r); c.fill(); c.globalAlpha=1; }
}
function drawGrid(){
  const w=boardCanvas._cssW, h=boardCanvas._cssH;
  ctx.clearRect(0,0,w,h);
  ctx.fillStyle='#0a1120'; ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='rgba(120,150,210,0.06)'; ctx.lineWidth=1;
  for (let x=1;x<COLS;x++){ ctx.beginPath(); ctx.moveTo(x*CELL+.5,0); ctx.lineTo(x*CELL+.5,h); ctx.stroke(); }
  for (let y=1;y<ROWS;y++){ ctx.beginPath(); ctx.moveTo(0,y*CELL+.5); ctx.lineTo(w,y*CELL+.5); ctx.stroke(); }
}
function drawGhost(){
  if (!current) return;
  let d=0; while(!collides(current,0,d+1,current.rot)) d++;
  const color=COLORS[current.type];
  for (const [cx,cy] of cellsOf(current)){
    const x=(current.x+cx)*CELL, y=(current.y+d+cy)*CELL;
    ctx.save(); ctx.globalAlpha=0.16; ctx.fillStyle=color;
    roundRect(ctx,x+3,y+3,CELL-6,CELL-6,4); ctx.fill(); ctx.restore();
    ctx.save(); ctx.globalAlpha=0.5; ctx.strokeStyle=color; ctx.lineWidth=1.5;
    roundRect(ctx,x+3,y+3,CELL-6,CELL-6,4); ctx.stroke(); ctx.restore();
  }
}
function drawPiece(){
  if (!current) return;
  const color=COLORS[current.type];
  for (const [cx,cy] of cellsOf(current)){
    const x=(current.x+cx)*CELL, y=(current.y+cy)*CELL;
    if (y>=0) drawBlock(ctx,x,y,CELL,color,{glow:true});
  }
}
function drawClearing(){
  const flash = 0.35 + 0.45*Math.abs(Math.sin(clearFlash*14));
  for (const r of clearingRows){
    ctx.fillStyle=`rgba(255,255,255,${flash})`;
    ctx.fillRect(0, r*CELL, COLS*CELL, CELL);
  }
}
function drawBoard(){
  drawGrid();
  for (let r=0;r<ROWS;r++) for (let c=0;c<COLS;c++){
    const t=grid[r][c]; if(!t) continue;
    if (clearingRows.includes(r)) continue;
    drawBlock(ctx, c*CELL, r*CELL, CELL, COLORS[t]);
  }
  if (state==='playing'){ drawGhost(); drawPiece(); }
  if (state==='clearing') drawClearing();
  drawParticles();
}
function drawMini(c, type){
  const w=c._cssW, h=c._cssH; c.clearRect(0,0,w,h);
  if (!type) return;
  const cells=SHAPES[type][0];
  let minX=9,maxX=-9,minY=9,maxY=-9;
  for (const [x,y] of cells){ minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y); }
  const cols=maxX-minX+1, rows=maxY-minY+1;
  const s=Math.min((w-10)/cols,(h-10)/rows,20);
  const ox=(w-cols*s)/2 - minX*s, oy=(h-rows*s)/2 - minY*s;
  for (const [x,y] of cells) drawBlock(c, ox+x*s, oy+y*s, s, COLORS[type]);
}
function renderNext(){ for (let i=0;i<NEXT_COUNT;i++) drawMini(nextCanvases[i], queue[i]); }
function renderHold(){ drawMini(holdCanvas, holdType); }

/* ---------- HUD ---------- */
function fmtTime(ms){ const s=Math.floor(ms/1000); return Math.floor(s/60)+':'+String(s%60).padStart(2,'0'); }
function updateHUD(){
  el.score.textContent = score.toLocaleString();
  el.best.textContent = best.toLocaleString();
  el.bestChip.textContent = best.toLocaleString();
  el.level.textContent = level; el.levelChip.textContent = level;
  el.lines.textContent = lines; el.linesChip.textContent = lines;
  el.clears.textContent = clears;
  el.time.textContent = fmtTime(elapsed);
}
function bumpScore(){ el.score.classList.remove('bump'); void el.score.offsetWidth; el.score.classList.add('bump'); }
function shake(){ el.boardWrap.classList.remove('shake'); void el.boardWrap.offsetWidth; el.boardWrap.classList.add('shake'); }

/* ---------- overlay ---------- */
function showOverlay(title, text, showScore){
  el.ovTitle.textContent = title; el.ovText.textContent = text;
  if (showScore){
    const isBest = score>=best && score>0;
    el.ovScore.hidden=false;
    el.ovScore.className = 'ov-score' + (isBest?' newbest':'');
    el.ovScore.innerHTML = (isBest?'New best! ':'') + 'Score<b>'+score.toLocaleString()+'</b>';
  } else el.ovScore.hidden=true;
  el.ovBtn.textContent = state==='gameover' ? 'Play Again' : 'Start Game';
  el.overlay.classList.add('show');
}
function hideOverlay(){ el.overlay.classList.remove('show'); }

/* ---------- flow ---------- */
function reset(){
  grid = Array.from({length:ROWS},()=>new Array(COLS).fill(null));
  bag=[]; queue=[]; ensureQueue();
  current=null; holdType=null; canHold=true;
  score=0; lines=0; level=1; clears=0; elapsed=0;
  dropInterval=1000; dropTimer=0; lockTimer=0; lockResets=0; lockActive=false;
  clearingRows=[]; clearTimer=0; clearFlash=0; particles=[];
  keys={left:false,right:false,down:false}; dasTimer=0; dasDir=0; arrTimer=0;
  renderHold(); renderNext(); updateHUD();
}
function startGame(){ reset(); state='playing'; hideOverlay(); spawn(); }
function togglePause(){
  if (state==='playing'){ state='paused'; showOverlay('PAUSED','Take a breath. Press P to resume.',false); }
  else if (state==='paused'){ state='playing'; hideOverlay(); }
}
function primaryAction(){
  if (state==='start' || state==='gameover') startGame();
  else if (state==='paused') togglePause();
}

/* ---------- input ---------- */
const KEYMAP = {
  ArrowLeft:'left', ArrowRight:'right', ArrowDown:'down', ArrowUp:'rotate',
  KeyX:'rotate', KeyZ:'rotateCCW', KeyC:'hold', KeyP:'pause', Space:'hard', Enter:'primary'
};
window.addEventListener('keydown', e=>{
  const a = KEYMAP[e.code]; if (!a) return;
  e.preventDefault();
  if (a==='primary'){ primaryAction(); return; }
  if (a==='pause'){ togglePause(); return; }
  if (state!=='playing') return;
  if (a==='left'){ keys.left=true; dasDir=-1; dasTimer=0; arrTimer=0; move(-1); }
  else if (a==='right'){ keys.right=true; dasDir=1; dasTimer=0; arrTimer=0; move(1); }
  else if (a==='down'){ keys.down=true; }
  else if (a==='rotate'){ rotate(1); }
  else if (a==='rotateCCW'){ rotate(-1); }
  else if (a==='hold'){ hold(); }
  else if (a==='hard'){ hardDrop(); }
});
window.addEventListener('keyup', e=>{
  const a = KEYMAP[e.code]; if (!a) return;
  if (a==='left'){ keys.left=false; if(dasDir===-1) dasDir=keys.right?1:0; }
  else if (a==='right'){ keys.right=false; if(dasDir===1) dasDir=keys.left?-1:0; }
  else if (a==='down'){ keys.down=false; }
});
el.ovBtn.addEventListener('click', primaryAction);
el.pauseBtn.addEventListener('click', togglePause);
el.restartBtn.addEventListener('click', ()=>{ if(state==='playing'||state==='paused') startGame(); else primaryAction(); });

/* touch buttons */
document.getElementById('touch').addEventListener('pointerdown', e=>{
  const act = e.target.dataset.act; if (!act) return; e.preventDefault();
  if (state!=='playing'){ if(act==='hard'||act==='soft') primaryAction(); return; }
  if (act==='left') move(-1);
  else if (act==='right') move(1);
  else if (act==='rotate') rotate(1);
  else if (act==='soft') softDrop();
  else if (act==='hard') hardDrop();
  else if (act==='hold') hold();
});

/* ---------- main loop ---------- */
function update(dt){
  if (state==='playing'){
    elapsed += dt*1000;
    // horizontal auto-repeat (DAS/ARR)
    if (dasDir!==0){
      dasTimer += dt*1000;
      if (dasTimer>=DAS){ arrTimer += dt*1000; while(arrTimer>=ARR){ move(dasDir); arrTimer-=ARR; } }
    }
    // gravity
    const interval = keys.down ? Math.min(dropInterval, SOFT_DROP_MS) : dropInterval;
    dropTimer += dt*1000;
    while (dropTimer>=interval){
      dropTimer-=interval;
      if (!collides(current,0,1,current.rot)){ current.y++; if(keys.down) score+=1; lockTimer=0; lockActive=false; }
      else { lockActive=true; break; }
    }
    // lock delay
    if (lockActive){
      lockTimer += dt*1000;
      if (lockTimer>=LOCK_DELAY) lockPiece();
    }
    updateHUD();
  } else if (state==='clearing'){
    clearTimer -= dt*1000; clearFlash += dt;
    if (clearTimer<=0) finishClear();
  }
  updateParticles(dt);
}
function loop(t){
  const dt = Math.min(0.05, (t-lastTime)/1000 || 0); lastTime=t;
  update(dt); drawBoard();
  requestAnimationFrame(loop);
}

/* ---------- boot ---------- */
best = parseInt(localStorage.getItem('tetris.best')||'0',10) || 0;
reset();
resize();
showOverlay('TETRIS','Press Enter or tap to start. Clear lines to score.',false);
updateHUD();
window.addEventListener('resize', resize);
if (window.ResizeObserver){ new ResizeObserver(resize).observe(el.boardWrap); }

/* floating background blocks */
(function(){
  const f=document.getElementById('floaters');
  const cols=Object.values(COLORS);
  for (let i=0;i<14;i++){
    const s=document.createElement('span');
    s.style.left=Math.random()*100+'%';
    s.style.background=cols[i%cols.length];
    s.style.animationDuration=(14+Math.random()*16)+'s';
    s.style.animationDelay=(-Math.random()*20)+'s';
    s.style.width=s.style.height=(10+Math.random()*16)+'px';
    f.append(s);
  }
})();

requestAnimationFrame(loop);
</script>
</body>
</html>
```

## How it works

**Core data model.** The board is a `ROWS × COLS` grid (`grid[y][x]`) holding either `null` or a piece letter (`'I'`, `'O'`, …). Each of the seven tetrominoes is stored in `SHAPES` as four explicit rotation states (0–3), each a list of `[x, y]` cells. Precomputing all rotations avoids fragile rotation math and lets the I-piece use its own 4×4 bounding box so it can hug walls.

**Collision.** `collides(piece, dx, dy, rot)` maps every cell of a candidate rotation through the piece's position plus an offset, and returns true if any cell lands outside the walls/floor or on an occupied grid cell. Cells above the top (`y < 0`) are allowed so pieces can spawn partially off-screen.

**Rotation with wall kicks.** `rotate(dir)` computes the target rotation, then walks the SRS kick tables (`KICKS_JLSTZ`, and a separate `KICKS_I` for the I-piece). It tries each offset in order and accepts the first that doesn't collide — this is what lets pieces rotate snugly against walls and into tight slots.

**Movement & gravity.** The game runs on a single `requestAnimationFrame` loop with a delta-time `update()`. Gravity accumulates `dropTimer` and steps the piece down when it exceeds `dropInterval` (which shrinks as the level rises). Horizontal keys use a DAS/ARR auto-repeat so holding a direction moves smoothly. Soft drop adds a small score bonus and speeds the fall.

**Lock delay.** When a piece can't move down, `lockActive` turns on and a `lockTimer` counts up to `LOCK_DELAY` before the piece locks. Any successful move or rotation resets that timer (up to `MAX_LOCK_RESETS` times), so you can slide a piece along the floor before it commits.

**Line clearing.** `lockPiece()` writes the piece into the grid, then scans for full rows. If any exist, `startClear()` scores them (100/300/500/800 × level), bumps the level, spawns particles, and enters a short `clearing` state that flashes the rows white. `finishClear()` then splices those rows out, unshifts empty rows on top, and spawns the next piece.

**Scoring, game over, restart.** Score comes from line clears plus soft/hard-drop bonuses; `best` persists via `localStorage`. If a freshly spawned piece immediately collides, `gameOver()` fires and shows the overlay. `startGame()` resets all state and is wired to Enter, the overlay button, and the Restart button.

**Extras.** A 7-bag randomizer (`refillBag`/`nextType`) guarantees fair piece distribution; a hold slot (`hold()`) swaps the current piece once per drop; a ghost piece previews the landing spot; and the next queue, hold, score, level, lines, timer, and clear count all live-update in the side panels. Rendering uses a device-pixel-ratio-aware canvas so blocks stay crisp, with gradient/bevel shading, a glow on the active piece, and particle bursts on clears.