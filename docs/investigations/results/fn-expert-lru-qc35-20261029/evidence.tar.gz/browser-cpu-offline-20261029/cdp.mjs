import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { pathToFileURL } from 'node:url';

const root = '/tmp/hipfire-qc-browser-20261029';

// Call loadReviewedHtml only after reviewing the original generated HTML.
// This helper supplies observations and input; game-specific assertions live outside it.
export async function openBrowser() {
  const profile = await mkdtemp(`${root}/profile-`);
  const proc = spawn('/usr/bin/chromium', [
    '--headless=new', '--disable-gpu', '--use-gl=disabled',
    '--no-first-run', '--no-default-browser-check', '--disable-extensions',
    '--disable-background-networking', '--disable-component-update',
    '--disable-sync', '--disable-default-apps', '--mute-audio',
    '--deny-permission-prompts', '--window-size=1280,900',
    '--proxy-server=http://127.0.0.1:9', '--proxy-bypass-list=<-loopback>',
    '--host-resolver-rules=MAP * ~NOTFOUND',
    '--remote-debugging-address=127.0.0.1', '--remote-debugging-port=0',
    `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe'] });
  let stderr = '';
  proc.stderr.on('data', b => { stderr = (stderr + b).slice(-16384); });
  let ws;
  let next = 0;
  const pending = new Map();
  const handlers = new Map();
  const errors = [];
  const consoleErrors = [];
  const networkFailures = [];
  const requests = new Map();
  const blockedRequests = [];
  let sessionId;
  let closing = false;

  async function close() {
    if (closing) return;
    closing = true;
    if (ws?.readyState === WebSocket.OPEN) {
      try { await send('Browser.close', {}, null, 2000); } catch {}
      ws.close();
    }
    if (proc.exitCode === null) {
      proc.kill('SIGTERM');
      for (let i = 0; i < 40 && proc.exitCode === null; i++) await delay(50);
      if (proc.exitCode === null) proc.kill('SIGKILL');
    }
    await rm(profile, { recursive: true, force: true });
  }

  function send(method, params = {}, session = sessionId, timeout = 10000) {
    const id = ++next;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error(`CDP timeout: ${method}`));
      }, timeout);
      pending.set(id, { resolve, reject, timer });
      ws.send(JSON.stringify({ id, method, params, ...(session && { sessionId: session }) }));
    });
  }

  function on(method, fn) {
    const list = handlers.get(method) ?? [];
    list.push(fn);
    handlers.set(method, list);
    return () => handlers.set(method, (handlers.get(method) ?? []).filter(f => f !== fn));
  }

  try {
    let active;
    for (let i = 0; i < 200; i++) {
      if (proc.exitCode !== null) throw new Error(`Chromium exited ${proc.exitCode}: ${stderr}`);
      try { active = (await readFile(`${profile}/DevToolsActivePort`, 'utf8')).trim().split('\n'); } catch {}
      if (active?.length >= 2) break;
      await delay(50);
    }
    if (!active) throw new Error(`Chromium startup timed out: ${stderr}`);
    ws = new WebSocket(`ws://127.0.0.1:${active[0]}${active[1]}`);
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve, { once: true });
      ws.addEventListener('error', reject, { once: true });
    });
    ws.addEventListener('message', event => {
      const message = JSON.parse(event.data);
      if (message.id) {
        const p = pending.get(message.id);
        if (!p) return;
        pending.delete(message.id);
        clearTimeout(p.timer);
        if (message.error) p.reject(new Error(JSON.stringify(message.error)));
        else p.resolve(message.result);
      } else {
        for (const fn of handlers.get(message.method) ?? []) {
          Promise.resolve().then(() => fn(message.params)).catch(e => errors.push({ helper: String(e) }));
        }
      }
    });
    ws.addEventListener('close', () => {
      for (const p of pending.values()) { clearTimeout(p.timer); p.reject(new Error('CDP closed')); }
      pending.clear();
    });
    const target = await send('Target.createTarget', { url: 'about:blank' }, null);
    ({ sessionId } = await send('Target.attachToTarget', { targetId: target.targetId, flatten: true }, null));
    on('Runtime.exceptionThrown', ({ exceptionDetails }) => errors.push(exceptionDetails));
    on('Runtime.consoleAPICalled', event => {
      if (event.type === 'error') consoleErrors.push(event.args.map(a => a.value ?? a.description));
    });
    on('Network.requestWillBeSent', event => requests.set(event.requestId, event.request.url));
    on('Network.loadingFailed', event => networkFailures.push({ url: requests.get(event.requestId), ...event }));
    on('Network.webSocketFrameError', event => networkFailures.push({ kind: 'websocket', ...event }));
    on('Fetch.requestPaused', async event => {
      if (/^(https?|wss?):/i.test(event.request.url)) {
        blockedRequests.push(event.request.url);
        await send('Fetch.failRequest', { requestId: event.requestId, errorReason: 'BlockedByClient' });
      } else await send('Fetch.continueRequest', { requestId: event.requestId });
    });
    await send('Runtime.enable');
    await send('Page.enable');
    await send('Network.enable');
    await send('Network.setBlockedURLs', { urls: ['http://*', 'https://*', 'ws://*', 'wss://*'] });
    await send('Fetch.enable', { patterns: [{ urlPattern: '*', requestStage: 'Request' }] });
    await send('Browser.setDownloadBehavior', { behavior: 'deny' }, null);

    async function evaluate(expression) {
      const result = await send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
      if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
      return result.result.value;
    }
    async function loadReviewedHtml(path) {
      const url = pathToFileURL(path).href;
      await send('Page.navigate', { url });
      let ready = false;
      for (let i = 0; i < 200; i++) {
        ready = await evaluate(`location.href === ${JSON.stringify(url)} && document.readyState === 'complete'`);
        if (ready) break;
        await delay(25);
      }
      if (!ready) throw new Error(`Reviewed HTML did not finish loading: ${path}`);
      await evaluate('document.fonts.ready.then(() => true)');
    }
    async function keyPress(key, code, virtualKeyCode, holdMs = 30) {
      const common = { key, code, windowsVirtualKeyCode: virtualKeyCode, nativeVirtualKeyCode: virtualKeyCode };
      await send('Input.dispatchKeyEvent', { type: 'keyDown', ...common });
      if (holdMs) await delay(holdMs);
      await send('Input.dispatchKeyEvent', { type: 'keyUp', ...common });
    }
    return { loadReviewedHtml, evaluate, keyPress, send, on, close, errors, consoleErrors,
      blockedRequests, networkFailures, profile, get stderr() { return stderr; } };
  } catch (error) {
    await close();
    throw error;
  }
}
