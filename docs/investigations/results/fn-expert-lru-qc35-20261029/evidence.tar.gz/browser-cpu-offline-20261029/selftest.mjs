import { createServer } from 'node:http';
import { writeFile, access } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import assert from 'node:assert/strict';
import { openBrowser } from './cdp.mjs';

// Agent-authored fixture only. No generated model output is loaded by this test.
let httpHits = 0, websocketHits = 0;
const server = createServer((_req, res) => { httpHits++; res.end('unexpected'); });
server.on('upgrade', (_req, socket) => { websocketHits++; socket.destroy(); });
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
const path = '/tmp/hipfire-qc-browser-20261029/selftest.html';
await writeFile(path, `<!doctype html><html><body><button id="start">Start</button><script>
window.observed = { keys: [], httpFailed: false, wsFailed: false };
document.addEventListener('keydown', e => observed.keys.push([e.key,e.code,e.keyCode]));
fetch('http://127.0.0.1:${port}/must-be-blocked').catch(() => observed.httpFailed = true);
const socket = new WebSocket('ws://127.0.0.1:${port}/must-be-blocked');
socket.onerror = () => observed.wsFailed = true;
setTimeout(() => { throw new Error('intentional-helper-selftest-error'); }, 0);
</script></body></html>`);
let browser;
try {
  browser = await openBrowser();
  await browser.loadReviewedHtml(path);
  await browser.keyPress('ArrowLeft', 'ArrowLeft', 37);
  await browser.keyPress(' ', 'Space', 32);
  await delay(300);
  const observed = await browser.evaluate('observed');
  assert.deepEqual(observed.keys, [['ArrowLeft', 'ArrowLeft', 37], [' ', 'Space', 32]]);
  assert.equal(observed.httpFailed, true);
  assert.equal(observed.wsFailed, true);
  assert.equal(httpHits, 0);
  assert.equal(websocketHits, 0);
  assert(browser.errors.some(e => e.exception?.description?.includes('intentional-helper-selftest-error')));
  const profile = browser.profile;
  await browser.close();
  await assert.rejects(access(profile));
  const result = { passed: true, fixture: 'agent-authored only', observed, httpHits, websocketHits,
    uncaughtErrorsCaptured: browser.errors.length, blockedRequests: browser.blockedRequests,
    networkFailures: browser.networkFailures, profileRemoved: true,
    limitation: 'Validates helper input/observation/error/network blocking only; no Snake/Tetris functionality or generated output has been evaluated.' };
  await writeFile('/tmp/hipfire-qc-browser-20261029/selftest-result.json', JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result, null, 2));
} finally {
  await browser?.close();
  await new Promise(resolve => server.close(resolve));
}
