
(function(){
  "use strict";

  /* ============================ Config ============================ */
  const COLS = 24, ROWS = 24;
  const BASE_INTERVAL = 130;      // ms per step at speed 1
  const MIN_INTERVAL  = 62;       // fastest step
  const SPEED_EVERY   = 4;        // grow faster every N fruits
  const GOLD_CHANCE   = 0.16;     // chance a fruit spawns as golden
  const GOLD_LIFE     = 6000;     // ms a golden fruit lingers
  const GOLD_POINTS   = 50;
  const FRUIT_POINTS  = 10;
  const DIRS = { up:{x:0,y:-1}, down:{x:0,y:1}, left:{x:-1,y:0}, right:{x:1,y:0} };

  const C = {
    bg:'#0a1712', grid:'rgba(120,200,160,.05)', gridStrong:'rgba(120,200,160,.09)',
    head:'#d6ff7a', headEdge:'#b6f24a', body:'#8fd92f', bodyEdge:'#5fae1f',
    eye:'#08130f', food:'#ffc24b', foodCore:'#fff0b8', foodGlow:'rgba(255,194,75,.55)',
    gold:'#ffd24a', goldCore:'#fff6cf', goldGlow:'rgba(255,210,74,.7)',
    wall:'#ff6b5e', text:'#eaf6ee', muted:'#8fb0a2'
  };

  /* ============================ State ============================ */
  let canvas, ctx, cell = 20, dpr = 1;
  let snake = [], dir = DIRS.right, dirQueue = [];
  let food = null, gold = null, goldTimer = 0;
  let score = 0, best = 0, fruitsEaten = 0, speedLevel = 1;
  let state = 'start';            // start | playing | paused | over | win
  let mode = 'classic';           // classic | wrap
  let soundOn = true;
  let interval = BASE_INTERVAL, acc = 0, last = 0;
  let particles = [], floaters = [];
  let shake = 0, flash = 0, flashColor = '255,107,94';
  let deathReason = '';
  let audioCtx = null;

  /* ============================ DOM ============================ */
  const $ = id => document.getElementById(id);
  const board = $('board');
  const el = {
    score:$('score'), best:$('best'), length:$('length'), speed:$('speed'), speedFill:$('speedFill'),
    bestChip:$('bestChip'), modeChip:$('modeChip'),
    ovStart:$('ovStart'), ovPause:$('ovPause'), ovOver:$('ovOver'), ovWin:$('ovWin'),
    overScore:$('overScore'), overSub:$('overSub'), overTitle:$('overTitle'), overKicker:$('overKicker'),
    winScore:$('winScore'), pauseBtn:$('pauseBtn')
  };

  /* ============================ Helpers ============================ */
  const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
  const lerp  = (a,b,t) => a + (b-a)*t;
  const rand  = (a,b) => a + Math.random()*(b-a);
  const key   = (x,y) => x + ',' + y;
  const occupied = () => { const s = new Set(); for (const p of snake) s.add(key(p.x,p.y)); if (food) s.add(key(food.x,food.y)); if (gold) s.add(key(gold.x,gold.y)); return s; };

  function rr(x,y,w,h,r){
    r = Math.min(r, w/2, h/2);
    ctx.beginPath();
    ctx.moveTo(x+r,y);
    ctx.arcTo(x+w,y,x+w,y+h,r);
    ctx.arcTo(x+w,y+h,x,y+h,r);
    ctx.arcTo(x,y+h,x,y,r);
    ctx.arcTo(x,y,x+w,y,r);
    ctx.closePath();
  }

  /* ============================ Audio ============================ */
  function ensureAudio(){
    if (!audioCtx){ try { audioCtx = new (window.AudioContext||window.webkitAudioContext)(); } catch(e){} }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
  }
  function tone(freq, dur, type, vol, slideTo){
    if (!soundOn || !audioCtx) return;
    const t = audioCtx.currentTime;
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.05, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(audioCtx.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }
  const sfx = {
    eat(){ tone(520, .09, 'square', .05, 760); },
    gold(){ tone(660, .1, 'triangle', .06, 990); setTimeout(()=>tone(990,.12,'triangle',.05,1320),70); },
    die(){ tone(300, .35, 'sawtooth', .07, 70); },
    ui(){ tone(420, .05, 'square', .03); }
  };

  /* ============================ Game logic ============================ */
  function reset(){
    const cx = Math.floor(COLS/2), cy = Math.floor(ROWS/2);
    snake = [{x:cx,y:cy},{x:cx-1,y:cy},{x:cx-2,y:cy}];
    dir = DIRS.right; dirQueue = [];
    food = null; gold = null; goldTimer = 0;
    score = 0; fruitsEaten = 0; speedLevel = 1; interval = BASE_INTERVAL; acc = 0;
    particles = []; floaters = []; shake = 0; flash = 0;
    spawnFood();
    updateHUD();
  }

  function spawnFood(){
    const occ = occupied();
    const free = [];
    for (let y=0;y<ROWS;y++) for (let x=0;x<COLS;x++) if (!occ.has(key(x,y))) free.push({x,y});
    if (!free.length){ win(); return; }
    const p = free[Math.floor(Math.random()*free.length)];
    food = { x:p.x, y:p.y, pulse:0 };
    if (!gold && Math.random() < GOLD_CHANCE){
      const occ2 = occupied();
      const free2 = free.filter(c => !occ2.has(key(c.x,c.y)));
      if (free2.length){ const g = free2[Math.floor(Math.random()*free2.length)]; gold = { x:g.x, y:g.y, life:GOLD_LIFE, max:GOLD_LIFE }; }
    }
  }

  function enqueueDir(d){
    const last = dirQueue.length ? dirQueue[dirQueue.length-1] : dir;
    if ((d.x === -last.x && d.y === -last.y) || (d.x === last.x && d.y === last.y)) return;
    if (dirQueue.length < 2) dirQueue.push(d);
  }

  function step(){
    if (dirQueue.length) dir = dirQueue.shift();
    const head = snake[0];
    let nx = head.x + dir.x, ny = head.y + dir.y;

    if (mode === 'wrap'){
      nx = (nx + COLS) % COLS; ny = (ny + ROWS) % ROWS;
    } else if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS){
      return die('wall');
    }

    const willEat = food && nx === food.x && ny === food.y;
    const willGold = gold && nx === gold.x && ny === gold.y;

    // Self-collision (tail vacates this tick unless we grow)
    const tail = snake[snake.length-1];
    const tailMoves = !(willEat || willGold);
    for (let i=0;i<snake.length;i++){
      const s = snake[i];
      if (s.x === nx && s.y === ny){
        if (i === snake.length-1 && tailMoves) continue;
        return die('self');
      }
    }

    snake.unshift({x:nx, y:ny});

    if (willGold){
      score += GOLD_POINTS; gold = null; goldTimer = 0;
      burst(nx,ny,C.gold,22); floaters.push({x:nx,y:ny,text:'+'+GOLD_POINTS,color:C.gold,life:900});
      flash = 1; flashColor = '255,210,74'; sfx.gold();
    } else if (willEat){
      score += FRUIT_POINTS; fruitsEaten++;
      burst(nx,ny,C.food,14); floaters.push({x:nx,y:ny,text:'+'+FRUIT_POINTS,color:C.food,life:800});
      sfx.eat();
      if (fruitsEaten % SPEED_EVERY === 0){ speedLevel++; interval = Math.max(MIN_INTERVAL, BASE_INTERVAL - (speedLevel-1)*8); }
      spawnFood();
    } else {
      snake.pop();
    }
    updateHUD();
  }

  function die(reason){
    state = 'over'; deathReason = reason;
    shake = 1; flash = 1; flashColor = '255,107,94';
    burst(snake[0].x, snake[0].y, C.wall, 26);
    sfx.die();
    if (score > best){ best = score; try{ localStorage.setItem('snake_best', best); }catch(e){} }
    el.overScore.textContent = score;
    el.overSub.innerHTML = 'Best <b>' + best + '</b>';
    el.overTitle.textContent = reason === 'wall' ? 'Hit the wall' : 'Bit yourself';
    el.overKicker.textContent = score >= best && score > 0 ? 'New best!' : 'Game over';
    showOverlay(el.ovOver);
    updateHUD();
  }

  function win(){
    state = 'win';
    if (score > best){ best = score; try{ localStorage.setItem('snake_best', best); }catch(e){} }
    el.winScore.textContent = score;
    showOverlay(el.ovWin);
    updateHUD();
  }

  /* ============================ Particles ============================ */
  function burst(gx,gy,color,n){
    const cx = (gx+0.5)*cell, cy = (gy+0.5)*cell;
    for (let i=0;i<n;i++){
      const a = Math.random()*Math.PI*2, sp = rand(40,180);
      particles.push({ x:cx, y:cy, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp, life:rand(300,650), max:650, size:rand(2,5), color });
    }
  }

  /* ============================ HUD ============================ */
  function updateHUD(){
    el.score.textContent = score;
    el.best.textContent = best;
    el.bestChip.textContent = best;
    el.length.textContent = snake.length;
    el.speed.textContent = speedLevel;
    const pct = clamp((BASE_INTERVAL - interval) / (BASE_INTERVAL - MIN_INTERVAL), 0, 1);
    el.speedFill.style.width = (pct*100).toFixed(0) + '%';
  }
  function popScore(){ el.score.classList.remove('pop'); void el.score.offsetWidth; el.score.classList.add('pop'); }

  /* ============================ Overlays ============================ */
  function showOverlay(node){ [el.ovStart,el.ovPause,el.ovOver,el.ovWin].forEach(o=>o.classList.toggle('show', o===node)); }
  function hideOverlays(){ [el.ovStart,el.ovPause,el.ovOver,el.ovWin].forEach(o=>o.classList.remove('show')); }

  function startGame(){ ensureAudio(); reset(); state = 'playing'; hideOverlays(); }
  function togglePause(){
    if (state === 'playing'){ state = 'paused'; showOverlay(el.ovPause); }
    else if (state === 'paused'){ state = 'playing'; hideOverlays(); }
  }
  function toMenu(){ state = 'start'; reset(); showOverlay(el.ovStart); }

  /* ============================ Rendering ============================ */
  function drawGrid(){
    ctx.lineWidth = 1;
    for (let x=1;x<COLS;x++){ ctx.strokeStyle = (x%4===0)?C.gridStrong:C.grid; ctx.beginPath(); ctx.moveTo(x*cell+.5,0); ctx.lineTo(x*cell+.5,ROWS*cell); ctx.stroke(); }
    for (let y=1;y<ROWS;y++){ ctx.strokeStyle = (y%4===0)?C.gridStrong:C.grid; ctx.beginPath(); ctx.moveTo(0,y*cell+.5); ctx.lineTo(COLS*cell,y*cell+.5); ctx.stroke(); }
  }

  function drawWalls(){
    if (mode !== 'classic') return;
    const t = Math.max(3, cell*0.28);
    ctx.save();
    ctx.shadowColor = C.wall; ctx.shadowBlur = 14;
    ctx.fillStyle = 'rgba(255,107,94,.16)';
    ctx.fillRect(0,0,COLS*cell,t); ctx.fillRect(0,ROWS*cell-t,COLS*cell,t);
    ctx.fillRect(0,0,t,ROWS*cell); ctx.fillRect(COLS*cell-t,0,t,ROWS*cell);
    ctx.restore();
  }

  function drawFood(){
    if (!food) return;
    const cx = (food.x+0.5)*cell, cy = (food.y+0.5)*cell;
    const pulse = 1 + Math.sin(food.pulse)*0.12;
    const r = cell*0.34*pulse;
    ctx.save();
    ctx.shadowColor = C.foodGlow; ctx.shadowBlur = 16;
    const g = ctx.createRadialGradient(cx-r*0.3, cy-r*0.3, r*0.1, cx, cy, r);
    g.addColorStop(0, C.foodCore); g.addColorStop(1, C.food);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fill();
    ctx.restore();
    ctx.fillStyle = 'rgba(255,255,255,.5)';
    ctx.beginPath(); ctx.arc(cx-r*0.32, cy-r*0.32, r*0.22, 0, Math.PI*2); ctx.fill();
  }

  function drawGold(){
    if (!gold) return;
    const cx = (gold.x+0.5)*cell, cy = (gold.y+0.5)*cell;
    const frac = gold.life / gold.max;
    const blink = frac < 0.35 ? (Math.sin(gold.life/60) > 0 ? 1 : 0.35) : 1;
    const r = cell*0.36;
    ctx.save();
    ctx.globalAlpha = blink;
    ctx.shadowColor = C.goldGlow; ctx.shadowBlur = 20;
    const g = ctx.createRadialGradient(cx-r*0.3, cy-r*0.3, r*0.1, cx, cy, r);
    g.addColorStop(0, C.goldCore); g.addColorStop(1, C.gold);
    ctx.fillStyle = g;
    ctx.beginPath();
    for (let i=0;i<5;i++){
      const a = -Math.PI/2 + i*(Math.PI*2/5);
      const a2 = a + Math.PI/5;
      ctx.lineTo(cx+Math.cos(a)*r, cy+Math.sin(a)*r);
      ctx.lineTo(cx+Math.cos(a2)*r*0.45, cy+Math.sin(a2)*r*0.45);
    }
    ctx.closePath(); ctx.fill();
    ctx.restore();
    // life ring
    ctx.save();
    ctx.strokeStyle = 'rgba(255,210,74,.85)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(cx, cy, cell*0.46, -Math.PI/2, -Math.PI/2 + Math.PI*2*frac); ctx.stroke();
    ctx.restore();
  }

  function drawSnake(){
    const n = snake.length;
    const pad = cell*0.10, r = cell*0.30;
    for (let i=n-1;i>=0;i--){
      const s = snake[i];
      const t = n>1 ? i/(n-1) : 0;
      const col = i===0 ? C.head : `rgb(${Math.round(lerp(143,95,t))},${Math.round(lerp(217,150,t))},${Math.round(lerp(47,31,t))})`;
      ctx.save();
      if (i===0){ ctx.shadowColor = 'rgba(182,242,74,.55)'; ctx.shadowBlur = 12; }
      ctx.fillStyle = col;
      rr(s.x*cell+pad, s.y*cell+pad, cell-2*pad, cell-2*pad, r);
      ctx.fill();
      ctx.restore();
      if (i===0) drawEyes(s);
    }
  }

  function drawEyes(head){
    const cx = (head.x+0.5)*cell, cy = (head.y+0.5)*cell;
    const f = dir, px = -f.y, py = f.x;
    const fwd = cell*0.16, side = cell*0.17, er = cell*0.11;
    for (const s of [-1,1]){
      const ex = cx + f.x*fwd + px*side*s, ey = cy + f.y*fwd + py*side*s;
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex,ey,er,0,Math.PI*2); ctx.fill();
      ctx.fillStyle = C.eye; ctx.beginPath(); ctx.arc(ex+f.x*er*0.4, ey+f.y*er*0.4, er*0.55, 0, Math.PI*2); ctx.fill();
    }
  }

  function drawParticles(dt){
    for (let i=particles.length-1;i>=0;i--){
      const p = particles[i];
      p.life -= dt;
      if (p.life <= 0){ particles.splice(i,1); continue; }
      p.x += p.vx*dt/1000; p.y += p.vy*dt/1000;
      p.vx *= 0.92; p.vy *= 0.92;
      ctx.globalAlpha = clamp(p.life/p.max,0,1);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x-p.size/2, p.y-p.size/2, p.size, p.size);
    }
    ctx.globalAlpha = 1;
  }

  function drawFloaters(dt){
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = `700 ${Math.round(cell*0.7)}px 'Space Grotesk', sans-serif`;
    for (let i=floaters.length-1;i>=0;i--){
      const f = floaters[i];
      f.life -= dt;
      if (f.life <= 0){ floaters.splice(i,1); continue; }
      const a = clamp(f.life/800,0,1);
      const y = (f.y+0.5)*cell - (1 - f.life/800)*cell*0.9;
      ctx.globalAlpha = a;
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, (f.x+0.5)*cell, y);
    }
    ctx.globalAlpha = 1;
  }

  function render(dt){
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,canvas.width/dpr,canvas.height/dpr);
    ctx.fillStyle = C.bg; ctx.fillRect(0,0,canvas.width/dpr,canvas.height/dpr);

    ctx.save();
    if (shake > 0){ ctx.translate(rand(-1,1)*shake*7, rand(-1,1)*shake*7); }
    drawGrid();
    drawWalls();
    drawFood();
    drawGold();
    drawSnake();
    drawParticles(dt);
    drawFloaters(dt);
    ctx.restore();

    if (flash > 0){
      ctx.fillStyle = `rgba(${flashColor},${flash*0.35})`;
      ctx.fillRect(0,0,canvas.width/dpr,canvas.height/dpr);
    }
  }

  /* ============================ Loop ============================ */
  function update(dt){
    if (state === 'playing'){
      acc += dt;
      let guard = 0;
      while (acc >= interval && state === 'playing' && guard++ < 5){ step(); acc -= interval; }
      if (gold){ goldTimer += dt; if (goldTimer >= gold.life){ gold = null; goldTimer = 0; } }
      if (food) food.pulse += dt/180;
    }
    if (shake > 0) shake = Math.max(0, shake - dt/220);
    if (flash > 0) flash = Math.max(0, flash - dt/260);
  }

  function frame(now){
    const dt = Math.min(50, now - last); last = now;
    update(dt);
    render(dt);
    requestAnimationFrame(frame);
  }

  /* ============================ Resize ============================ */
  function resize(){
    const rect = board.getBoundingClientRect();
    const size = Math.max(1, Math.floor(Math.min(rect.width, rect.height)));
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size*dpr; canvas.height = size*dpr;
    canvas.style.width = size+'px'; canvas.style.height = size+'px';
    cell = size / COLS;
  }

  /* ============================ Input ============================ */
  function bind(){
    window.addEventListener('keydown', e=>{
      const k = e.key.toLowerCase();
      const dirMap = { arrowup:'up', w:'up', arrowdown:'down', s:'down', arrowleft:'left', a:'left', arrowright:'right', d:'right' };
      if (dirMap[k]){
        e.preventDefault();
        if (state === 'start'){ startGame(); }
        if (state === 'playing') enqueueDir(DIRS[dirMap[k]]);
        return;
      }
      if (k === ' ' || k === 'spacebar'){ e.preventDefault(); if (state==='playing'||state==='paused') togglePause(); else if (state==='start') startGame(); }
      else if (k === 'p'){ if (state==='playing'||state==='paused') togglePause(); }
      else if (k === 'enter'){ if (state==='over'||state==='win'||state==='start') startGame(); }
      else if (k === 'r'){ if (state!=='start') startGame(); }
    });

    // Buttons
    $('startBtn').onclick = ()=>{ sfx.ui(); startGame(); };
    $('resumeBtn').onclick = ()=>{ sfx.ui(); togglePause(); };
    $('pauseRestart').onclick = ()=>{ sfx.ui(); startGame(); };
    $('againBtn').onclick = ()=>{ sfx.ui(); startGame(); };
    $('overMenu').onclick = ()=>{ sfx.ui(); toMenu(); };
    $('winAgain').onclick = ()=>{ sfx.ui(); startGame(); };
    $('winMenu').onclick = ()=>{ sfx.ui(); toMenu(); };
    el.pauseBtn.onclick = ()=>{ sfx.ui(); if (state==='playing'||state==='paused') togglePause(); };
    $('restartBtn').onclick = ()=>{ sfx.ui(); startGame(); };

    // Mode segmented control
    document.querySelectorAll('#modeSeg button').forEach(b=>{
      b.onclick = ()=>{
        mode = b.dataset.mode;
        document.querySelectorAll('#modeSeg button').forEach(x=>x.classList.toggle('active', x===b));
        el.modeChip.textContent = mode === 'wrap' ? 'Wrap' : 'Classic';
        sfx.ui();
        if (state === 'playing' || state === 'paused'){ reset(); state = 'playing'; hideOverlays(); }
      };
    });

    // Sound toggle
    $('soundToggle').onclick = function(){
      soundOn = !soundOn;
      this.classList.toggle('on', soundOn);
      if (soundOn){ ensureAudio(); sfx.ui(); }
    };

    // Touch / swipe
    let tsx=0, tsy=0, swiping=false;
    canvas.addEventListener('touchstart', e=>{ const t=e.touches[0]; tsx=t.clientX; tsy=t.clientY; swiping=true; }, {passive:true});
    canvas.addEventListener('touchmove', e=>{
      if (!swiping) return;
      const t=e.touches[0], dx=t.clientX-tsx, dy=t.clientY-tsy;
      if (Math.abs(dx) < 24 && Math.abs(dy) < 24) return;
      if (state === 'start'){ startGame(); }
      if (state === 'playing'){
        if (Math.abs(dx) > Math.abs(dy)) enqueueDir(dx>0?DIRS.right:DIRS.left);
        else enqueueDir(dy>0?DIRS.down:DIRS.up);
      }
      tsx=t.clientX; tsy=t.clientY;
    }, {passive:true});
    canvas.addEventListener('touchend', ()=>{ swiping=false; });

    // Score pop on eat
    const origEat = sfx.eat;
    sfx.eat = function(){ origEat(); popScore(); };

    // Pause when tab hidden
    document.addEventListener('visibilitychange', ()=>{ if (document.hidden && state==='playing') togglePause(); });

    // Reveal on scroll
    const io = new IntersectionObserver(entries=>{
      entries.forEach(en=>{ if (en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold:0.12 });
    document.querySelectorAll('.reveal').forEach(n=>io.observe(n));
  }

  /* ============================ Init ============================ */
  function init(){
    canvas = $('game'); ctx = canvas.getContext('2d');
    try { best = parseInt(localStorage.getItem('snake_best')||'0',10) || 0; } catch(e){ best = 0; }
    resize();
    reset();
    bind();
    last = performance.now();
    requestAnimationFrame(frame);
    if (window.ResizeObserver) new ResizeObserver(resize).observe(board);
    window.addEventListener('resize', resize);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
