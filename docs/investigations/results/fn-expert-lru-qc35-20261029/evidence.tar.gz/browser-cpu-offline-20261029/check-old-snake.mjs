import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { openBrowser } from './cdp.mjs';

const root = '/tmp/hipfire-qc-browser-20261029';
const checks = [], fixtures = [];
const result = { artifact: 'old-snake-original.html', provenance: JSON.parse(await readFile(`${root}/old-snake-source-review.json`, 'utf8')),
  evidence: 'Offline integration checks of one generated artifact, not a gold/reference score.',
  method: 'Unchanged original HTML at file://. CDP frame breakpoints inspect original IIFE lexical state. Real keyboard/mouse inputs run original handlers/update/step. Explicit food/snake/accumulator fixtures only; no algorithm replacement, injected API, score assignment or direct game-over state assignment.',
  checks, fixtures, limits: ['Not exhaustive gameplay or human usability.', 'Optional Google Fonts blocked; fallback fonts rendered.',
    'No full-board win, golden bonus expiry, touch, audio quality, cross-session persistence, or long-run randomized qualification.'] };
let b, paused, waiter, location, breakpointId, success = false;
const scripts = [];
function nextPause() {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => { waiter = null; reject(new Error('Frame breakpoint timeout')); }, 10000);
    waiter = p => { clearTimeout(t); resolve(p); };
  });
}
async function scope(expression) {
  const r = await b.send('Debugger.evaluateOnCallFrame', { callFrameId: paused.callFrames[0].callFrameId, expression, returnByValue: true });
  if (r.exceptionDetails) throw new Error(r.exceptionDetails.exception?.description ?? r.exceptionDetails.text);
  return r.result.value;
}
const snap = () => scope('({snake,dir,dirQueue,food,gold,score,best,state,mode,interval,acc,last})');
async function frame(input) {
  let click;
  if (input?.click) {
    click = await scope(`(() => {let r=document.getElementById(${JSON.stringify(input.click)}).getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()`);
    const hit=await scope(`document.elementFromPoint(${click.x},${click.y})?.id`);
    (result.pointer_observations ??= []).push({target:input.click,point:click,hit});
    assert.equal(hit,input.click,'Physical mouse coordinates must hit intended button');
  }
  if (input) await b.send('Debugger.removeBreakpoint', {breakpointId});
  const p = nextPause();
  await b.send('Debugger.resume');
  if (input?.key) await b.keyPress(...input.key, 0);
  if (click) {
    await b.send('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', clickCount: 1, ...click });
    await b.send('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', clickCount: 1, ...click });
  }
  if (input) ({breakpointId} = await b.send('Debugger.setBreakpoint', {location}));
  paused = await p;
  return snap();
}
async function until(predicate, input) {
  let s;
  for (let i = 0; i < 150; i++) { s = await frame(i === 0 ? input : undefined); if (predicate(s)) return s; }
  throw new Error(`150-frame limit: ${JSON.stringify(s)}`);
}
async function move(input) {
  const a = await snap();
  return until(s => s.state !== 'playing' || s.snake[0].x !== a.snake[0].x || s.snake[0].y !== a.snake[0].y, input);
}
async function check(name, fn) {
  try { checks.push({ name, status: 'PASS', evidence: await fn() }); console.error('PASS', name); }
  catch (e) { checks.push({ name, status: 'FAIL', error: String(e) }); throw e; }
}
async function setup(name, expression) {
  fixtures.push({ name, expression }); await scope(expression);
}
async function screenshot(name) {
  (result.screenshots_skipped ??= []).push({name, reason:'Optional screenshots skipped while Debugger-paused; does not affect game state assertions.'});
}
const K = { left: ['ArrowLeft', 'ArrowLeft', 37], up: ['ArrowUp', 'ArrowUp', 38], down: ['ArrowDown', 'ArrowDown', 40],
  space: [' ', 'Space', 32], p: ['p', 'KeyP', 80], r: ['r', 'KeyR', 82], enter: ['Enter', 'Enter', 13] };

try {
  b = await openBrowser();
  b.on('Debugger.scriptParsed', s => scripts.push(s));
  b.on('Debugger.paused', p => { paused = p; const w = waiter; waiter = null; w?.(p); });
  await b.send('Debugger.enable');
  await b.loadReviewedHtml(`${root}/old-snake-original.html`);
  let script, source;
  for (const s of scripts) {
    const r = await b.send('Debugger.getScriptSource', { scriptId: s.scriptId });
    if (r.scriptSource.includes('function frame(now)') && r.scriptSource.includes('function enqueueDir')) { script = s; source = r.scriptSource; break; }
  }
  assert(script, 'Original inline script located');
  const lines = source.split('\n'), begin = lines.findIndex(l => l.includes('function frame(now)'));
  const relative = lines.findIndex((l, i) => i > begin && l.includes('requestAnimationFrame(frame)'));
  const p = nextPause();
  location = { scriptId: script.scriptId, lineNumber: script.startLine + relative, columnNumber: 0 };
  result.breakpoint = await b.send('Debugger.setBreakpoint', { location });
  breakpointId = result.breakpoint.breakpointId;
  paused = await p;
  result.origin = await scope(`({href:location.href,origin:location.origin,localStorageAvailable:(()=>{try{localStorage.setItem('qc_probe','1');localStorage.removeItem('qc_probe');return true;}catch(e){return String(e);}})()})`);
  await check('load_canvas_initial_state', async () => {
    const s = await snap();
    const dom = await scope(`({title:document.title,canvas:{width:game.width,height:game.height},start:document.getElementById('ovStart').classList.contains('show'),score:document.getElementById('score').textContent,length:document.getElementById('length').textContent})`);
    assert.equal(s.state, 'start'); assert.equal(s.snake.length, 3); assert.equal(s.score, 0);
    assert(dom.start && dom.canvas.width > 0 && dom.canvas.height > 0); assert.equal(dom.score, '0'); assert.equal(dom.length, '3');
    await screenshot('old-snake-load'); return { state: s, dom };
  });
  await check('start_and_automatic_movement', async () => {
    const a = await until(s => s.state === 'playing', { key: K.space }), z = await move();
    assert.equal(z.state, 'playing'); assert.equal(z.snake[0].x, a.snake[0].x + 1); assert.equal(z.snake[0].y, a.snake[0].y);
    return { before: a.snake, after: z.snake };
  });
  for (const [name, key, direction] of [['horizontal_reverse_rejected', K.left, {x:1,y:0}], ['turn_up', K.up, {x:0,y:-1}], ['vertical_reverse_rejected', K.down, {x:0,y:-1}]]) {
    await check(name, async () => {
      const a = await snap(), z = await move({ key });
      assert.equal(z.state, 'playing'); assert.deepEqual(z.dir, direction);
      assert.deepEqual(z.snake[0], { x: a.snake[0].x + direction.x, y: a.snake[0].y + direction.y });
      return { before: a.snake, after: z.snake, dir: z.dir };
    });
  }
  await check('pause_freezes_movement_and_score', async () => {
    const a = await until(s => s.state === 'paused', { key: K.space });
    const z = await until(s => s.last - a.last >= 420);
    assert.equal(z.state, 'paused'); assert.deepEqual(z.snake, a.snake); assert.equal(z.score, a.score);
    assert(await scope(`document.getElementById('ovPause').classList.contains('show')`));
    return { browser_elapsed_ms: z.last-a.last, snake: z.snake, score: z.score };
  });
  await check('resume_restores_movement', async () => {
    await until(s => s.state === 'playing', { key: K.p }); const a = await snap(), z = await move();
    assert.equal(z.state, 'playing'); assert(z.snake[0].y < a.snake[0].y); return { before: a.snake, after: z.snake };
  });
  await check('keyboard_restart_resets_game', async () => {
    const s = await until(s => s.state === 'playing' && s.score === 0 && s.snake.length === 3 && s.snake[0].x === 12 && s.snake[0].y === 12, { key: K.r });
    assert.deepEqual(s.dir, { x:1,y:0 }); return s;
  });
  for (let n = 1; n <= 2; n++) {
    await check(`food_${n}_growth_score_hud_respawn`, async () => {
      const a = await snap();
      await setup(`normal fruit ${n} one cell ahead`, 'food={x:snake[0].x+dir.x,y:snake[0].y+dir.y,pulse:0};gold=null;acc=0;undefined');
      const placed = await snap(), z = await move();
      assert.equal(z.score, a.score + 10); assert.equal(z.snake.length, a.snake.length + 1); assert.equal(z.state, 'playing');
      const hud = await scope(`({score:document.getElementById('score').textContent,length:document.getElementById('length').textContent})`);
      assert.equal(hud.score, String(z.score)); assert.equal(hud.length, String(z.snake.length));
      assert(!z.snake.some(p => p.x === z.food.x && p.y === z.food.y));
      if (n === 2) await screenshot('old-snake-growth');
      return { before: {score:a.score,length:a.snake.length}, fixture: placed, after: z, hud };
    });
  }
  await check('wall_collision_game_over', async () => {
    await setup('legal length-3 snake adjacent to right wall', 'snake=[{x:23,y:12},{x:22,y:12},{x:21,y:12}];dir=DIRS.right;dirQueue=[];food={x:2,y:2,pulse:0};gold=null;acc=0;undefined');
    const z = await until(s => s.state === 'over');
    const dom = await scope(`({title:document.getElementById('overTitle').textContent,shown:document.getElementById('ovOver').classList.contains('show'),score:document.getElementById('overScore').textContent})`);
    assert.equal(dom.title, 'Hit the wall'); assert(dom.shown); assert.equal(dom.score, String(z.score));
    await screenshot('old-snake-wall'); return { after: z, dom };
  });
  await check('enter_restarts_after_game_over', async () => {
    const s = await until(s => s.state === 'playing' && s.score === 0 && s.snake.length === 3, { key: K.enter });
    assert.equal(await scope(`document.getElementById('ovOver').classList.contains('show')`), false); return s;
  });
  await check('self_collision_game_over', async () => {
    await setup('contiguous length-5 snake; turn up enters a non-tail segment', 'snake=[{x:5,y:5},{x:4,y:5},{x:4,y:4},{x:5,y:4},{x:6,y:4}];dir=DIRS.right;dirQueue=[];food={x:2,y:2,pulse:0};gold=null;acc=0;undefined');
    const a = await snap(), z = await until(s => s.state === 'over', { key: K.up });
    const dom = await scope(`({title:document.getElementById('overTitle').textContent,shown:document.getElementById('ovOver').classList.contains('show')})`);
    assert.equal(dom.title, 'Bit yourself'); assert(dom.shown); assert.deepEqual(z.dir, {x:0,y:-1});
    await screenshot('old-snake-self-collision'); return { before: a, after: z, dom };
  });
  await check('play_again_button_restarts', async () => {
    const before=await snap(); await until(s=>s.last-before.last>=500);
    const s = await until(s => s.state === 'playing' && s.score === 0 && s.snake.length === 3, { click: 'againBtn' });
    assert.equal(await scope(`document.getElementById('ovOver').classList.contains('show')`), false); return s;
  });
  await check('no_uncaught_js_exceptions', async () => { assert.equal(b.errors.length, 0); return { count: b.errors.length }; });
  success = true;
} catch (e) { result.failure = { error: String(e), stack: e.stack }; }
finally {
  result.successful = success; result.errors = b?.errors ?? []; result.console_errors = b?.consoleErrors ?? [];
  result.network_failures = b?.networkFailures ?? []; result.blocked_requests = b?.blockedRequests ?? [];
  result.browser_stderr = b?.stderr; result.finished_utc = new Date().toISOString();
  result.counts = { pass: checks.filter(c => c.status === 'PASS').length, fail: checks.filter(c => c.status === 'FAIL').length };
  await b?.close();
  await writeFile(`${root}/old-snake-functional.json`, JSON.stringify(result, null, 2)+'\n');
  console.log(JSON.stringify({ successful: success, counts: result.counts, failure: result.failure, checks: checks.map(c=>({name:c.name,status:c.status})), errors: result.errors, network_failures: result.network_failures },null,2));
  process.exitCode = success ? 0 : 1;
}
