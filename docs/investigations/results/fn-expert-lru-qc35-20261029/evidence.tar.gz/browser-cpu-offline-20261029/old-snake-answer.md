Here's a complete, self-contained Snake game. Save it as `snake.html` and open it in any modern browser.

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Snake — Arcade</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bungee&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root{
    --bg:#081310; --panel:#0f2019; --panel-2:#132a21;
    --line:rgba(120,200,160,.14); --line-strong:rgba(120,200,160,.28);
    --ink:#eaf6ee; --muted:#8fb0a2; --muted-2:#6f9184;
    --lime:#b6f24a; --lime-2:#8fd92f; --amber:#ffc24b; --coral:#ff6b5e; --teal:#37d6c0;
    --shadow:0 24px 60px -24px rgba(0,0,0,.75);
  }
  *{box-sizing:border-box}
  html,body{margin:0}
  body{
    min-height:100vh; color:var(--ink);
    font-family:'Space Grotesk',system-ui,sans-serif;
    background:
      radial-gradient(1200px 700px at 12% -12%, rgba(182,242,74,.10), transparent 60%),
      radial-gradient(1000px 800px at 112% 118%, rgba(55,214,192,.10), transparent 55%),
      radial-gradient(700px 500px at 90% 8%, rgba(255,194,75,.06), transparent 60%),
      var(--bg);
    overflow-x:hidden;
  }
  body::before{
    content:''; position:fixed; inset:0; pointer-events:none; z-index:0;
    background-image:
      linear-gradient(rgba(120,200,160,.05) 1px, transparent 1px),
      linear-gradient(90deg, rgba(120,200,160,.05) 1px, transparent 1px);
    background-size:44px 44px;
    -webkit-mask-image:radial-gradient(circle at 50% 38%, #000, transparent 82%);
            mask-image:radial-gradient(circle at 50% 38%, #000, transparent 82%);
  }
  .wrap{position:relative; z-index:1; max-width:1180px; margin:0 auto; padding:clamp(18px,3vw,40px)}

  /* ---------- Header ---------- */
  .topbar{display:flex; justify-content:space-between; align-items:flex-end; gap:24px; flex-wrap:wrap; margin-bottom:clamp(18px,3vw,30px)}
  .brand{display:flex; align-items:center; gap:16px}
  .logo{width:56px; height:56px; flex:none; filter:drop-shadow(0 6px 14px rgba(182,242,74,.35))}
  .logo .seg{fill:var(--lime)}
  .logo .seg:nth-child(2){fill:var(--lime-2)}
  .logo .seg:nth-child(3){fill:var(--teal)}
  .logo .eye{fill:#08130f}
  .logo .tongue{stroke:var(--coral); stroke-width:2.4; stroke-linecap:round; fill:none}
  .logo .tongue{animation:flick 2.4s ease-in-out infinite}
  @keyframes flick{0%,88%,100%{opacity:0}92%,96%{opacity:1}}
  .brand h1{font-family:'Bungee',cursive; font-weight:400; font-size:clamp(2.1rem,5.4vw,3.4rem); line-height:.9; margin:0; letter-spacing:.01em; color:var(--ink)}
  .brand h1 span{color:var(--lime)}
  .brand p{margin:.35rem 0 0; color:var(--muted); font-size:.9rem; max-width:34ch}
  .topbar .meta{display:flex; gap:10px; flex-wrap:wrap}
  .chip{display:inline-flex; align-items:center; gap:8px; padding:8px 13px; border:1px solid var(--line); border-radius:999px; background:rgba(255,255,255,.02); font-size:.8rem; color:var(--muted)}
  .chip b{color:var(--ink); font-weight:600}
  .dot{width:8px; height:8px; border-radius:50%; background:var(--lime); box-shadow:0 0 10px var(--lime)}

  /* ---------- Layout ---------- */
  .stage{display:grid; grid-template-columns:minmax(0,1fr) 320px; gap:clamp(16px,2.4vw,28px); align-items:start}
  @media (max-width:900px){ .stage{grid-template-columns:1fr} }

  /* ---------- Board ---------- */
  .board{position:relative; width:100%; max-width:640px; margin-inline:auto; aspect-ratio:1/1;
    border-radius:20px; overflow:hidden; background:#0a1712;
    border:1px solid var(--line-strong); box-shadow:var(--shadow), inset 0 0 0 1px rgba(0,0,0,.4);
    transition:transform .12s ease}
  .board::after{content:''; position:absolute; inset:0; pointer-events:none; border-radius:inherit;
    box-shadow:inset 0 0 90px rgba(0,0,0,.55)}
  .board canvas{display:block; width:100%; height:100%; touch-action:none}
  .board.shake{animation:shake .32s cubic-bezier(.36,.07,.19,.97)}
  @keyframes shake{10%,90%{transform:translate(-2px,1px)}20%,80%{transform:translate(4px,-2px)}30%,50%,70%{transform:translate(-6px,2px)}40%,60%{transform:translate(6px,-1px)}}

  /* ---------- Overlays ---------- */
  .overlay{position:absolute; inset:0; display:flex; align-items:center; justify-content:center; padding:22px;
    background:radial-gradient(circle at 50% 40%, rgba(8,19,16,.55), rgba(6,14,11,.86));
    backdrop-filter:blur(3px); -webkit-backdrop-filter:blur(3px);
    opacity:0; visibility:hidden; transition:opacity .28s ease, visibility .28s}
  .overlay.show{opacity:1; visibility:visible}
  .panel{width:min(360px,100%); text-align:center; padding:clamp(20px,4vw,30px);
    background:linear-gradient(180deg, rgba(19,42,33,.96), rgba(12,26,20,.96));
    border:1px solid var(--line-strong); border-radius:18px; box-shadow:var(--shadow);
    transform:translateY(14px) scale(.97); transition:transform .32s cubic-bezier(.2,.9,.3,1.2)}
  .overlay.show .panel{transform:none}
  .panel .kicker{font-size:.72rem; letter-spacing:.28em; text-transform:uppercase; color:var(--muted-2); margin:0 0 6px}
  .panel h2{font-family:'Bungee',cursive; font-weight:400; font-size:clamp(1.7rem,4.5vw,2.3rem); margin:0 0 10px; line-height:1}
  .panel h2.win{color:var(--amber)}
  .panel p{color:var(--muted); margin:0 0 18px; font-size:.92rem; line-height:1.5}
  .panel .big{font-family:'Bungee',cursive; font-size:2.6rem; color:var(--lime); line-height:1; margin:2px 0 4px}
  .panel .sub{color:var(--muted); font-size:.85rem; margin-bottom:18px}
  .panel .sub b{color:var(--ink)}
  .keys{display:flex; flex-wrap:wrap; gap:8px; justify-content:center; margin-bottom:20px}
  .key{display:inline-flex; align-items:center; gap:7px; font-size:.78rem; color:var(--muted)}
  kbd{font-family:'Space Grotesk',sans-serif; font-size:.72rem; font-weight:600; color:var(--ink);
    background:linear-gradient(180deg,#1c3a2e,#12271f); border:1px solid var(--line-strong);
    border-bottom-width:2px; border-radius:7px; padding:4px 8px; min-width:26px; text-align:center}

  /* ---------- Buttons ---------- */
  .btn{font-family:'Space Grotesk',sans-serif; font-weight:600; font-size:.95rem; cursor:pointer;
    border:1px solid transparent; border-radius:12px; padding:12px 20px; color:#08130f;
    background:linear-gradient(180deg,var(--lime),var(--lime-2));
    box-shadow:0 10px 22px -10px rgba(182,242,74,.7); transition:transform .12s ease, box-shadow .2s ease, filter .2s}
  .btn:hover{transform:translateY(-2px); box-shadow:0 16px 30px -12px rgba(182,242,74,.8); filter:brightness(1.05)}
  .btn:active{transform:translateY(0)}
  .btn.ghost{background:transparent; color:var(--ink); border-color:var(--line-strong); box-shadow:none}
  .btn.ghost:hover{background:rgba(255,255,255,.05); border-color:var(--lime)}
  .btn-row{display:flex; gap:10px; justify-content:center; flex-wrap:wrap}

  /* ---------- Side panel ---------- */
  .side{display:flex; flex-direction:column; gap:16px}
  .card{background:linear-gradient(180deg, rgba(19,42,33,.7), rgba(12,26,20,.7));
    border:1px solid var(--line); border-radius:16px; padding:18px}
  .card h3{margin:0 0 14px; font-size:.72rem; letter-spacing:.24em; text-transform:uppercase; color:var(--muted-2); font-weight:600}
  .score-grid{display:grid; grid-template-columns:1fr 1fr; gap:12px}
  .stat{background:rgba(0,0,0,.22); border:1px solid var(--line); border-radius:12px; padding:12px 14px}
  .stat .label{font-size:.68rem; letter-spacing:.16em; text-transform:uppercase; color:var(--muted-2)}
  .stat .value{font-family:'Bungee',cursive; font-size:1.9rem; line-height:1.1; margin-top:4px; color:var(--ink)}
  .stat.score .value{color:var(--lime)}
  .stat.best .value{color:var(--amber)}
  .stat .value.pop{animation:pop .3s ease}
  @keyframes pop{0%{transform:scale(1)}40%{transform:scale(1.28)}100%{transform:scale(1)}}
  .stat.wide{grid-column:1 / -1; display:flex; align-items:center; justify-content:space-between}
  .stat.wide .value{font-size:1.4rem}
  .speedbar{height:8px; border-radius:999px; background:rgba(0,0,0,.35); overflow:hidden; margin-top:10px; border:1px solid var(--line)}
  .speedbar i{display:block; height:100%; width:0%; border-radius:999px;
    background:linear-gradient(90deg,var(--teal),var(--lime),var(--amber)); transition:width .3s ease}

  .ctrls{display:flex; flex-direction:column; gap:12px}
  .ctrl-row{display:flex; gap:10px}
  .ctrl-row .btn{flex:1; padding:11px 12px; font-size:.85rem}
  .seg{display:flex; gap:6px; background:rgba(0,0,0,.25); border:1px solid var(--line); border-radius:12px; padding:5px}
  .seg button{flex:1; border:none; background:transparent; color:var(--muted); font-family:inherit; font-weight:600;
    font-size:.82rem; padding:9px 6px; border-radius:8px; cursor:pointer; transition:.18s}
  .seg button:hover{color:var(--ink)}
  .seg button.active{background:linear-gradient(180deg,var(--lime),var(--lime-2)); color:#08130f; box-shadow:0 6px 14px -8px rgba(182,242,74,.8)}
  .toggle{display:flex; align-items:center; justify-content:space-between; gap:10px; padding:11px 14px;
    background:rgba(0,0,0,.22); border:1px solid var(--line); border-radius:12px; cursor:pointer; user-select:none}
  .toggle span{font-size:.85rem; color:var(--muted)}
  .switch{width:44px; height:24px; border-radius:999px; background:rgba(255,255,255,.12); position:relative; transition:.2s; flex:none}
  .switch::after{content:''; position:absolute; top:3px; left:3px; width:18px; height:18px; border-radius:50%; background:var(--muted); transition:.2s}
  .toggle.on .switch{background:linear-gradient(90deg,var(--lime),var(--lime-2))}
  .toggle.on .switch::after{left:23px; background:#08130f}

  .legend{display:flex; flex-direction:column; gap:10px}
  .legend .row{display:flex; align-items:center; gap:12px; font-size:.85rem; color:var(--muted)}
  .legend .row b{color:var(--ink); font-weight:600}
  .swatch{width:16px; height:16px; border-radius:5px; flex:none}
  .swatch.food{background:radial-gradient(circle at 35% 30%, #ffd07a, var(--amber)); box-shadow:0 0 10px rgba(255,194,75,.6)}
  .swatch.gold{background:radial-gradient(circle at 35% 30%, #fff0b8, var(--amber)); box-shadow:0 0 12px rgba(255,194,75,.9)}
  .swatch.snake{background:linear-gradient(180deg,var(--lime),var(--lime-2))}
  .swatch.wall{background:var(--coral); box-shadow:0 0 10px rgba(255,107,94,.5)}

  .foot{margin-top:26px; text-align:center; color:var(--muted-2); font-size:.8rem}
  .foot b{color:var(--muted)}

  /* ---------- Reveal ---------- */
  .reveal{opacity:0; transform:translateY(18px); transition:opacity .7s ease, transform .7s cubic-bezier(.2,.8,.2,1)}
  .reveal.in{opacity:1; transform:none}

  @media (prefers-reduced-motion:reduce){
    *{animation-duration:.001ms !important; transition-duration:.001ms !important}
    .reveal{opacity:1; transform:none}
  }
</style>
</head>
<body>
<div class="wrap">

  <header class="topbar reveal">
    <div class="brand">
      <svg class="logo" viewBox="0 0 64 64" aria-hidden="true">
        <rect class="seg" x="6"  y="30" width="16" height="16" rx="5"/>
        <rect class="seg" x="22" y="30" width="16" height="16" rx="5"/>
        <rect class="seg" x="38" y="30" width="16" height="16" rx="5"/>
        <circle class="eye" cx="49" cy="35" r="2.4"/>
        <path class="tongue" d="M54 38 h6 M60 38 l3 -3 M60 38 l3 3"/>
      </svg>
      <div>
        <h1>Snake<span>.</span></h1>
        <p>Grow the tail, dodge yourself, and don't hit the walls.</p>
      </div>
    </div>
    <div class="meta">
      <span class="chip"><span class="dot"></span> <b id="modeChip">Classic</b></span>
      <span class="chip">Grid <b>24×24</b></span>
      <span class="chip">Best <b id="bestChip">0</b></span>
    </div>
  </header>

  <main class="stage">
    <section class="board reveal" id="board">
      <canvas id="game"></canvas>

      <!-- Start -->
      <div class="overlay show" id="ovStart">
        <div class="panel">
          <p class="kicker">Ready when you are</p>
          <h2>Let's <span style="color:var(--lime)">slither</span></h2>
          <p>Eat the glowing fruit to grow. Every few bites a golden bonus appears — grab it before it fades.</p>
          <div class="keys">
            <span class="key"><kbd>↑</kbd><kbd>↓</kbd><kbd>←</kbd><kbd>→</kbd> move</span>
            <span class="key"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> move</span>
            <span class="key"><kbd>Space</kbd> pause</span>
          </div>
          <button class="btn" id="startBtn">Start game</button>
        </div>
      </div>

      <!-- Pause -->
      <div class="overlay" id="ovPause">
        <div class="panel">
          <p class="kicker">Take a breath</p>
          <h2>Paused</h2>
          <p>Press <kbd>Space</kbd> or <kbd>P</kbd> to resume.</p>
          <div class="btn-row">
            <button class="btn" id="resumeBtn">Resume</button>
            <button class="btn ghost" id="pauseRestart">Restart</button>
          </div>
        </div>
      </div>

      <!-- Game over -->
      <div class="overlay" id="ovOver">
        <div class="panel">
          <p class="kicker" id="overKicker">Game over</p>
          <h2 id="overTitle">You crashed</h2>
          <div class="big" id="overScore">0</div>
          <div class="sub" id="overSub">Best <b>0</b></div>
          <div class="btn-row">
            <button class="btn" id="againBtn">Play again</button>
            <button class="btn ghost" id="overMenu">Menu</button>
          </div>
        </div>
      </div>

      <!-- Win -->
      <div class="overlay" id="ovWin">
        <div class="panel">
          <p class="kicker">Perfect run</p>
          <h2 class="win">You win!</h2>
          <div class="big" id="winScore">0</div>
          <div class="sub">The board is full. Legendary.</div>
          <div class="btn-row">
            <button class="btn" id="winAgain">Play again</button>
            <button class="btn ghost" id="winMenu">Menu</button>
          </div>
        </div>
      </div>
    </section>

    <aside class="side">
      <div class="card reveal">
        <h3>Scoreboard</h3>
        <div class="score-grid">
          <div class="stat score"><div class="label">Score</div><div class="value" id="score">0</div></div>
          <div class="stat best"><div class="label">Best</div><div class="value" id="best">0</div></div>
          <div class="stat wide"><div class="label">Length</div><div class="value" id="length">3</div></div>
          <div class="stat wide"><div class="label">Speed</div><div class="value" id="speed">1</div></div>
        </div>
        <div class="speedbar"><i id="speedFill"></i></div>
      </div>

      <div class="card reveal">
        <h3>Controls</h3>
        <div class="ctrls">
          <div class="ctrl-row">
            <button class="btn" id="pauseBtn">Pause</button>
            <button class="btn ghost" id="restartBtn">Restart</button>
          </div>
          <div class="seg" id="modeSeg">
            <button data-mode="classic" class="active">Classic</button>
            <button data-mode="wrap">Wrap</button>
          </div>
          <div class="toggle on" id="soundToggle"><span>Sound effects</span><span class="switch"></span></div>
        </div>
      </div>

      <div class="card reveal">
        <h3>Legend</h3>
        <div class="legend">
          <div class="row"><span class="swatch snake"></span> <b>Snake</b> — you</div>
          <div class="row"><span class="swatch food"></span> <b>Fruit</b> — +10 &amp; grow</div>
          <div class="row"><span class="swatch gold"></span> <b>Golden</b> — +50, timed</div>
          <div class="row"><span class="swatch wall"></span> <b>Walls</b> — deadly (Classic)</div>
        </div>
      </div>
    </aside>
  </main>

  <footer class="foot reveal">Built with <b>HTML canvas</b> &amp; <b>vanilla JavaScript</b> — no libraries, no build step.</footer>
</div>

<script>
(function(){
  "use strict";

  /* ============================ Config ============================ */
  const COLS = 24, ROWS = 24;
  const BASE_INTERVAL = 130;      // ms per step at speed 1
  const MIN_INTERVAL  = 62;       // fastest step
  const SPEED_EVERY   = 4;        // grow faster every N fruits
  const GOLD_CHANCE   = 0.16;     // chance a fruit spawns as golden
  const GOLD_LIFE     = 6000;     // ms a golden fruit lingers
  const GOLD_POINTS   = 50;
  const FRUIT_POINTS  = 10;
  const DIRS = { up:{x:0,y:-1}, down:{x:0,y:1}, left:{x:-1,y:0}, right:{x:1,y:0} };

  const C = {
    bg:'#0a1712', grid:'rgba(120,200,160,.05)', gridStrong:'rgba(120,200,160,.09)',
    head:'#d6ff7a', headEdge:'#b6f24a', body:'#8fd92f', bodyEdge:'#5fae1f',
    eye:'#08130f', food:'#ffc24b', foodCore:'#fff0b8', foodGlow:'rgba(255,194,75,.55)',
    gold:'#ffd24a', goldCore:'#fff6cf', goldGlow:'rgba(255,210,74,.7)',
    wall:'#ff6b5e', text:'#eaf6ee', muted:'#8fb0a2'
  };

  /* ============================ State ============================ */
  let canvas, ctx, cell = 20, dpr = 1;
  let snake = [], dir = DIRS.right, dirQueue = [];
  let food = null, gold = null, goldTimer = 0;
  let score = 0, best = 0, fruitsEaten = 0, speedLevel = 1;
  let state = 'start';            // start | playing | paused | over | win
  let mode = 'classic';           // classic | wrap
  let soundOn = true;
  let interval = BASE_INTERVAL, acc = 0, last = 0;
  let particles = [], floaters = [];
  let shake = 0, flash = 0, flashColor = '255,107,94';
  let deathReason = '';
  let audioCtx = null;

  /* ============================ DOM ============================ */
  const $ = id => document.getElementById(id);
  const board = $('board');
  const el = {
    score:$('score'), best:$('best'), length:$('length'), speed:$('speed'), speedFill:$('speedFill'),
    bestChip:$('bestChip'), modeChip:$('modeChip'),
    ovStart:$('ovStart'), ovPause:$('ovPause'), ovOver:$('ovOver'), ovWin:$('ovWin'),
    overScore:$('overScore'), overSub:$('overSub'), overTitle:$('overTitle'), overKicker:$('overKicker'),
    winScore:$('winScore'), pauseBtn:$('pauseBtn')
  };

  /* ============================ Helpers ============================ */
  const clamp = (v,a,b) => Math.max(a, Math.min(b, v));
  const lerp  = (a,b,t) => a + (b-a)*t;
  const rand  = (a,b) => a + Math.random()*(b-a);
  const key   = (x,y) => x + ',' + y;
  const occupied = () => { const s = new Set(); for (const p of snake) s.add(key(p.x,p.y)); if (food) s.add(key(food.x,food.y)); if (gold) s.add(key(gold.x,gold.y)); return s; };

  function rr(x,y,w,h,r){
    r = Math.min(r, w/2, h/2);
    ctx.beginPath();
    ctx.moveTo(x+r,y);
    ctx.arcTo(x+w,y,x+w,y+h,r);
    ctx.arcTo(x+w,y+h,x,y+h,r);
    ctx.arcTo(x,y+h,x,y,r);
    ctx.arcTo(x,y,x+w,y,r);
    ctx.closePath();
  }

  /* ============================ Audio ============================ */
  function ensureAudio(){
    if (!audioCtx){ try { audioCtx = new (window.AudioContext||window.webkitAudioContext)(); } catch(e){} }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
  }
  function tone(freq, dur, type, vol, slideTo){
    if (!soundOn || !audioCtx) return;
    const t = audioCtx.currentTime;
    const o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol || 0.05, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(audioCtx.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }
  const sfx = {
    eat(){ tone(520, .09, 'square', .05, 760); },
    gold(){ tone(660, .1, 'triangle', .06, 990); setTimeout(()=>tone(990,.12,'triangle',.05,1320),70); },
    die(){ tone(300, .35, 'sawtooth', .07, 70); },
    ui(){ tone(420, .05, 'square', .03); }
  };

  /* ============================ Game logic ============================ */
  function reset(){
    const cx = Math.floor(COLS/2), cy = Math.floor(ROWS/2);
    snake = [{x:cx,y:cy},{x:cx-1,y:cy},{x:cx-2,y:cy}];
    dir = DIRS.right; dirQueue = [];
    food = null; gold = null; goldTimer = 0;
    score = 0; fruitsEaten = 0; speedLevel = 1; interval = BASE_INTERVAL; acc = 0;
    particles = []; floaters = []; shake = 0; flash = 0;
    spawnFood();
    updateHUD();
  }

  function spawnFood(){
    const occ = occupied();
    const free = [];
    for (let y=0;y<ROWS;y++) for (let x=0;x<COLS;x++) if (!occ.has(key(x,y))) free.push({x,y});
    if (!free.length){ win(); return; }
    const p = free[Math.floor(Math.random()*free.length)];
    food = { x:p.x, y:p.y, pulse:0 };
    if (!gold && Math.random() < GOLD_CHANCE){
      const occ2 = occupied();
      const free2 = free.filter(c => !occ2.has(key(c.x,c.y)));
      if (free2.length){ const g = free2[Math.floor(Math.random()*free2.length)]; gold = { x:g.x, y:g.y, life:GOLD_LIFE, max:GOLD_LIFE }; }
    }
  }

  function enqueueDir(d){
    const last = dirQueue.length ? dirQueue[dirQueue.length-1] : dir;
    if ((d.x === -last.x && d.y === -last.y) || (d.x === last.x && d.y === last.y)) return;
    if (dirQueue.length < 2) dirQueue.push(d);
  }

  function step(){
    if (dirQueue.length) dir = dirQueue.shift();
    const head = snake[0];
    let nx = head.x + dir.x, ny = head.y + dir.y;

    if (mode === 'wrap'){
      nx = (nx + COLS) % COLS; ny = (ny + ROWS) % ROWS;
    } else if (nx < 0 || ny < 0 || nx >= COLS || ny >= ROWS){
      return die('wall');
    }

    const willEat = food && nx === food.x && ny === food.y;
    const willGold = gold && nx === gold.x && ny === gold.y;

    // Self-collision (tail vacates this tick unless we grow)
    const tail = snake[snake.length-1];
    const tailMoves = !(willEat || willGold);
    for (let i=0;i<snake.length;i++){
      const s = snake[i];
      if (s.x === nx && s.y === ny){
        if (i === snake.length-1 && tailMoves) continue;
        return die('self');
      }
    }

    snake.unshift({x:nx, y:ny});

    if (willGold){
      score += GOLD_POINTS; gold = null; goldTimer = 0;
      burst(nx,ny,C.gold,22); floaters.push({x:nx,y:ny,text:'+'+GOLD_POINTS,color:C.gold,life:900});
      flash = 1; flashColor = '255,210,74'; sfx.gold();
    } else if (willEat){
      score += FRUIT_POINTS; fruitsEaten++;
      burst(nx,ny,C.food,14); floaters.push({x:nx,y:ny,text:'+'+FRUIT_POINTS,color:C.food,life:800});
      sfx.eat();
      if (fruitsEaten % SPEED_EVERY === 0){ speedLevel++; interval = Math.max(MIN_INTERVAL, BASE_INTERVAL - (speedLevel-1)*8); }
      spawnFood();
    } else {
      snake.pop();
    }
    updateHUD();
  }

  function die(reason){
    state = 'over'; deathReason = reason;
    shake = 1; flash = 1; flashColor = '255,107,94';
    burst(snake[0].x, snake[0].y, C.wall, 26);
    sfx.die();
    if (score > best){ best = score; try{ localStorage.setItem('snake_best', best); }catch(e){} }
    el.overScore.textContent = score;
    el.overSub.innerHTML = 'Best <b>' + best + '</b>';
    el.overTitle.textContent = reason === 'wall' ? 'Hit the wall' : 'Bit yourself';
    el.overKicker.textContent = score >= best && score > 0 ? 'New best!' : 'Game over';
    showOverlay(el.ovOver);
    updateHUD();
  }

  function win(){
    state = 'win';
    if (score > best){ best = score; try{ localStorage.setItem('snake_best', best); }catch(e){} }
    el.winScore.textContent = score;
    showOverlay(el.ovWin);
    updateHUD();
  }

  /* ============================ Particles ============================ */
  function burst(gx,gy,color,n){
    const cx = (gx+0.5)*cell, cy = (gy+0.5)*cell;
    for (let i=0;i<n;i++){
      const a = Math.random()*Math.PI*2, sp = rand(40,180);
      particles.push({ x:cx, y:cy, vx:Math.cos(a)*sp, vy:Math.sin(a)*sp, life:rand(300,650), max:650, size:rand(2,5), color });
    }
  }

  /* ============================ HUD ============================ */
  function updateHUD(){
    el.score.textContent = score;
    el.best.textContent = best;
    el.bestChip.textContent = best;
    el.length.textContent = snake.length;
    el.speed.textContent = speedLevel;
    const pct = clamp((BASE_INTERVAL - interval) / (BASE_INTERVAL - MIN_INTERVAL), 0, 1);
    el.speedFill.style.width = (pct*100).toFixed(0) + '%';
  }
  function popScore(){ el.score.classList.remove('pop'); void el.score.offsetWidth; el.score.classList.add('pop'); }

  /* ============================ Overlays ============================ */
  function showOverlay(node){ [el.ovStart,el.ovPause,el.ovOver,el.ovWin].forEach(o=>o.classList.toggle('show', o===node)); }
  function hideOverlays(){ [el.ovStart,el.ovPause,el.ovOver,el.ovWin].forEach(o=>o.classList.remove('show')); }

  function startGame(){ ensureAudio(); reset(); state = 'playing'; hideOverlays(); }
  function togglePause(){
    if (state === 'playing'){ state = 'paused'; showOverlay(el.ovPause); }
    else if (state === 'paused'){ state = 'playing'; hideOverlays(); }
  }
  function toMenu(){ state = 'start'; reset(); showOverlay(el.ovStart); }

  /* ============================ Rendering ============================ */
  function drawGrid(){
    ctx.lineWidth = 1;
    for (let x=1;x<COLS;x++){ ctx.strokeStyle = (x%4===0)?C.gridStrong:C.grid; ctx.beginPath(); ctx.moveTo(x*cell+.5,0); ctx.lineTo(x*cell+.5,ROWS*cell); ctx.stroke(); }
    for (let y=1;y<ROWS;y++){ ctx.strokeStyle = (y%4===0)?C.gridStrong:C.grid; ctx.beginPath(); ctx.moveTo(0,y*cell+.5); ctx.lineTo(COLS*cell,y*cell+.5); ctx.stroke(); }
  }

  function drawWalls(){
    if (mode !== 'classic') return;
    const t = Math.max(3, cell*0.28);
    ctx.save();
    ctx.shadowColor = C.wall; ctx.shadowBlur = 14;
    ctx.fillStyle = 'rgba(255,107,94,.16)';
    ctx.fillRect(0,0,COLS*cell,t); ctx.fillRect(0,ROWS*cell-t,COLS*cell,t);
    ctx.fillRect(0,0,t,ROWS*cell); ctx.fillRect(COLS*cell-t,0,t,ROWS*cell);
    ctx.restore();
  }

  function drawFood(){
    if (!food) return;
    const cx = (food.x+0.5)*cell, cy = (food.y+0.5)*cell;
    const pulse = 1 + Math.sin(food.pulse)*0.12;
    const r = cell*0.34*pulse;
    ctx.save();
    ctx.shadowColor = C.foodGlow; ctx.shadowBlur = 16;
    const g = ctx.createRadialGradient(cx-r*0.3, cy-r*0.3, r*0.1, cx, cy, r);
    g.addColorStop(0, C.foodCore); g.addColorStop(1, C.food);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fill();
    ctx.restore();
    ctx.fillStyle = 'rgba(255,255,255,.5)';
    ctx.beginPath(); ctx.arc(cx-r*0.32, cy-r*0.32, r*0.22, 0, Math.PI*2); ctx.fill();
  }

  function drawGold(){
    if (!gold) return;
    const cx = (gold.x+0.5)*cell, cy = (gold.y+0.5)*cell;
    const frac = gold.life / gold.max;
    const blink = frac < 0.35 ? (Math.sin(gold.life/60) > 0 ? 1 : 0.35) : 1;
    const r = cell*0.36;
    ctx.save();
    ctx.globalAlpha = blink;
    ctx.shadowColor = C.goldGlow; ctx.shadowBlur = 20;
    const g = ctx.createRadialGradient(cx-r*0.3, cy-r*0.3, r*0.1, cx, cy, r);
    g.addColorStop(0, C.goldCore); g.addColorStop(1, C.gold);
    ctx.fillStyle = g;
    ctx.beginPath();
    for (let i=0;i<5;i++){
      const a = -Math.PI/2 + i*(Math.PI*2/5);
      const a2 = a + Math.PI/5;
      ctx.lineTo(cx+Math.cos(a)*r, cy+Math.sin(a)*r);
      ctx.lineTo(cx+Math.cos(a2)*r*0.45, cy+Math.sin(a2)*r*0.45);
    }
    ctx.closePath(); ctx.fill();
    ctx.restore();
    // life ring
    ctx.save();
    ctx.strokeStyle = 'rgba(255,210,74,.85)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(cx, cy, cell*0.46, -Math.PI/2, -Math.PI/2 + Math.PI*2*frac); ctx.stroke();
    ctx.restore();
  }

  function drawSnake(){
    const n = snake.length;
    const pad = cell*0.10, r = cell*0.30;
    for (let i=n-1;i>=0;i--){
      const s = snake[i];
      const t = n>1 ? i/(n-1) : 0;
      const col = i===0 ? C.head : `rgb(${Math.round(lerp(143,95,t))},${Math.round(lerp(217,150,t))},${Math.round(lerp(47,31,t))})`;
      ctx.save();
      if (i===0){ ctx.shadowColor = 'rgba(182,242,74,.55)'; ctx.shadowBlur = 12; }
      ctx.fillStyle = col;
      rr(s.x*cell+pad, s.y*cell+pad, cell-2*pad, cell-2*pad, r);
      ctx.fill();
      ctx.restore();
      if (i===0) drawEyes(s);
    }
  }

  function drawEyes(head){
    const cx = (head.x+0.5)*cell, cy = (head.y+0.5)*cell;
    const f = dir, px = -f.y, py = f.x;
    const fwd = cell*0.16, side = cell*0.17, er = cell*0.11;
    for (const s of [-1,1]){
      const ex = cx + f.x*fwd + px*side*s, ey = cy + f.y*fwd + py*side*s;
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ex,ey,er,0,Math.PI*2); ctx.fill();
      ctx.fillStyle = C.eye; ctx.beginPath(); ctx.arc(ex+f.x*er*0.4, ey+f.y*er*0.4, er*0.55, 0, Math.PI*2); ctx.fill();
    }
  }

  function drawParticles(dt){
    for (let i=particles.length-1;i>=0;i--){
      const p = particles[i];
      p.life -= dt;
      if (p.life <= 0){ particles.splice(i,1); continue; }
      p.x += p.vx*dt/1000; p.y += p.vy*dt/1000;
      p.vx *= 0.92; p.vy *= 0.92;
      ctx.globalAlpha = clamp(p.life/p.max,0,1);
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x-p.size/2, p.y-p.size/2, p.size, p.size);
    }
    ctx.globalAlpha = 1;
  }

  function drawFloaters(dt){
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.font = `700 ${Math.round(cell*0.7)}px 'Space Grotesk', sans-serif`;
    for (let i=floaters.length-1;i>=0;i--){
      const f = floaters[i];
      f.life -= dt;
      if (f.life <= 0){ floaters.splice(i,1); continue; }
      const a = clamp(f.life/800,0,1);
      const y = (f.y+0.5)*cell - (1 - f.life/800)*cell*0.9;
      ctx.globalAlpha = a;
      ctx.fillStyle = f.color;
      ctx.fillText(f.text, (f.x+0.5)*cell, y);
    }
    ctx.globalAlpha = 1;
  }

  function render(dt){
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,canvas.width/dpr,canvas.height/dpr);
    ctx.fillStyle = C.bg; ctx.fillRect(0,0,canvas.width/dpr,canvas.height/dpr);

    ctx.save();
    if (shake > 0){ ctx.translate(rand(-1,1)*shake*7, rand(-1,1)*shake*7); }
    drawGrid();
    drawWalls();
    drawFood();
    drawGold();
    drawSnake();
    drawParticles(dt);
    drawFloaters(dt);
    ctx.restore();

    if (flash > 0){
      ctx.fillStyle = `rgba(${flashColor},${flash*0.35})`;
      ctx.fillRect(0,0,canvas.width/dpr,canvas.height/dpr);
    }
  }

  /* ============================ Loop ============================ */
  function update(dt){
    if (state === 'playing'){
      acc += dt;
      let guard = 0;
      while (acc >= interval && state === 'playing' && guard++ < 5){ step(); acc -= interval; }
      if (gold){ goldTimer += dt; if (goldTimer >= gold.life){ gold = null; goldTimer = 0; } }
      if (food) food.pulse += dt/180;
    }
    if (shake > 0) shake = Math.max(0, shake - dt/220);
    if (flash > 0) flash = Math.max(0, flash - dt/260);
  }

  function frame(now){
    const dt = Math.min(50, now - last); last = now;
    update(dt);
    render(dt);
    requestAnimationFrame(frame);
  }

  /* ============================ Resize ============================ */
  function resize(){
    const rect = board.getBoundingClientRect();
    const size = Math.max(1, Math.floor(Math.min(rect.width, rect.height)));
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size*dpr; canvas.height = size*dpr;
    canvas.style.width = size+'px'; canvas.style.height = size+'px';
    cell = size / COLS;
  }

  /* ============================ Input ============================ */
  function bind(){
    window.addEventListener('keydown', e=>{
      const k = e.key.toLowerCase();
      const dirMap = { arrowup:'up', w:'up', arrowdown:'down', s:'down', arrowleft:'left', a:'left', arrowright:'right', d:'right' };
      if (dirMap[k]){
        e.preventDefault();
        if (state === 'start'){ startGame(); }
        if (state === 'playing') enqueueDir(DIRS[dirMap[k]]);
        return;
      }
      if (k === ' ' || k === 'spacebar'){ e.preventDefault(); if (state==='playing'||state==='paused') togglePause(); else if (state==='start') startGame(); }
      else if (k === 'p'){ if (state==='playing'||state==='paused') togglePause(); }
      else if (k === 'enter'){ if (state==='over'||state==='win'||state==='start') startGame(); }
      else if (k === 'r'){ if (state!=='start') startGame(); }
    });

    // Buttons
    $('startBtn').onclick = ()=>{ sfx.ui(); startGame(); };
    $('resumeBtn').onclick = ()=>{ sfx.ui(); togglePause(); };
    $('pauseRestart').onclick = ()=>{ sfx.ui(); startGame(); };
    $('againBtn').onclick = ()=>{ sfx.ui(); startGame(); };
    $('overMenu').onclick = ()=>{ sfx.ui(); toMenu(); };
    $('winAgain').onclick = ()=>{ sfx.ui(); startGame(); };
    $('winMenu').onclick = ()=>{ sfx.ui(); toMenu(); };
    el.pauseBtn.onclick = ()=>{ sfx.ui(); if (state==='playing'||state==='paused') togglePause(); };
    $('restartBtn').onclick = ()=>{ sfx.ui(); startGame(); };

    // Mode segmented control
    document.querySelectorAll('#modeSeg button').forEach(b=>{
      b.onclick = ()=>{
        mode = b.dataset.mode;
        document.querySelectorAll('#modeSeg button').forEach(x=>x.classList.toggle('active', x===b));
        el.modeChip.textContent = mode === 'wrap' ? 'Wrap' : 'Classic';
        sfx.ui();
        if (state === 'playing' || state === 'paused'){ reset(); state = 'playing'; hideOverlays(); }
      };
    });

    // Sound toggle
    $('soundToggle').onclick = function(){
      soundOn = !soundOn;
      this.classList.toggle('on', soundOn);
      if (soundOn){ ensureAudio(); sfx.ui(); }
    };

    // Touch / swipe
    let tsx=0, tsy=0, swiping=false;
    canvas.addEventListener('touchstart', e=>{ const t=e.touches[0]; tsx=t.clientX; tsy=t.clientY; swiping=true; }, {passive:true});
    canvas.addEventListener('touchmove', e=>{
      if (!swiping) return;
      const t=e.touches[0], dx=t.clientX-tsx, dy=t.clientY-tsy;
      if (Math.abs(dx) < 24 && Math.abs(dy) < 24) return;
      if (state === 'start'){ startGame(); }
      if (state === 'playing'){
        if (Math.abs(dx) > Math.abs(dy)) enqueueDir(dx>0?DIRS.right:DIRS.left);
        else enqueueDir(dy>0?DIRS.down:DIRS.up);
      }
      tsx=t.clientX; tsy=t.clientY;
    }, {passive:true});
    canvas.addEventListener('touchend', ()=>{ swiping=false; });

    // Score pop on eat
    const origEat = sfx.eat;
    sfx.eat = function(){ origEat(); popScore(); };

    // Pause when tab hidden
    document.addEventListener('visibilitychange', ()=>{ if (document.hidden && state==='playing') togglePause(); });

    // Reveal on scroll
    const io = new IntersectionObserver(entries=>{
      entries.forEach(en=>{ if (en.isIntersecting){ en.target.classList.add('in'); io.unobserve(en.target); } });
    }, { threshold:0.12 });
    document.querySelectorAll('.reveal').forEach(n=>io.observe(n));
  }

  /* ============================ Init ============================ */
  function init(){
    canvas = $('game'); ctx = canvas.getContext('2d');
    try { best = parseInt(localStorage.getItem('snake_best')||'0',10) || 0; } catch(e){ best = 0; }
    resize();
    reset();
    bind();
    last = performance.now();
    requestAnimationFrame(frame);
    if (window.ResizeObserver) new ResizeObserver(resize).observe(board);
    window.addEventListener('resize', resize);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
</script>
</body>
</html>
```

## Main design choices

**Fixed-timestep logic, free-running render.** The game runs on `requestAnimationFrame` for smooth animation, but movement is driven by an accumulator (`acc += dt; while (acc >= interval) step()`). This decouples the snake's grid speed from the display refresh rate, so it behaves identically on 60 Hz and 144 Hz screens, and the difficulty ramp is just a shrinking `interval`. A small guard cap prevents a "spiral of death" if the tab stalls.

**Grid + interpolation-free rendering.** The snake lives as integer cells; drawing rounds each segment to a rounded rect with a head-to-tail color gradient and directional eyes. Keeping logic on the grid makes collision trivial and predictable, while the pulsing fruit, particle bursts, floating score text, screen shake, and death flash supply the "alive" feel on top of a crisp board.

**Input queue with anti-reversal.** Key presses push into a 2-deep queue and reject reversals and duplicates. This fixes the classic bug where two fast turns in one tick let you fold into yourself, and it makes quick direction changes feel responsive.

**Correct tail-vacancy collision.** When the snake moves without eating, the tail cell frees up that same tick, so moving into the old tail position is legal. The collision check explicitly allows that case (`i === last && tailMoves`) — a subtle rule that feels fair and matches player intuition.

**Two modes, one code path.** `classic` (deadly walls) and `wrap` (toroidal) share all logic; only the boundary branch in `step()` differs. The wall glow and the mode chip update live, and switching mid-game cleanly restarts.

**Layered scoring + a timed bonus.** Base fruit is +10 with a speed-up every 4 bites; a golden star occasionally spawns with a shrinking life ring and is worth +50, adding a risk/reward decision without complicating the core loop.

**State machine for overlays.** `start / playing / paused / over / win` are explicit states, so pause, restart, keyboard shortcuts (Space/P, Enter, R), and the visibility-change auto-pause all route through the same transitions instead of scattered flags.

**Persistence, audio, and polish.** Best score persists via `localStorage` (wrapped in try/catch for sandboxed contexts). Sound is synthesized with the Web Audio API (no assets), created lazily on first interaction to respect autoplay policies, and fully mutable. Everything is DPR-aware and resizes via `ResizeObserver`, and `prefers-reduced-motion` disables the decorative animations.