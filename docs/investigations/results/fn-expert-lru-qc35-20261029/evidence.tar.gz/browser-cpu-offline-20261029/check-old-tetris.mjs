import { readFile, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
import { openBrowser } from './cdp.mjs';

const root='/tmp/hipfire-qc-browser-20261029';
const result={artifact:'old-tetris-original.html',provenance:JSON.parse(await readFile(`${root}/old-tetris-source-review.json`,'utf8')),
  evidence:'Offline checks of original generated output; not gold or an inference-engine correctness verdict.',
  method:'Original byte-identical HTML at file://; external optional fonts blocked. No algorithm, canvas method, state, score or initialization is patched.',checks:[],
  limits:['Boot/start failure prevents core gameplay tests. Not-run checks are BLOCKED, not independent failures.',
    'Static canHold rearm concern is not runtime-qualified because original boot fails.']};
let b;
try {
 b=await openBrowser();
 await b.loadReviewedHtml(`${root}/old-tetris-original.html`);
 await delay(100);
 result.origin=await b.evaluate(`({href:location.href,origin:location.origin,localStorageAvailable:(()=>{try{localStorage.setItem('qc_probe','1');localStorage.removeItem('qc_probe');return true;}catch(e){return String(e);}})()})`);
 result.boot_errors=structuredClone(b.errors);
 result.initial=await b.evaluate(`({state,current,gridRows:grid.length,gridCols:grid[0].length,score,lines,level,overlayVisible:el.overlay.classList.contains('show'),board:{width:boardCanvas.width,height:boardCanvas.height},canvasClearRectType:typeof holdCanvas.clearRect,contextClearRectType:typeof holdCtx.clearRect})`);
 result.checks.push({name:'inline_js_syntax',status:result.provenance.node_check.every(c=>c.exit_code===0)?'PASS':'FAIL'});
 result.checks.push({name:'file_origin_localstorage_available',status:result.origin.localStorageAvailable===true?'PASS':'FAIL',evidence:result.origin});
 result.checks.push({name:'boot_without_uncaught_exception',status:b.errors.length===0?'PASS':'FAIL',evidence:result.boot_errors});
 await b.keyPress('Enter','Enter',13,0);
 await delay(100);
 result.after_enter=await b.evaluate('({state,current,score,lines,level})');
 result.start_errors=b.errors.slice(result.boot_errors.length);
 result.checks.push({name:'start_via_enter',status:result.after_enter.state==='playing'&&result.after_enter.current&&result.start_errors.length===0?'PASS':'FAIL',evidence:{after:result.after_enter,errors:result.start_errors}});
 if(result.after_enter.state!=='playing'||!result.after_enter.current){
  for(const name of ['movement','rotation_and_wall_collision','soft_drop','hard_drop_lock','line_clear_and_score','pause_resume','game_over','restart','hold_once_per_piece'])
   result.checks.push({name,status:'BLOCKED',reason:'Original boot/start throws in drawMini; no valid current piece or active game loop. No repair/bypass applied.'});
 }
 const screenshot=await b.send('Page.captureScreenshot',{format:'png'});
 await writeFile(`${root}/old-tetris-load.png`,Buffer.from(screenshot.data,'base64'));
 result.screenshot='old-tetris-load.png';
 result.root_cause='drawMini receives an HTMLCanvasElement from renderHold/renderNext, then invokes c.clearRect. HTMLCanvasElement has no clearRect; the 2D context does. Boot reset -> renderHold -> drawMini throws before resize/showOverlay/requestAnimationFrame; Enter -> startGame -> reset repeats the same exception.';
}catch(e){result.harness_failure={error:String(e),stack:e.stack};}
finally{
 result.errors=b?.errors??[];result.console_errors=b?.consoleErrors??[];result.network_failures=b?.networkFailures??[];
 result.counts={pass:result.checks.filter(c=>c.status==='PASS').length,fail:result.checks.filter(c=>c.status==='FAIL').length,blocked:result.checks.filter(c=>c.status==='BLOCKED').length};
 result.finished_utc=new Date().toISOString();await b?.close();
 await writeFile(`${root}/old-tetris-functional.json`,JSON.stringify(result,null,2)+'\n');
 console.log(JSON.stringify(result,null,2));
 process.exitCode=result.harness_failure?2:result.counts.fail?1:0;
}
