Local offline browser helper (Node 24 builtin WebSocket + Chromium 153).

Run the agent-authored infrastructure selftest:
  /usr/bin/node /tmp/hipfire-qc-browser-20261029/selftest.mjs

After manually reviewing a generated HTML artifact, a small game-specific driver may:
  import { openBrowser } from './cdp.mjs';
  const b = await openBrowser();
  try {
    await b.loadReviewedHtml('/absolute/path/reviewed-original.html');
    console.log(await b.evaluate('document.body.innerText'));
    await b.keyPress('ArrowLeft', 'ArrowLeft', 37);
    // Assert actual original state/DOM/canvas observations here.
    console.log(b.errors, b.consoleErrors, b.networkFailures);
  } finally { await b.close(); }

Every run uses a separate temporary Chromium profile, headless mode, and disabled GPU.
Reviewed original HTML is opened through file://, matching a standalone HTML file and
avoiding about:blank's opaque-origin localStorage restrictions.
Page HTTP/HTTPS URLs are blocked through CDP. A dead localhost proxy (including
loopback destinations) and DNS failure rule also apply to browser network traffic;
Node's localhost DevTools control connection remains available. Downloads are denied.
The selftest confirms an HTTP request fails with CDP's inspector block and a WebSocket
fails at the dead proxy; both controlled endpoints receive zero requests. WS/WSS URL
patterns are also requested from CDP, but this helper does not rely on CDP intercepting
the WebSocket handshake.

Limits: this is not an OS security sandbox or a universal malicious-code verifier.
Generated code must be reviewed first. Offline blocking intentionally makes external
assets/APIs unavailable. An absence of JS errors is only a smoke observation, not proof
of gameplay, collision, scoring, restart, win/loss, or fidelity to the original prompt.
Game checks must use the actual artifact's observable state and report unreachable or
ambiguous assertions explicitly. Headless keyboard input does not prove human usability,
render quality, or physical GPU behavior. Private closure state may be inaccessible;
tests must not invent a game state API or silently rewrite the implementation to inspect it.
No model/remote GPU/product/PR is touched.
