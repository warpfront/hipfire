
"use strict";
/* ============================================================
   TETRIS — single-file implementation
   ============================================================ */

/* ---------- constants ---------- */
const COLS = 10, ROWS = 20, CELL = 30;
const LOCK_DELAY = 500, MAX_LOCK_RESETS = 15;
const DAS = 150, ARR = 40, SOFT_DROP_MS = 45, CLEAR_MS = 380;
const NEXT_COUNT = 5;

const COLORS = {
  I:'#22d3ee', O:'#fbbf24', T:'#a855f7', S:'#34d399',
  Z:'#f43f5e', J:'#3b82f6', L:'#fb923c'
};
const CLEAR_NAMES = ['','Single','Double','Triple','TETRIS!'];

/* Tetromino shapes per rotation state (0..3). Each is a list of [x,y] cells. */
const SHAPES = {
  I:[[[0,1],[1,1],[2,1],[3,1]],[[2,0],[2,1],[2,2],[2,3]],[[0,2],[1,2],[2,2],[3,2]],[[1,0],[1,1],[1,2],[1,3]]],
  O:[[[1,0],[2,0],[1,1],[2,1]],[[1,0],[2,0],[1,1],[2,1]],[[1,0],[2,0],[1,1],[2,1]],[[1,0],[2,0],[1,1],[2,1]]],
  T:[[[1,0],[0,1],[1,1],[2,1]],[[1,0],[1,1],[2,1],[1,2]],[[0,1],[1,1],[2,1],[1,2]],[[1,0],[0,1],[1,1],[1,2]]],
  S:[[[1,0],[2,0],[0,1],[1,1]],[[1,0],[1,1],[2,1],[2,2]],[[1,1],[2,1],[0,2],[1,2]],[[0,0],[0,1],[1,1],[1,2]]],
  Z:[[[0,0],[1,0],[1,1],[2,1]],[[2,0],[1,1],[2,1],[1,2]],[[0,1],[1,1],[1,2],[2,2]],[[1,0],[0,1],[1,1],[0,2]]],
  J:[[[0,0],[0,1],[1,1],[2,1]],[[1,0],[2,0],[1,1],[1,2]],[[0,1],[1,1],[2,1],[2,2]],[[1,0],[1,1],[0,2],[1,2]]],
  L:[[[2,0],[0,1],[1,1],[2,1]],[[1,0],[1,1],[1,2],[2,2]],[[0,1],[1,1],[2,1],[0,2]],[[0,0],[1,0],[1,1],[1,2]]]
};
/* SRS wall-kick tables (offsets tried in order). */
const KICKS_JLSTZ = {
  '0>1':[[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],
  '1>0':[[0,0],[1,0],[1,1],[0,-2],[1,-2]],
  '1>2':[[0,0],[1,0],[1,1],[0,-2],[1,-2]],
  '2>1':[[0,0],[-1,0],[-1,-1],[0,2],[-1,2]],
  '2>3':[[0,0],[1,0],[1,-1],[0,2],[1,2]],
  '3>2':[[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
  '3>0':[[0,0],[-1,0],[-1,1],[0,-2],[-1,-2]],
  '0>3':[[0,0],[1,0],[1,-1],[0,2],[1,2]]
};
const KICKS_I = {
  '0>1':[[0,0],[-2,0],[1,0],[-2,1],[1,-2]],
  '1>0':[[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
  '1>2':[[0,0],[-1,0],[2,0],[-1,-2],[2,1]],
  '2>1':[[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
  '2>3':[[0,0],[2,0],[-1,0],[2,-1],[-1,2]],
  '3>2':[[0,0],[-2,0],[1,0],[-2,1],[1,-2]],
  '3>0':[[0,0],[1,0],[-2,0],[1,2],[-2,-1]],
  '0>3':[[0,0],[-1,0],[2,0],[-1,-2],[2,1]]
};

/* ---------- DOM ---------- */
const boardCanvas = document.getElementById('board');
const ctx = boardCanvas.getContext('2d');
const holdCanvas = document.getElementById('hold');
const holdCtx = holdCanvas.getContext('2d');
const nextCanvases = [];
const nextSlots = document.getElementById('nextSlots');
for (let i=0;i<NEXT_COUNT;i++){
  const slot = document.createElement('div'); slot.className='slot';
  const c = document.createElement('canvas');
  const tag = document.createElement('span'); tag.className='tag';
  tag.textContent = i===0 ? 'NEXT' : '·'+i;
  slot.append(c, tag); nextSlots.append(slot);
  nextCanvases.push(c);
}
const el = {
  score:document.getElementById('score'), best:document.getElementById('best'),
  bestChip:document.getElementById('bestChip'), level:document.getElementById('level'),
  levelChip:document.getElementById('levelChip'), lines:document.getElementById('lines'),
  linesChip:document.getElementById('linesChip'), time:document.getElementById('time'),
  clears:document.getElementById('clears'), lastclear:document.getElementById('lastclear'),
  overlay:document.getElementById('overlay'), ovTitle:document.getElementById('ovTitle'),
  ovText:document.getElementById('ovText'), ovScore:document.getElementById('ovScore'),
  ovBtn:document.getElementById('ovBtn'), pauseBtn:document.getElementById('pauseBtn'),
  restartBtn:document.getElementById('restartBtn'), boardWrap:document.getElementById('boardWrap')
};

/* ---------- state ---------- */
let grid, current, holdType, canHold, bag, queue;
let score, lines, level, clears, best;
let state = 'start';           // start | playing | paused | clearing | gameover
let dropInterval, dropTimer, lockTimer, lockResets, lockActive;
let clearingRows = [], clearTimer = 0, clearFlash = 0;
let particles = [];
let elapsed = 0, lastTime = 0;
let keys = {left:false,right:false,down:false};
let dasTimer = 0, dasDir = 0, arrTimer = 0;

/* ---------- helpers ---------- */
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
function hexToRgb(h){h=h.replace('#','');return{r:parseInt(h.slice(0,2),16),g:parseInt(h.slice(2,4),16),b:parseInt(h.slice(4,6),16)};}
function shade(hex,amt){const c=hexToRgb(hex);const f=amt<0?0:255;const p=Math.abs(amt);
  return `rgb(${Math.round(c.r+(f-c.r)*p)},${Math.round(c.g+(f-c.g)*p)},${Math.round(c.b+(f-c.b)*p)})`;}
function roundRect(c,x,y,w,h,r){c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);
  c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath();}

/* ---------- canvas sizing ---------- */
function setupCanvas(canvas, cssW, cssH){
  const dpr = Math.min(window.devicePixelRatio||1, 2);
  canvas.width = Math.round(cssW*dpr); canvas.height = Math.round(cssH*dpr);
  const c = canvas.getContext('2d'); c.setTransform(dpr,0,0,dpr,0,0);
  canvas._cssW = cssW; canvas._cssH = cssH;
}
function resize(){
  const rect = boardCanvas.getBoundingClientRect();
  setupCanvas(boardCanvas, rect.width, rect.height);
  const hr = holdCanvas.getBoundingClientRect();
  setupCanvas(holdCanvas, hr.width, hr.height);
  nextCanvases.forEach(c=>{const r=c.getBoundingClientRect(); setupCanvas(c, r.width, r.height);});
}

/* ---------- 7-bag randomizer ---------- */
function refillBag(){
  const types = ['I','O','T','S','Z','J','L'];
  for (let i=types.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[types[i],types[j]]=[types[j],types[i]];}
  bag.push(...types);
}
function nextType(){ if(bag.length<7) refillBag(); return bag.shift(); }
function ensureQueue(){ while(queue.length < NEXT_COUNT+1) queue.push(nextType()); }

/* ---------- piece ---------- */
function makePiece(type){
  return { type, rot:0, x:3, y:(type==='I'?-1:0) };
}
function cellsOf(p){ return SHAPES[p.type][p.rot]; }
function collides(p, dx, dy, rot){
  const cells = SHAPES[p.type][rot];
  for (const [cx,cy] of cells){
    const x = p.x+dx+cx, y = p.y+dy+cy;
    if (x<0 || x>=COLS || y>=ROWS) return true;
    if (y>=0 && grid[y][x]) return true;
  }
  return false;
}
function spawn(){
  ensureQueue();
  const type = queue.shift(); ensureQueue();
  current = makePiece(type);
  lockTimer = 0; lockResets = 0; lockActive = false;
  if (collides(current,0,0,current.rot)) gameOver();
  renderNext();
}
function move(dx){
  if (state!=='playing') return;
  if (!collides(current,dx,0,current.rot)){ current.x+=dx; resetLock(); }
}
function rotate(dir){
  if (state!=='playing') return;
  const from = current.rot, to = (from+dir+4)%4;
  const table = current.type==='I' ? KICKS_I : KICKS_JLSTZ;
  const kicks = table[from+'>'+to];
  for (const [kx,ky] of kicks){
    if (!collides(current,kx,-ky,to)){ current.x+=kx; current.y-=ky; current.rot=to; resetLock(); return; }
  }
}
function softDrop(){
  if (state!=='playing') return;
  if (!collides(current,0,1,current.rot)){ current.y++; score+=1; dropTimer=0; resetLock(); }
  else { lockTimer = LOCK_DELAY; lockActive = true; }
}
function hardDrop(){
  if (state!=='playing') return;
  let d=0; while(!collides(current,0,d+1,current.rot)) d++;
  current.y += d; score += d*2; lockPiece();
}
function resetLock(){
  if (lockActive && lockResets < MAX_LOCK_RESETS){ lockTimer = 0; lockResets++; }
}
function lockPiece(){
  for (const [cx,cy] of cellsOf(current)){
    const x=current.x+cx, y=current.y+cy;
    if (y>=0 && y<ROWS && x>=0 && x<COLS) grid[y][x]=current.type;
  }
  current = null;
  const full=[]; for(let r=0;r<ROWS;r++) if(grid[r].every(c=>c)) full.push(r);
  if (full.length){ startClear(full); }
  else { spawn(); }
}
function startClear(rows){
  clearingRows = rows; clearTimer = CLEAR_MS; clearFlash = 0; state='clearing';
  const n = rows.length;
  score += [0,100,300,500,800][n] * level;
  lines += n; clears++;
  level = Math.floor(lines/10)+1;
  dropInterval = Math.max(70, 1000 - (level-1)*80);
  el.lastclear.textContent = CLEAR_NAMES[n];
  if (n===4) shake();
  spawnParticles(rows);
  updateHUD();
}
function finishClear(){
  for (const r of clearingRows){ grid.splice(r,1); grid.unshift(new Array(COLS).fill(null)); }
  clearingRows = []; state='playing'; spawn();
}
function hold(){
  if (state!=='playing' || !canHold) return;
  const cur = current.type;
  if (holdType){ const t=holdType; holdType=cur; current=makePiece(t); }
  else { holdType=cur; spawn(); }
  canHold=false; lockTimer=0; lockResets=0; lockActive=false;
  renderHold();
}
function gameOver(){
  state='gameover';
  if (score>best){ best=score; localStorage.setItem('tetris.best', best); }
  updateHUD();
  showOverlay('GAME OVER', 'The stack reached the top.', true);
}

/* ---------- particles ---------- */
function spawnParticles(rows){
  const colors = rows.map(r=>{
    const set=new Set(grid[r].filter(Boolean));
    return set.size? [...set][Math.floor(Math.random()*set.size)] : '#fff';
  });
  for (const r of rows){
    for (let x=0;x<COLS;x++){
      const col = COLORS[grid[r][x]] || '#fff';
      for (let k=0;k<2;k++){
        particles.push({
          x:(x+0.5)*CELL, y:(r+0.5)*CELL,
          vx:(Math.random()-0.5)*160, vy:-Math.random()*180-40,
          life:1, size:CELL*(0.18+Math.random()*0.22), color:col
        });
      }
    }
  }
  if (particles.length>420) particles.splice(0, particles.length-420);
}
function updateParticles(dt){
  for (let i=particles.length-1;i>=0;i--){
    const p=particles[i];
    p.vy += 620*dt; p.x += p.vx*dt; p.y += p.vy*dt; p.life -= dt*1.6;
    if (p.life<=0) particles.splice(i,1);
  }
}
function drawParticles(){
  for (const p of particles){
    ctx.globalAlpha = Math.max(0,p.life);
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x-p.size/2, p.y-p.size/2, p.size, p.size);
  }
  ctx.globalAlpha = 1;
}

/* ---------- drawing ---------- */
function drawBlock(c, x, y, size, color, opts={}){
  const pad = Math.max(1, size*0.06);
  const bx=x+pad, by=y+pad, bw=size-pad*2, bh=size-pad*2, r=Math.max(2,size*0.16);
  const g=c.createLinearGradient(bx,by,bx,by+bh);
  g.addColorStop(0, shade(color,0.30)); g.addColorStop(0.5,color); g.addColorStop(1, shade(color,-0.22));
  c.fillStyle=g; roundRect(c,bx,by,bw,bh,r); c.fill();
  c.fillStyle='rgba(255,255,255,0.22)'; roundRect(c,bx+1,by+1,bw-2,bh*0.34,r*0.8); c.fill();
  c.strokeStyle='rgba(0,0,0,0.35)'; c.lineWidth=1; roundRect(c,bx+0.5,by+0.5,bw-1,bh-1,r); c.stroke();
  if (opts.glow){ c.save(); c.shadowColor=color; c.shadowBlur=size*0.5; c.fillStyle=color;
    roundRect(c,bx,by,bw,bh,r); c.fill(); c.restore(); }
  if (opts.alpha!=null){ c.globalAlpha=opts.alpha; c.fillStyle='#fff'; roundRect(c,bx,by,bw,bh,r); c.fill(); c.globalAlpha=1; }
}
function drawGrid(){
  const w=boardCanvas._cssW, h=boardCanvas._cssH;
  ctx.clearRect(0,0,w,h);
  ctx.fillStyle='#0a1120'; ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='rgba(120,150,210,0.06)'; ctx.lineWidth=1;
  for (let x=1;x<COLS;x++){ ctx.beginPath(); ctx.moveTo(x*CELL+.5,0); ctx.lineTo(x*CELL+.5,h); ctx.stroke(); }
  for (let y=1;y<ROWS;y++){ ctx.beginPath(); ctx.moveTo(0,y*CELL+.5); ctx.lineTo(w,y*CELL+.5); ctx.stroke(); }
}
function drawGhost(){
  if (!current) return;
  let d=0; while(!collides(current,0,d+1,current.rot)) d++;
  const color=COLORS[current.type];
  for (const [cx,cy] of cellsOf(current)){
    const x=(current.x+cx)*CELL, y=(current.y+d+cy)*CELL;
    ctx.save(); ctx.globalAlpha=0.16; ctx.fillStyle=color;
    roundRect(ctx,x+3,y+3,CELL-6,CELL-6,4); ctx.fill(); ctx.restore();
    ctx.save(); ctx.globalAlpha=0.5; ctx.strokeStyle=color; ctx.lineWidth=1.5;
    roundRect(ctx,x+3,y+3,CELL-6,CELL-6,4); ctx.stroke(); ctx.restore();
  }
}
function drawPiece(){
  if (!current) return;
  const color=COLORS[current.type];
  for (const [cx,cy] of cellsOf(current)){
    const x=(current.x+cx)*CELL, y=(current.y+cy)*CELL;
    if (y>=0) drawBlock(ctx,x,y,CELL,color,{glow:true});
  }
}
function drawClearing(){
  const flash = 0.35 + 0.45*Math.abs(Math.sin(clearFlash*14));
  for (const r of clearingRows){
    ctx.fillStyle=`rgba(255,255,255,${flash})`;
    ctx.fillRect(0, r*CELL, COLS*CELL, CELL);
  }
}
function drawBoard(){
  drawGrid();
  for (let r=0;r<ROWS;r++) for (let c=0;c<COLS;c++){
    const t=grid[r][c]; if(!t) continue;
    if (clearingRows.includes(r)) continue;
    drawBlock(ctx, c*CELL, r*CELL, CELL, COLORS[t]);
  }
  if (state==='playing'){ drawGhost(); drawPiece(); }
  if (state==='clearing') drawClearing();
  drawParticles();
}
function drawMini(c, type){
  const w=c._cssW, h=c._cssH; c.clearRect(0,0,w,h);
  if (!type) return;
  const cells=SHAPES[type][0];
  let minX=9,maxX=-9,minY=9,maxY=-9;
  for (const [x,y] of cells){ minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y); }
  const cols=maxX-minX+1, rows=maxY-minY+1;
  const s=Math.min((w-10)/cols,(h-10)/rows,20);
  const ox=(w-cols*s)/2 - minX*s, oy=(h-rows*s)/2 - minY*s;
  for (const [x,y] of cells) drawBlock(c, ox+x*s, oy+y*s, s, COLORS[type]);
}
function renderNext(){ for (let i=0;i<NEXT_COUNT;i++) drawMini(nextCanvases[i], queue[i]); }
function renderHold(){ drawMini(holdCanvas, holdType); }

/* ---------- HUD ---------- */
function fmtTime(ms){ const s=Math.floor(ms/1000); return Math.floor(s/60)+':'+String(s%60).padStart(2,'0'); }
function updateHUD(){
  el.score.textContent = score.toLocaleString();
  el.best.textContent = best.toLocaleString();
  el.bestChip.textContent = best.toLocaleString();
  el.level.textContent = level; el.levelChip.textContent = level;
  el.lines.textContent = lines; el.linesChip.textContent = lines;
  el.clears.textContent = clears;
  el.time.textContent = fmtTime(elapsed);
}
function bumpScore(){ el.score.classList.remove('bump'); void el.score.offsetWidth; el.score.classList.add('bump'); }
function shake(){ el.boardWrap.classList.remove('shake'); void el.boardWrap.offsetWidth; el.boardWrap.classList.add('shake'); }

/* ---------- overlay ---------- */
function showOverlay(title, text, showScore){
  el.ovTitle.textContent = title; el.ovText.textContent = text;
  if (showScore){
    const isBest = score>=best && score>0;
    el.ovScore.hidden=false;
    el.ovScore.className = 'ov-score' + (isBest?' newbest':'');
    el.ovScore.innerHTML = (isBest?'New best! ':'') + 'Score<b>'+score.toLocaleString()+'</b>';
  } else el.ovScore.hidden=true;
  el.ovBtn.textContent = state==='gameover' ? 'Play Again' : 'Start Game';
  el.overlay.classList.add('show');
}
function hideOverlay(){ el.overlay.classList.remove('show'); }

/* ---------- flow ---------- */
function reset(){
  grid = Array.from({length:ROWS},()=>new Array(COLS).fill(null));
  bag=[]; queue=[]; ensureQueue();
  current=null; holdType=null; canHold=true;
  score=0; lines=0; level=1; clears=0; elapsed=0;
  dropInterval=1000; dropTimer=0; lockTimer=0; lockResets=0; lockActive=false;
  clearingRows=[]; clearTimer=0; clearFlash=0; particles=[];
  keys={left:false,right:false,down:false}; dasTimer=0; dasDir=0; arrTimer=0;
  renderHold(); renderNext(); updateHUD();
}
function startGame(){ reset(); state='playing'; hideOverlay(); spawn(); }
function togglePause(){
  if (state==='playing'){ state='paused'; showOverlay('PAUSED','Take a breath. Press P to resume.',false); }
  else if (state==='paused'){ state='playing'; hideOverlay(); }
}
function primaryAction(){
  if (state==='start' || state==='gameover') startGame();
  else if (state==='paused') togglePause();
}

/* ---------- input ---------- */
const KEYMAP = {
  ArrowLeft:'left', ArrowRight:'right', ArrowDown:'down', ArrowUp:'rotate',
  KeyX:'rotate', KeyZ:'rotateCCW', KeyC:'hold', KeyP:'pause', Space:'hard', Enter:'primary'
};
window.addEventListener('keydown', e=>{
  const a = KEYMAP[e.code]; if (!a) return;
  e.preventDefault();
  if (a==='primary'){ primaryAction(); return; }
  if (a==='pause'){ togglePause(); return; }
  if (state!=='playing') return;
  if (a==='left'){ keys.left=true; dasDir=-1; dasTimer=0; arrTimer=0; move(-1); }
  else if (a==='right'){ keys.right=true; dasDir=1; dasTimer=0; arrTimer=0; move(1); }
  else if (a==='down'){ keys.down=true; }
  else if (a==='rotate'){ rotate(1); }
  else if (a==='rotateCCW'){ rotate(-1); }
  else if (a==='hold'){ hold(); }
  else if (a==='hard'){ hardDrop(); }
});
window.addEventListener('keyup', e=>{
  const a = KEYMAP[e.code]; if (!a) return;
  if (a==='left'){ keys.left=false; if(dasDir===-1) dasDir=keys.right?1:0; }
  else if (a==='right'){ keys.right=false; if(dasDir===1) dasDir=keys.left?-1:0; }
  else if (a==='down'){ keys.down=false; }
});
el.ovBtn.addEventListener('click', primaryAction);
el.pauseBtn.addEventListener('click', togglePause);
el.restartBtn.addEventListener('click', ()=>{ if(state==='playing'||state==='paused') startGame(); else primaryAction(); });

/* touch buttons */
document.getElementById('touch').addEventListener('pointerdown', e=>{
  const act = e.target.dataset.act; if (!act) return; e.preventDefault();
  if (state!=='playing'){ if(act==='hard'||act==='soft') primaryAction(); return; }
  if (act==='left') move(-1);
  else if (act==='right') move(1);
  else if (act==='rotate') rotate(1);
  else if (act==='soft') softDrop();
  else if (act==='hard') hardDrop();
  else if (act==='hold') hold();
});

/* ---------- main loop ---------- */
function update(dt){
  if (state==='playing'){
    elapsed += dt*1000;
    // horizontal auto-repeat (DAS/ARR)
    if (dasDir!==0){
      dasTimer += dt*1000;
      if (dasTimer>=DAS){ arrTimer += dt*1000; while(arrTimer>=ARR){ move(dasDir); arrTimer-=ARR; } }
    }
    // gravity
    const interval = keys.down ? Math.min(dropInterval, SOFT_DROP_MS) : dropInterval;
    dropTimer += dt*1000;
    while (dropTimer>=interval){
      dropTimer-=interval;
      if (!collides(current,0,1,current.rot)){ current.y++; if(keys.down) score+=1; lockTimer=0; lockActive=false; }
      else { lockActive=true; break; }
    }
    // lock delay
    if (lockActive){
      lockTimer += dt*1000;
      if (lockTimer>=LOCK_DELAY) lockPiece();
    }
    updateHUD();
  } else if (state==='clearing'){
    clearTimer -= dt*1000; clearFlash += dt;
    if (clearTimer<=0) finishClear();
  }
  updateParticles(dt);
}
function loop(t){
  const dt = Math.min(0.05, (t-lastTime)/1000 || 0); lastTime=t;
  update(dt); drawBoard();
  requestAnimationFrame(loop);
}

/* ---------- boot ---------- */
best = parseInt(localStorage.getItem('tetris.best')||'0',10) || 0;
reset();
resize();
showOverlay('TETRIS','Press Enter or tap to start. Clear lines to score.',false);
updateHUD();
window.addEventListener('resize', resize);
if (window.ResizeObserver){ new ResizeObserver(resize).observe(el.boardWrap); }

/* floating background blocks */
(function(){
  const f=document.getElementById('floaters');
  const cols=Object.values(COLORS);
  for (let i=0;i<14;i++){
    const s=document.createElement('span');
    s.style.left=Math.random()*100+'%';
    s.style.background=cols[i%cols.length];
    s.style.animationDuration=(14+Math.random()*16)+'s';
    s.style.animationDelay=(-Math.random()*20)+'s';
    s.style.width=s.style.height=(10+Math.random()*16)+'px';
    f.append(s);
  }
})();

requestAnimationFrame(loop);
