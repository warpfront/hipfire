#!/usr/bin/env python3
"""Offline fixture-aware LongBench30 / LongDecode5 A/B receipt verifier.

Never loads a model, opens a GPU, reads old reference-baseline outputs, or
executes generated code. Run --self-test for CPU-only parser negative controls.
Default arm layout: old/{longbench,longdecode}.json + old/serve.log, same for new.
All individual paths may be overridden. --partial reports missing evidence as
pending, never as passed. Exit 1: A/B parity or receipt-integrity failure;
2: incomplete; 0: complete relative-regression gates pass, which can retain
absolute truncation/quality limitations (or a clean explicitly partial report).
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import sys

PROOF = re.compile(r"HIPFIRE_REPLAY_ROUTE_PROOF transport=(\S+) position=(\d+) request_id=(\S+) replays=(\d+)(?:\s|$)")
MD5 = re.compile(r"[0-9a-f]{32}\Z")
OFFICIAL = re.compile(r"\bthe\s+correct\s+answer\s+is\s*:?\s*\*{0,2}\s*(?:\(\s*([A-D])\s*\)|([A-D])(?=[\s.,!;:*]|$))", re.I)
ANSWER_LINE = re.compile(r"^\s*\*{0,2}(?:final\s+)?answer\*{0,2}\s*[:=]\s*\*{0,2}\s*\(?([A-D])\)?\s*\*{0,2}\s*[.!]?\s*$", re.I | re.M)
BARE = re.compile(r"\s*\*{0,2}\s*\(?([A-D])\)?\s*\*{0,2}\s*[.!]?\s*", re.I)
ALTERNATIVE = re.compile(r"^\s*(?:/|or\b|and\b)\s*\(?([A-D])\)?", re.I)
TEXT_FIELDS = ("content", "reasoning_content", "assistant_content", "tool_calls")
PARITY_FIELDS = ("prompt_md5", "request_md5", *TEXT_FIELDS, "gen", "ctx", "finish",
                 "attractor", "empty", "runaway", "atem_leak")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def md5(text):
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def integer(value):
    return isinstance(value, int) and not isinstance(value, bool)


def extract_answer(text):
    """Conservative formatted-final extraction, never a first A-D in prose.

    Conflicting explicit answers are ambiguous, including an immediate 'or B'.
    A unique explicit answer is accepted; otherwise allow a constrained answer
    line or a whole-response single letter. Reasoning channel is never scored.
    """
    matches = list(OFFICIAL.finditer(text))
    found = [(m.group(1) or m.group(2)).upper() for m in matches]
    alternatives = []
    for match in matches:
        alternative = ALTERNATIVE.match(text[match.end():])
        if alternative:
            alternatives.append(alternative[1].upper())
    fallback = [m[1].upper() for m in ANSWER_LINE.finditer(text)]
    candidates = found + alternatives + fallback
    method = "formatted_correct_answer" if found else "explicit_answer_line"
    if not candidates:
        bare = BARE.fullmatch(text)
        if bare:
            candidates, method = [bare[1].upper()], "whole_response_letter"
    letters = sorted(set(candidates))
    if len(letters) > 1:
        return {"status": "ambiguous", "answer": None, "candidates": letters, "method": method}
    if not letters:
        return {"status": "unparsed", "answer": None, "candidates": [], "method": None}
    return {"status": "parsed", "answer": letters[0], "candidates": letters, "method": method}


def self_test():
    for text, answer in [("The correct answer is (A)", "A"), ("**The correct answer is (b)**.", "B"),
                         ("The correct answer is C.", "C"), ("Final answer: (D)", "D"), ("(A)", "A")]:
        assert extract_answer(text)["answer"] == answer, (text, extract_answer(text))
    for text in ("The correct answer is (A).\nThe correct answer is (B).", "The correct answer is (A) or (D)",
                 "The correct answer is (B)\nAnswer: C"):
        assert extract_answer(text)["status"] == "ambiguous", text
    for text in ("A is discussed first; B is discussed second.", "The correct answer is (A or B)", "", "Possibly (D)."):
        assert extract_answer(text)["status"] == "unparsed", text
    payload = (json.dumps({"prompt": "keep\u2028inside"}, ensure_ascii=False) + "\n").encode("utf-8")
    rows = [json.loads(line) for line in payload.split(b"\n") if line.strip()]
    assert len(rows) == 1 and "\u2028" in rows[0]["prompt"]
    print("verify-quality: CPU self-test PASS (answer conflicts, unparsed prose, physical LF)")


class Audit:
    def __init__(self, args):
        self.args, self.root = args, args.root.resolve()
        self.failures, self.absolute_failures, self.pending, self.inputs = [], [], [], {}
        self.rows, self.summaries, self.requests, self.run_receipts = {}, {}, {}, {}
        self.phase_sources = {}

    def check(self, ok, where, detail):
        if not ok:
            self.failures.append({"where": where, "detail": detail})
        return bool(ok)

    def absolute(self, ok, where, detail):
        if not ok:
            self.absolute_failures.append({"where": where, "detail": detail})
        return bool(ok)

    def read(self, path):
        try:
            data = path.read_bytes()
        except OSError as error:
            self.pending.append({"path": str(path), "reason": str(error)})
            return None
        self.inputs[str(path)] = {"bytes": len(data), "sha256": sha(data)}
        return data

    def load_json(self, path):
        data = self.read(path)
        if data is None:
            return None
        try:
            return json.loads(data)
        except (ValueError, UnicodeError) as error:
            target = self.pending if self.args.partial else self.failures
            target.append({"where": str(path), "detail": f"invalid/unsettled JSON: {error}"})
            return None

    def fixtures(self):
        qc = self.args.qc_root.resolve()
        data = self.read(qc / "longbench/longbench-hard30-pp32k.jsonl")
        manifest = self.load_json(qc / "longbench/longbench-hard30-pp32k.manifest.json")
        ld = self.load_json(qc / "longdecode/questions.json")
        if data is None or not isinstance(manifest, dict) or not isinstance(ld, list):
            return None
        try:
            # Physical LF is essential: a fixture contains literal U+2028.
            lb = [json.loads(line) for line in data.split(b"\n") if line.strip()]
        except (ValueError, UnicodeError) as error:
            self.check(False, "fixtures/longbench", str(error))
            return None
        self.check(len(lb) == manifest.get("count") == 30, "fixtures/longbench", "official subset must have 30 records")
        self.check(sha(data) == manifest.get("sample_sha256"), "fixtures/longbench", "JSONL hash differs from manifest")
        self.check([r.get("ordinal") for r in lb] == list(range(30)), "fixtures/longbench", "ordinals are not exactly 0..29")
        self.check(len(ld) == 5, "fixtures/longdecode", "expected five local tasks")
        for row in lb:
            self.check(isinstance(row.get("answer"), str) and row["answer"] in "ABCD" and len(row["answer"]) == 1,
                       "fixtures/longbench", "invalid official gold letter")
            self.check(md5(row["prompt_no_think"]) == row.get("prompt_no_think_md5"),
                       f"fixtures/lb/{row.get('ordinal')}", "prompt bytes differ from fixture MD5")
        for suite, rows, key in (("longbench", lb, "prompt_no_think"), ("longdecode", ld, "prompt")):
            for i, row in enumerate(rows):
                row["_prompt_md5"] = md5(row[key])
                row["_index"] = i
            self.check(len({r["_prompt_md5"] for r in rows}) == len(rows), f"fixtures/{suite}", "duplicate fixture prompt MD5")
        return {"longbench": lb, "longdecode": ld}, manifest

    def metadata(self, arm, directory, suite):
        run = self.load_json(directory / "run.json")
        if not isinstance(run, dict):
            return {}
        expected = {"sampling": "greedy", "temperature": 0, "seed": 123, "thinking": "off",
            "speculation": "off", "normalization": "off", "max_seq": 65536,
            "longbench_max_tokens": 512, "longdecode_max_tokens": 16384, "resident_budget_mib": 18000}
        settings = run.get("settings") or {}
        for key, value in expected.items():
            self.check(settings.get(key) == value, f"{arm}/settings", f"{key}={settings.get(key)!r}, expected {value!r}")
        env = run.get("env") or {}
        flags = {"HIPFIRE_MTP_MODE": "off", "HIPFIRE_OFFLOAD_EXEC": "pcie", "HIPFIRE_QWEN4_EXPERT_CACHE": "1",
            "HIPFIRE_QWEN4_EXPERT_CACHE_TAIL_PERCENT": "50", "HIPFIRE_QWEN4_EXPERT_CACHE_INFLIGHT": "64",
            "HIPFIRE_QWEN4_DECODE_SHARE": "off", "HIPFIRE_QWEN4_D2_DEFAULT": "0", "HIPFIRE_PLE_FORMAT": "q4",
            "HIPFIRE_PREFILL_CHUNK_ROWS": "4096", "HIPFIRE_QWEN4_EXPERT_HOT_BUDGET_MIB": "18000",
            "HIPFIRE_DN_STATE_EF": "1", "HIPFIRE_NORMALIZE_PROMPT": "0"}
        for key, value in flags.items():
            self.check(env.get(key) == value, f"{arm}/env", f"{key}={env.get(key)!r}, expected {value!r}")
        manifest = run.get("runtime_manifest")
        cli = env.get("HIPFIRE_CLI_BIN")
        if isinstance(cli, str):
            frozen = self.load_json(Path(cli).parent / "MANIFEST.json")
            self.check(isinstance(manifest, dict) and manifest == frozen, f"{arm}/runtime_manifest", "run manifest differs from frozen runtime manifest")
        else:
            self.check(False, f"{arm}/runtime_manifest", "no explicit CLI binary binding")
        commands = run.get("commands") or []
        if run.get("status") == "PASS":
            self.check(len(commands) >= 2, f"{arm}/commands", "expected warmup and scored-suite commands")
        for index, command in enumerate(commands):
            if not self.check(isinstance(command, list), f"{arm}/commands", "command is not argument list"):
                continue
            for flag, value in {"--thinking": "off", "--speculation": "off", "--max-seq": "65536",
                                "--sampling": "greedy", "--seed": "123"}.items():
                actual = command[command.index(flag) + 1] if flag in command and command.index(flag) + 1 < len(command) else None
                self.check(actual == value, f"{arm}/commands/{index}", f"{flag} is {actual!r}")
            self.check(("--no-spawn" in command) == (index > 0), f"{arm}/commands/{index}", "same-process no-spawn sequence differs")
        if run.get("status") == "FAIL":
            self.absolute(False, f"{arm}/{suite}/canonical_driver", f"canonical driver failed (retained verbatim): {run.get('failure')}")
        elif run.get("status") != "PASS":
            self.pending.append({"where": f"{arm}/driver", "reason": "arm has not completed"})
        receipt = {key: run.get(key) for key in ("status", "failure", "settings", "env", "runtime_manifest", "commands", "phase_results", "completed")}
        receipt.update(directory=str(directory), canonical_driver_pass=run.get("status") == "PASS")
        warmup = self.load_json(directory / "warmup.json")
        if isinstance(warmup, list) and len(warmup) == 1:
            receipt["warmup_projection"] = {key: warmup[0].get(key) for key in PARITY_FIELDS}
        else:
            self.check(False, f"{arm}/{suite}/warmup", "missing single fiction16 warmup receipt")
        self.run_receipts[f"{arm}/{suite}"] = receipt
        return run

    def request(self, arm, suite, directory, fixture, row, cap):
        task = fixture["_id"] if suite == "longbench" else fixture["genre"]
        path = directory / "requests" / suite / f"{fixture['_index']:02d}-{task}" / "request.json"
        wire = self.read(path)
        if wire is None:
            return
        where = f"{arm}/{suite}/{fixture['_index']}/request"
        self.check(hashlib.md5(wire).hexdigest() == row.get("request_md5"), where, "saved wire MD5 differs from actual canonical send MD5")
        try:
            body = json.loads(wire)
        except (ValueError, UnicodeError) as error:
            self.check(False, where, f"invalid saved request: {error}")
            return
        prompt = fixture["prompt_no_think"] if suite == "longbench" else fixture["prompt"]
        self.check(body.get("messages") == [{"role": "user", "content": prompt}], where, "wire messages differ from the exact independent fixture")
        for key, value in {"max_tokens": cap, "seed": 123, "temperature": 0, "stream": True,
                           "stream_options": {"include_usage": True}}.items():
            self.check(body.get(key) == value, where, f"wire {key}={body.get(key)!r}, expected {value!r}")
        self.check("tools" not in body, where, "unexpected tools in wire request")
        if "actual_request_md5" in row:
            self.check(row["actual_request_md5"] == row.get("request_md5"), where, "two actual request MD5 fields disagree")
        self.requests[(arm, suite, fixture["_prompt_md5"])] = sha(wire)

    def arm(self, arm, fixtures):
        base_directory = getattr(self.args, arm) or self.root / arm
        ids = set()
        for suite, expected in fixtures.items():
            separate_ld = getattr(self.args, f"{arm}_longdecode_dir") if suite == "longdecode" else None
            directory = (separate_ld or base_directory).resolve()
            run = self.metadata(arm, directory, suite)
            log_path = (getattr(self.args, f"{arm}_log") if not separate_ld else None) or directory / "serve.log"
            raw_log = self.read(log_path)
            proofs = defaultdict(list)
            if raw_log is not None:
                for line_no, line in enumerate(raw_log.decode("utf-8", errors="replace").split("\n"), 1):
                    match = PROOF.search(line)
                    if match:
                        transport, position, request_id, count = match.groups()
                        proofs[request_id].append({"line": line_no, "transport": transport,
                            "position": int(position), "replays": int(count)})
            path = getattr(self.args, f"{arm}_{suite}") or directory / f"{suite}.json"
            partial_rows = False
            if not path.exists() and path.with_suffix(".partial.json").exists():
                path = path.with_suffix(".partial.json")
                partial_rows = True
            loaded = self.load_json(path)
            if loaded is None:
                continue
            rows = loaded.get("rows") if isinstance(loaded, dict) else loaded
            if not self.check(isinstance(rows, list), f"{arm}/{suite}", "harness receipt must be rows list"):
                continue
            where = f"{arm}/{suite}"
            if partial_rows:
                self.check(len(rows) <= len(expected), where, "partial receipt has extra rows")
                if len(rows) < len(expected) or run.get("status") not in ("PASS", "FAIL"):
                    self.pending.append({"where": where, "reason": f"partial receipt: {len(rows)}/{len(expected)} rows, phase not fully settled"})
            else:
                self.check(len(rows) == len(expected), where, f"expected {len(expected)} rows, got {len(rows)}")
            index = {r["_prompt_md5"]: r for r in expected}
            aligned, summaries = {}, []
            cap = 512 if suite == "longbench" else 16384
            for row_no, row in enumerate(rows):
                loc = f"{where}[{row_no}]"
                if not self.check(isinstance(row, dict), loc, "row is not an object"):
                    continue
                prompt = row.get("prompt_md5")
                if not self.check(isinstance(prompt, str) and prompt in index, loc, "prompt MD5 does not match an exact no-think fixture"):
                    continue
                fixture = index[prompt]
                self.check(prompt not in aligned, loc, "duplicate fixture prompt")
                aligned[prompt] = row
                for field in ("request_md5", "prompt_md5"):
                    self.check(isinstance(row.get(field), str) and bool(MD5.fullmatch(row[field])), loc, f"invalid {field}")
                request_id = row.get("request_id")
                self.check(isinstance(request_id, str) and bool(request_id), loc, "missing request ID")
                if isinstance(request_id, str):
                    self.check(request_id not in ids, loc, "duplicate request ID within arm")
                    ids.add(request_id)
                self.check(row.get("finish") in ("stop", "length"), loc, f"invalid runtime finish: {row.get('finish')!r}")
                self.absolute(row.get("finish") == "stop", loc, f"not a natural stop: {row.get('finish')!r}")
                self.check(row.get("terminal_count") == 1 and row.get("terminal_reasons") == [row.get("finish")], loc, "expected exactly one matching terminal")
                self.check(row.get("saw_done") is True, loc, "missing SSE [DONE]")
                self.check(row.get("post_terminal_bytes") == 0, loc, "late payload bytes after terminal")
                self.check("stream_error" in row and row["stream_error"] is None, loc, f"stream error: {row.get('stream_error')!r}")
                self.check(isinstance(row.get("tool_calls"), list), loc, "missing tool_calls observation")
                self.absolute(row.get("tool_calls") == [], loc, "unexpected tool output")
                for field in ("attractor", "empty", "atem_leak", "runaway"):
                    self.check(isinstance(row.get(field), bool), loc, f"missing raw flag {field}")
                    self.absolute(row.get(field) is False, loc, f"raw quality flag {field}={row.get(field)!r}")
                for field in TEXT_FIELDS[:3]:
                    self.check(isinstance(row.get(field), str), loc, f"missing text field {field}")
                text = row.get("content") if isinstance(row.get("content"), str) else ""
                self.absolute(bool(text.strip()), loc, "visible answer is empty")
                self.absolute(row.get("reasoning_content") == "", loc, "unexpected reasoning under no-think")
                self.absolute(row.get("assistant_content") == text, loc, "visible/fallback text disagree")
                self.request(arm, suite, directory, fixture, row, cap)
                gen, ctx, cached = row.get("gen"), row.get("ctx"), row.get("cached")
                self.check(integer(gen) and 0 < gen <= cap, loc, f"invalid actual generated token count {gen!r} (cap {cap})")
                self.check(integer(ctx) and 0 < ctx < 65536, loc, f"invalid actual prompt context {ctx!r}")
                self.check(integer(cached) and integer(ctx) and 0 <= cached <= ctx, loc, "invalid cached prompt count")
                if integer(gen) and integer(ctx):
                    self.check(ctx + gen <= 65536, loc, "actual prompt + generation exceeds configured context")
                joined = proofs.get(request_id, []) if isinstance(request_id, str) else []
                if raw_log is not None:
                    self.check(len(joined) == 1 and joined[0]["transport"] in ("pm4", "pm4_ib") and joined[0]["replays"] > 0,
                               loc, f"expected one successful request-scoped PM4 proof, got {joined!r}")
                item = {"fixture_index": fixture["_index"], "genre": fixture.get("genre"),
                    "ordinal": fixture.get("ordinal"), "domain": fixture.get("domain"),
                    "request_id": request_id, "prompt_md5": prompt, "request_md5": row.get("request_md5"),
                    "content_sha256": sha(text.encode("utf-8")), "actual_gen": gen, "cap": cap,
                    "finish": row.get("finish"), "ctx": ctx, "cached": cached,
                    "request_pm4_proof": joined,
                    "raw_quality_flags": {key: row.get(key) for key in ("finish", "attractor", "empty", "runaway", "atem_leak", "terminal_count", "terminal_reasons", "saw_done", "post_terminal_bytes", "stream_error")},
                    "wall_s": row.get("wall_s"),
                    "prefill_ms": row.get("prefill_ms"), "decode_tok_s": row.get("decode_tok_s")}
                if suite == "longbench":
                    answer = extract_answer(text)
                    self.absolute(answer["status"] == "parsed", loc, f"final answer {answer['status']}")
                    item.update(gold=fixture["answer"], extraction=answer,
                                correct=answer["answer"] == fixture["answer"], answer_excerpt=text[:1000])
                else:
                    words = len(re.findall(r"\S+", text))
                    if fixture.get("genre") == "story":
                        item["story_word_requirement"] = {"requested_minimum": 1500, "actual_words": words,
                            "met": words >= 1500, "is_gold_accuracy": False}
                        self.absolute(words >= 1500, loc, f"story has {words} words, requested at least 1500; not a semantic-gold metric")
                    item.update(words=words, semantic_correctness="NOT_AUTOMATICALLY_CERTIFIED",
                                natural_stop=row.get("finish") == "stop", generated_cap_is_not_actual_length=True)
                summaries.append(item)
            if not partial_rows:
                self.check(set(aligned) == set(index), where, "missing or extra fixture prompt identities")
            self.phase_sources[f"{arm}/{suite}"] = {"directory": str(directory), "artifact": str(path),
                "partial_artifact": partial_rows, "all_fixture_rows_present": set(aligned) == set(index),
                "canonical_driver_status": run.get("status"), "canonical_driver_failure": run.get("failure"),
                "same_process_as_other_suite": directory == (getattr(self.args, f"{arm}_longdecode_dir") or base_directory).resolve() if suite == "longbench" else directory == base_directory.resolve()}
            self.rows[(arm, suite)] = aligned
            self.summaries[f"{arm}/{suite}"] = sorted(summaries, key=lambda r: r["fixture_index"])

    def compare(self, fixtures):
        output = {}
        for suite, expected in fixtures.items():
            left, right = self.rows.get(("old", suite), {}), self.rows.get(("new", suite), {})
            comparisons = []
            for fixture in expected:
                prompt = fixture["_prompt_md5"]
                if prompt not in left or prompt not in right:
                    self.pending.append({"where": f"compare/{suite}/{fixture['_index']}", "reason": "both arm receipts not yet available"})
                    continue
                a, b = left[prompt], right[prompt]
                differences = [key for key in PARITY_FIELDS if a.get(key) != b.get(key)]
                old_wire = self.requests.get(("old", suite, prompt))
                new_wire = self.requests.get(("new", suite, prompt))
                if old_wire is not None and new_wire is not None and old_wire != new_wire:
                    differences.append("actual_request_wire_sha256")
                old_score = extract_answer(a.get("content", ""))["answer"] == fixture["answer"] if suite == "longbench" else None
                new_score = extract_answer(b.get("content", ""))["answer"] == fixture["answer"] if suite == "longbench" else None
                if old_score != new_score:
                    differences.append("gold_score")
                self.check(not differences, f"compare/{suite}/{fixture['_index']}", f"A/B mismatch: {differences}")
                comparisons.append({"fixture_index": fixture["_index"], "prompt_md5": prompt,
                    "same_prompt_request_text_tokens_finish": not differences, "differences": differences,
                    "old_request_sha256": old_wire, "new_request_sha256": new_wire,
                    "old_gen": a.get("gen"), "new_gen": b.get("gen"),
                    "old_correct": old_score, "new_correct": new_score,
                    "shared_length_limit": a.get("finish") == b.get("finish") == "length",
                    "old_finish": a.get("finish"), "new_finish": b.get("finish")})
            output[suite] = comparisons
        return output

    def scores(self):
        output = {}
        for arm in ("old", "new"):
            rows = self.summaries.get(f"{arm}/longbench", [])
            domains = {}
            for domain in sorted({r["domain"] for r in rows}):
                part = [r for r in rows if r["domain"] == domain]
                domains[domain] = {"observed": len(part), "correct": sum(r["correct"] for r in part),
                    "parsed": sum(r["extraction"]["status"] == "parsed" for r in part),
                    "ambiguous": [r["ordinal"] for r in part if r["extraction"]["status"] == "ambiguous"],
                    "unparsed": [r["ordinal"] for r in part if r["extraction"]["status"] == "unparsed"]}
            correct = sum(r["correct"] for r in rows)
            output[arm] = {"official_gold_subset_denominator": 30, "observed": len(rows), "correct": correct,
                "accuracy_percent_all30": round(100 * correct / 30, 3) if len(rows) == 30 else None,
                "gold_letter_counts_observed": dict(sorted(Counter(r["gold"] for r in rows).items())),
                "ambiguous_ordinals": [r["ordinal"] for r in rows if r["extraction"]["status"] == "ambiguous"],
                "unparsed_ordinals": [r["ordinal"] for r in rows if r["extraction"]["status"] == "unparsed"],
                "truncated_ordinals": [r["ordinal"] for r in rows if r["finish"] == "length"],
                "parsed_gold_score_is_retained_when_truncated": True,
                "domains": domains,
                "extraction_scope": "Conservative formatted-final extraction, not a claim of running the upstream official evaluator; ambiguous/unparsed count incorrect in all-30 accuracy."}
        return output

    def finish(self):
        loaded = self.fixtures()
        fixtures, manifest = loaded if loaded else ({}, {})
        if fixtures:
            for arm in ("old", "new"):
                self.arm(arm, fixtures)
        for suite in ("longbench", "longdecode"):
            old_receipt, new_receipt = (self.run_receipts.get(f"{arm}/{suite}") for arm in ("old", "new"))
            if old_receipt and new_receipt:
                self.check((old_receipt["runtime_manifest"] or {}).get("model") == (new_receipt["runtime_manifest"] or {}).get("model"),
                           f"runtime_manifests/{suite}", "old/new model identity differs")
                self.check(old_receipt.get("warmup_projection") == new_receipt.get("warmup_projection"),
                           f"compare/{suite}/warmup", "old/new fiction16 warmup history differs")
        comparisons = self.compare(fixtures)
        complete = not self.pending and all(len(comparisons.get(suite, [])) == count for suite, count in (("longbench", 30), ("longdecode", 5)))
        relative_pass = not self.failures if complete else None
        absolute_pass = not self.failures and not self.absolute_failures if complete else None
        ab_failures = [x for x in self.failures if x["where"].startswith("compare/")]
        integrity_failures = [x for x in self.failures if not x["where"].startswith("compare/")]
        status = "FAIL" if self.failures else ("PASS_WITH_ABSOLUTE_LIMITATIONS" if relative_pass and self.absolute_failures else ("PASS" if complete else "INCOMPLETE"))
        return {"status": status, "regression_gates_pass": relative_pass,
            "absolute_completeness_pass": absolute_pass, "evidence_complete": complete,
            "absolute_completeness_failures": self.absolute_failures,
            "canonical_harness_pass": all(r["canonical_driver_pass"] for r in self.run_receipts.values()) if complete else None,
            "canonical_driver_failures": [{"scope": k, "status": r["status"], "failure": r["failure"]} for k, r in self.run_receipts.items() if r["status"] == "FAIL"],
            "ab_equivalence_failures": ab_failures, "receipt_integrity_failures": integrity_failures,
            "ab_equivalence_pass": not ab_failures if complete else None,
            "regression_scope": "Exact A/B prompt/request wire/text/token-count/finish/gold-score parity plus valid settings and PM4/terminal receipts. Shared length truncation, unparsed final answers or output defects remain absolute limitations and are not attributed to the new path.",
            "partial_requested": self.args.partial, "run_receipts": self.run_receipts, "phase_sources": self.phase_sources, "failures": self.failures, "pending_evidence": self.pending,
            "longbench_scores": self.scores(), "comparisons": comparisons, "rows": self.summaries,
            "fixture_source": manifest.get("source"), "fixture_domain_quotas": manifest.get("domain_quotas"),
            "fixture_official_gold_letter_counts": dict(sorted(Counter(r["answer"] for r in fixtures.get("longbench", [])).items())),
            "longdecode_has_gold": False, "old_reference_baseline_read_or_scored": False,
            "longdecode_semantic_correctness": "NOT_AUTOMATICALLY_CERTIFIED; natural stop and exact A/B parity do not prove game/tutorial/story correctness",
            "settings_scope": "run.json settings/env/commands are checked, runtime_manifest is joined to its frozen MANIFEST.json, and private request.json wire bytes are matched to actual canonical-send MD5 plus exact fixture messages/seed123/temperature0/cap. Frozen binary hashes were checked by the runner; this posthoc verifier does not rehash binaries or execute models.",
            "no_model_no_gpu_no_generated_code_execution": True, "input_receipts": self.inputs}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--qc-root", type=Path, default=Path("/home/husrcf/Code/hipfireQC"))
    parser.add_argument("--old", type=Path)
    parser.add_argument("--new", type=Path)
    parser.add_argument("--old-longdecode-dir", type=Path, help="Separate matched fiction16 + LongDecode process directory")
    parser.add_argument("--new-longdecode-dir", type=Path, help="Separate matched fiction16 + LongDecode process directory")
    for arm in ("old", "new"):
        for name in ("longbench", "longdecode", "log"):
            parser.add_argument(f"--{arm}-{name}", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--partial", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    report = Audit(args).finish()
    output = args.out or args.root / ("quality-report-partial.json" if args.partial else "quality-report.json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "regression_gates_pass": report["regression_gates_pass"],
        "absolute_completeness_pass": report["absolute_completeness_pass"],
        "failures": len(report["failures"]), "absolute_limitations": len(report["absolute_completeness_failures"]), "pending": len(report["pending_evidence"]),
        "longbench_correct": {k: v["correct"] for k, v in report["longbench_scores"].items()}, "report": str(output)}))
    return 1 if report["failures"] else (0 if report["evidence_complete"] or args.partial else 2)


if __name__ == "__main__":
    sys.exit(main())
