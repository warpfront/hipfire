# Comprehensive Tutorial: KV Caches in Autoregressive Transformer Inference

## 1. Introduction

In autoregressive Large Language Models (LLMs), generating text token-by-token is computationally expensive. The **Key-Value (KV) Cache** is a critical optimization that reduces the computational complexity of inference from $O(N^2)$ to $O(N)$ per step by caching the Key ($K$) and Value ($V$) tensors of previous tokens.

This tutorial covers:
1.  The mechanics of Prefill vs. Decode.
2.  Derivation of the KV Cache memory formula.
3.  Advanced optimizations: Grouped-Query Attention (GQA), Quantization, Paging, Prefix Reuse, and Eviction.
4.  Worked numerical examples.
5.  Pseudocode implementations.
6.  Correctness and performance tradeoffs.

---

## 2. Prefill vs. Decode: The Two Phases of Inference

Autoregressive inference consists of two distinct phases with different computational characteristics.

### 2.1 Prefill (Prompt Processing)
- **Input**: The entire prompt (sequence of $N$ tokens).
- **Operation**: The model processes all $N$ tokens in parallel.
- **Attention**: Full self-attention across all $N$ tokens.
- **Output**: The logits for the *next* token and the **KV Cache** for all $N$ tokens.
- **Characteristics**: Compute-bound. High parallelism.

### 2.2 Decode (Token Generation)
- **Input**: One new token (the previously generated token).
- **Operation**: The model processes only the new token.
- **Attention**: The new token’s Query ($Q$) attends to the cached Keys ($K$) and Values ($V$) of all previous tokens.
- **Output**: Logits for the next token and an updated KV Cache (appending the new $K, V$).
- **Characteristics**: Memory-bound. Low parallelism. The bottleneck is reading the KV cache from memory.

> **Key Insight**: Without a KV cache, each decode step would recompute $K$ and $V$ for all previous tokens, leading to $O(N^2)$ total complexity. With a cache, each step is $O(N)$, and total generation is $O(N^2)$ but with a much smaller constant factor and better hardware utilization.

---

## 3. Deriving the KV Cache Memory Formula

### 3.1 Basic Formula

For a transformer with:
- $B$: Batch size
- $L$: Number of layers
- $H$: Number of attention heads
- $D_h$: Head dimension (embedding dimension / $H$)
- $S$: Sequence length (number of tokens in cache)
- $D_{dtype}$: Bytes per element (e.g., 2 for FP16, 4 for FP32)

The KV cache stores both $K$ and $V$ tensors. Each tensor has shape:
$$ [B, L, H, S, D_h] $$

Total elements for $K$ and $V$:
$$ \text{Elements} = 2 \times B \times L \times H \times S \times D_h $$

Total memory in bytes:
$$ M_{KV} = 2 \times B \times L \times H \times S \times D_h \times D_{dtype} $$

### 3.2 Grouped-Query Attention (GQA) Adjustment

In standard Multi-Head Attention (MHA), $H_K = H_V = H_Q = H$.
In **Grouped-Query Attention (GQA)**, multiple query heads share a single key/value head. Let:
- $H_Q$: Number of query heads
- $H_{KV}$: Number of key/value heads ($H_{KV} \leq H_Q$)

The KV cache shape becomes:
$$ [B, L, H_{KV}, S, D_h] $$

Updated memory formula:
$$ M_{KV} = 2 \times B \times L \times H_{KV} \times S \times D_h \times D_{dtype} $$

> **Note**: In Multi-Query Attention (MQA), $H_{KV} = 1$. In MHA, $H_{KV} = H_Q$.

### 3.3 Worked Numerical Example 1: Llama-2-7B (MHA)

- **Model**: Llama-2-7B
- $L = 32$ layers
- $H = 32$ heads
- $D_h = 128$ (hidden dim 4096 / 32 heads)
- $D_{dtype} = 2$ bytes (FP16)
- $B = 1$
- $S = 2048$ tokens

$$ M_{KV} = 2 \times 1 \times 32 \times 32 \times 2048 \times 128 \times 2 $$
$$ M_{KV} = 2 \times 32 \times 32 \times 2048 \times 128 \times 2 $$
$$ M_{KV} = 536,870,912 \text{ bytes} \approx 512 \text{ MB} $$

### 3.4 Worked Numerical Example 2: Llama-3-8B (GQA)

- **Model**: Llama-3-8B
- $L = 32$ layers
- $H_Q = 32$ query heads
- $H_{KV} = 8$ key/value heads (GQA)
- $D_h = 128$
- $D_{dtype} = 2$ bytes (FP16)
- $B = 1$
- $S = 8192$ tokens

$$ M_{KV} = 2 \times 1 \times 32 \times 8 \times 8192 \times 128 \times 2 $$
$$ M_{KV} = 2 \times 32 \times 8 \times 8192 \times 128 \times 2 $$
$$ M_{KV} = 1,073,741,824 \text{ bytes} \approx 1 \text{ GB} $$

> **Observation**: GQA reduces KV cache size by $H_Q / H_{KV} = 32/8 = 4\times$ compared to MHA.

---

## 4. Advanced Optimizations

### 4.1 Quantization of KV Cache

Storing KV cache in FP16 is memory-intensive. Quantizing to lower precision reduces memory footprint.

- **FP8**: 1 byte per element. Reduces memory by 2x.
- **INT8**: 1 byte per element. Requires scaling factors.
- **INT4**: 0.5 bytes per element. Aggressive compression.

**Tradeoff**: Lower precision may degrade model accuracy, especially for long sequences. Recent research (e.g., KIVI, KVQuant) shows that per-channel or per-token quantization can maintain accuracy.

**Updated Formula for INT8**:
$$ M_{KV} = 2 \times B \times L \times H_{KV} \times S \times D_h \times 1 $$

### 4.2 PagedAttention (vLLM)

Traditional KV cache allocation requires contiguous memory blocks. This leads to:
- **Fragmentation**: Unused memory between sequences.
- **Over-allocation**: Reserving max sequence length for all sequences.

**PagedAttention** (inspired by OS virtual memory) divides the KV cache into fixed-size **blocks** (e.g., 16 tokens per block). A block table maps logical token positions to physical memory blocks.

**Benefits**:
- Near-zero memory waste.
- Enables efficient batch size scaling.
- Supports copy-on-write for parallel sampling (e.g., beam search).

### 4.3 Prefix Reuse (Prompt Caching)

If multiple requests share the same prompt prefix (e.g., system prompt + few-shot examples), the KV cache for the prefix can be computed once and reused.

**Mechanism**:
1. Hash the prefix tokens.
2. If a cache hit occurs, load the precomputed KV blocks.
3. Only compute the KV cache for the new suffix tokens.

**Impact**: Reduces prefill latency and memory usage for multi-turn conversations or RAG systems.

### 4.4 Eviction Policies

For long-context models, the KV cache may exceed GPU memory. Eviction strategies remove less important tokens.

- **Sliding Window**: Keep only the last $W$ tokens. Simple but loses long-range context.
- **Attention-Based Eviction**: Remove tokens with the lowest attention scores from recent queries.
- **H2O (Heavy-Hitter Oracle)**: Identifies "heavy hitter" tokens that receive high attention and keeps them, evicting others.

**Tradeoff**: Eviction is lossy. It may degrade performance on tasks requiring long-range dependencies.

---

## 5. Pseudocode Implementation

### 5.1 Basic KV Cache Update (Decode Step)

```python
import torch

class KVCache:
    def __init__(self, batch_size, num_layers, num_kv_heads, head_dim, max_seq_len, dtype=torch.float16):
        self.batch_size = batch_size
        self.num_layers = num_layers
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim
        self.max_seq_len = max_seq_len
        self.dtype = dtype
        
        # Initialize cache tensors: [batch, layers, kv_heads, seq_len, head_dim]
        self.k_cache = torch.zeros(
            batch_size, num_layers, num_kv_heads, max_seq_len, head_dim, 
            dtype=dtype, device='cuda'
        )
        self.v_cache = torch.zeros_like(self.k_cache)
        self.current_seq_len = 0

    def update(self, new_k, new_v):
        """
        new_k, new_v: [batch, layers, kv_heads, 1, head_dim]
        """
        if self.current_seq_len >= self.max_seq_len:
            raise RuntimeError("KV Cache full")
        
        # Append new K and V to the cache
        self.k_cache[:, :, :, self.current_seq_len, :] = new_k.squeeze(3)
        self.v_cache[:, :, :, self.current_seq_len, :] = new_v.squeeze(3)
        
        self.current_seq_len += 1
        
        # Return the full cache up to current length
        return self.k_cache[:, :, :, :self.current_seq_len, :], \
               self.v_cache[:, :, :, :self.current_seq_len, :]

    def reset(self):
        self.current_seq_len = 0
```

### 5.2 Attention with KV Cache

```python
def attention_with_cache(query, k_cache, v_cache, mask=None):
    """
    query: [batch, num_heads, 1, head_dim]
    k_cache: [batch, num_kv_heads, seq_len, head_dim]
    v_cache: [batch, num_kv_heads, seq_len, head_dim]
    """
    # Expand KV heads to match query heads if GQA
    if k_cache.shape[1] != query.shape[1]:
        num_groups = query.shape[1] // k_cache.shape[1]
        k_cache = k_cache.repeat_interleave(num_groups, dim=1)
        v_cache = v_cache.repeat_interleave(num_groups, dim=1)
    
    # Compute attention scores: Q @ K^T
    scores = torch.matmul(query, k_cache.transpose(-2, -1))
    
    # Apply causal mask (only attend to past tokens)
    if mask is not None:
        scores = scores + mask
    
    # Softmax
    attn_weights = torch.softmax(scores, dim=-1)
    
    # Weighted sum of values
    output = torch.matmul(attn_weights, v_cache)
    
    return output
```

### 5.3 PagedAttention Block Allocation (Conceptual)

```python
class PagedKVCache:
    def __init__(self, block_size=16, num_blocks=1000):
        self.block_size = block_size
        self.num_blocks = num_blocks
        self.free_blocks = list(range(num_blocks))
        self.block_tables = {}  # seq_id -> list of block_ids
    
    def allocate_block(self, seq_id):
        if not self.free_blocks:
            raise MemoryError("No free blocks")
        block_id = self.free_blocks.pop(0)
        if seq_id not in self.block_tables:
            self.block_tables[seq_id] = []
        self.block_tables[seq_id].append(block_id)
        return block_id
    
    def get_physical_indices(self, seq_id, logical_positions):
        """Map logical token positions to physical memory indices."""
        physical_indices = []
        for pos in logical_positions:
            block_idx = pos // self.block_size
            offset = pos % self.block_size
            if block_idx >= len(self.block_tables[seq_id]):
                raise IndexError("Block not allocated")
            block_id = self.block_tables[seq_id][block_idx]
            physical_indices.append(block_id * self.block_size + offset)
        return physical_indices
```

---

## 6. Correctness and Performance Tradeoffs

### 6.1 Correctness

1. **Numerical Stability**:
   - **FP16/BF16**: Standard for KV cache. BF16 has better dynamic range than FP16, reducing overflow risks.
   - **Quantization**: INT8/INT4 quantization introduces quantization error. Use per-channel scaling and calibration to minimize accuracy loss. Monitor perplexity on validation sets.

2. **Attention Masking**:
   - Ensure the causal mask is correctly applied during decode. The new token must only attend to previous tokens (including itself).
   - In batched inference, ensure padding tokens do not contribute to attention scores.

3. **GQA/MQA Correctness**:
   - When using GQA, ensure query heads are correctly grouped with key/value heads. Incorrect grouping leads to wrong attention patterns.

### 6.2 Performance Tradeoffs

| Optimization | Memory Savings | Latency Impact | Accuracy Impact | Complexity |
| :--- | :--- | :--- | :--- | :--- |
| **GQA** | High (up to 8x) | Low (faster decode) | Minimal | Low |
| **KV Quantization (INT8)** | 2x | Low (memory bandwidth bound) | Low (with calibration) | Medium |
| **PagedAttention** | High (reduces waste) | Low (better batching) | None | High |
| **Prefix Reuse** | High (for shared prompts) | Low (faster prefill) | None | Medium |
| **Eviction (Sliding Window)** | High | Low | High (loses context) | Low |
| **Eviction (Attention-Based)** | Medium | Medium (overhead for scoring) | Low-Medium | High |

### 6.3 Hardware Considerations

- **Memory Bandwidth**: Decode is memory-bound. Reducing KV cache size (via GQA, quantization) directly increases throughput.
- **Compute**: Prefill is compute-bound. GQA reduces compute in prefill as well.
- **GPU Memory**: Larger batch sizes require more KV cache memory. PagedAttention enables larger batches by reducing fragmentation.

---

## 7. Conclusion

The KV cache is the cornerstone of efficient autoregressive transformer inference. By understanding the memory formula and leveraging optimizations like GQA, quantization, PagedAttention, and prefix reuse, practitioners can significantly reduce memory usage and latency while maintaining model accuracy.

**Best Practices**:
1. Use **GQA** or **MQA** for new models to reduce KV cache size.
2. Implement **PagedAttention** for production serving to maximize batch size.
3. Use **BF16** for KV cache by default; consider **INT8** quantization for memory-constrained environments.
4. Leverage **prefix caching** for multi-turn conversations or RAG.
5. Avoid aggressive eviction unless long-context performance is not critical.

This tutorial provides the theoretical foundation and practical implementation details for mastering KV cache management in modern LLM inference systems.