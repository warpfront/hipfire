The fog did not roll in; it descended, a heavy, suffocating blanket of gray wool that smothered the world beyond the glass of the lantern room. Elara Vance stood by the brass railing, her knuckles white as she gripped the cold metal. The wind, usually a howling companion in these northern latitudes, had died into an eerie, pressurized silence.

In her pocket, the letter burned like a coal.

She had found it an hour ago, wedged between the barnacles of the lower jetty. The glass bottle was old, the cork rotted away, but the paper inside was crisp, white, and terrifyingly familiar. The ink was blue-black, the loops of the 'y' and the cross of the 't' identical to her own. It was dated tomorrow.

*Do not light the lamp tonight,* it read. *The light is not a guide. It is a lure. They are waiting in the dark.*

Elara looked out into the void. Through the swirling mist, she could see the faint, rhythmic pulse of a ship’s horn. It was the *Aethelgard*, a cargo freighter she had watched pass this point a hundred times. It was close. Too close. If she didn’t light the lamp, the *Aethelgard* would likely strike the Razor Rocks, a jagged spine of granite that lay submerged just two hundred yards off the coast. Thirty years of service had taught her that the light was the only thing standing between the living and the dead.

But the letter. Her own handwriting. A warning from a future that hadn’t happened yet.

"Elara?"

The voice came from the spiral staircase below. It was Thomas, her assistant, a young man with eager eyes and a heart too big for his chest. He climbed the last few steps, his boots clanging against the iron grating. He stopped when he saw her face, pale and rigid in the dim emergency lighting.

"The fog is thick, Elara. The *Aethelgard* is signaling. They’re asking for confirmation of the beacon." Thomas reached for the switch on the control panel, his hand hovering over the lever that would ignite the massive Fresnel lens.

"Don't," Elara said. Her voice was a rasp, dry and brittle.

Thomas paused, confused. "Elara? The ship is blind. If we don’t light it, they’ll run aground. You know the protocol."

"I know the protocol," she said, turning to face him. She pulled the letter from her pocket and held it out. "Read this."

Thomas took the paper, squinting in the low light. He read it once, then again. His brow furrowed. "This is... this is your handwriting. But the date is tomorrow. And the ink... it’s fresh."

"It’s a prank," Thomas said, though his voice wavered. "Someone is messing with us. Maybe a drunk sailor from the last supply run."

"Look at the seal," Elara whispered. "It’s the wax from my own stamp. The one I keep in the drawer. The one no one else has touched in a decade."

Thomas looked up, fear creeping into his eyes. "So what do we do? We can’t just leave the ship in the dark. People will die, Elara. Real people. Not ghosts."

Elara looked back out the window. The horn sounded again, closer now. A deep, mournful bellow that vibrated in her teeth. She could hear the engine now, a low thrumming that seemed to sync with her heartbeat.

"If I light it," Elara said, her mind racing, "I follow the present. I save the ship. But I ignore the warning. And if the warning is true, I am leading them into a trap."

"A trap?" Thomas scoffed, though he didn’t let go of the letter. "What kind of trap? The rocks? The rocks are natural. They don’t set traps."

"The letter says 'They are waiting in the dark.' Who is 'they'?"

Before Thomas could answer, the light in the lantern room flickered. Not the main lamp, which was still off, but the emergency bulbs. They buzzed, dimmed, and then surged with a strange, violet hue. The temperature in the room dropped sharply, their breath pluming in the air.

"Elara," Thomas whispered, backing away from the control panel. "What is that?"

Outside, the fog seemed to thicken, turning from gray to a bruised purple. The sound of the ship’s engine changed. It wasn’t just a mechanical thrum anymore; it sounded like a chorus of voices, low and guttural, rising from the water.

Elara grabbed Thomas’s arm. "Stay here. Don’t touch the switch. No matter what you hear."

"Elara, where are you going?"

"To the gallery. I need to see."

She stepped out onto the narrow catwalk that ringed the lantern room. The wind hit her like a physical blow, carrying the scent of ozone and rotting kelp. She looked down at the sea.

The water was not moving. The waves had ceased. The surface was a mirror of black glass, reflecting the violet glow of the lighthouse’s emergency lights. And in that reflection, she saw them.

Figures. Dozens of them. Standing on the surface of the water, just below the railing. They were translucent, made of mist and memory, their faces twisted in silent screams. They were looking up at her.

Elara stumbled back inside, slamming the heavy iron door shut. Her heart hammered against her ribs like a trapped bird.

"Did you see it?" Thomas asked, his face gray.

"I saw them," Elara breathed. "They’re not ghosts, Thomas. They’re echoes. The letter... it’s not a warning from the future. It’s a warning from the past. Or maybe the present, stretched thin."

"What does that mean?"

"It means the light doesn’t just guide ships. It feeds them. Every time we light the lamp, we pull something out of the deep. Something that wants to be seen."

The horn sounded again, but this time, it was distorted, stretched into a long, agonizing wail. The ship was right on top of them.

"We have to light it," Thomas said, his voice trembling. "If we don’t, the ship crashes. The crew dies. And then... then what? Do we let them die to save ourselves from some supernatural nonsense?"

Elara looked at the control panel. The lever was simple, brass and cold. One pull, and the great lens would ignite, casting a beam of pure, white salvation across the water. It would save the *Aethelgard*. It would save the sailors.

But it would also wake the things in the water.

She thought of the thirty years. The storms she had weathered. The ships she had guided home. She had always believed the light was a promise. *You are safe. You are seen. You are not alone.*

But what if the light was a lie? What if the safety was an illusion, and the darkness was the only truth?

"Thomas," she said softly. "If I light it, and the things come... can you fight them?"

Thomas shook his head, tears in his eyes. "No. I can’t."

"And if I don’t light it, and the ship crashes... can you live with that?"

Thomas looked at the letter, then at the window, then at Elara. He stepped back from the panel. "I can’t live with either. But you... you’ve been the keeper. You decide."

Elara walked to the window. The violet light was pulsing now, in time with the voices outside. The figures on the water were pressing against the glass, their mouths opening, though no sound came through.

She thought of the letter. *Do not light the lamp tonight.*

She thought of the ship. *The Aethelgard.*

She thought of the thirty years.

Elara reached into her pocket and pulled out a match. She struck it against the wall. The flame flared, bright and orange, a tiny defiance against the encroaching purple dark.

She didn’t go to the control panel. She went to the oil reservoir.

"Elara, what are you doing?" Thomas cried.

"If the light is a lure," Elara said, her voice steady now, "then we don’t give them the light. We give them the fire."

She poured the oil onto the floor of the lantern room, creating a slick, dangerous pool. Then, she took the match and dropped it.

The fire roared to life, not with the clean, white brilliance of the electric lamp, but with a chaotic, hungry orange blaze. It consumed the oil, climbing the walls, licking at the glass.

The effect was instantaneous.

The violet glow outside shattered. The figures on the water screamed—a sound that was not heard, but felt, a psychic shriek that tore through Elara’s mind. The fog boiled away, burned off by the intense heat radiating from the lighthouse.

For a second, the world was clear. Elara saw the *Aethelgard*. It was not a cargo ship. It was a vessel of black wood and bone, its sails tattered, its crew standing on the deck, their faces identical to the figures in the water. They were not sailors. They were the trapped. The lured.

The fire in the lighthouse was not saving them. It was burning the net.

The black ship lurched, its engines failing as the magnetic pull of the lighthouse was broken by the chaos of the fire. It drifted, not toward the rocks, but away, pushed by the sudden change in the air pressure, by the sheer force of the light’s rejection.

The fire alarm began to blare, a harsh, mechanical scream. Thomas grabbed Elara’s arm, pulling her toward the stairs. "We have to go! The whole tower is going up!"

Elara resisted for a moment, watching the black ship disappear into the now-clear night. The stars were visible again. The sea was just water. The monsters were gone, banished by the very thing they feared: uncontrolled, chaotic light.

"Go!" Thomas shouted, dragging her down the spiral stairs.

They ran through the corridors, the heat rising behind them, the smell of burning oil and ozone filling the air. They burst out of the base door and into the cool night air, collapsing on the grass as the lighthouse roared behind them.

The fire department arrived twenty minutes later, but the tower was already a skeleton of blackened iron. The great lens had melted, the glass shattered, the mechanism destroyed. The light was gone.

Elara sat on the grass, watching the flames die down. Thomas sat beside her, shaking, holding the letter.

"What did you do?" he whispered.

"I broke the cycle," Elara said. She looked at the letter in his hand. The ink was fading, the words dissolving into the paper as if they had never been written.

"But the ship..." Thomas started.

"The ship was already dead, Thomas," Elara said, her voice hollow. "It’s been dead for a long time. We were just keeping it alive with our light. We were feeding it."

She stood up, brushing ash from her coat. The lighthouse was dark. Truly dark. For the first time in thirty years, the coast was unlit.

"What will happen now?" Thomas asked. "Ships will crash. People will die."

Elara looked out at the horizon. The sea was calm. The stars were bright.

"Maybe," she said. "Or maybe, for the first time, they’ll find their own way. And maybe, just maybe, the things in the dark will stay there."

She turned and walked toward the keeper’s cottage, leaving the ruins of the lighthouse behind. The letter was gone. The warning was fulfilled. The light was out.

And in the silence, for the first time, Elara Vance was free.