# Technical Tutorial: Radix-Tree Prefix Caching for LLM Serving (Radix Attention)

## 1. Introduction

In Large Language Model (LLM) serving, **Key-Value (KV) Cache** management is the primary bottleneck for throughput and latency. When multiple requests share a common prefix (e.g., a system prompt, few-shot examples, or a long document), recomputing the KV cache for that prefix is wasteful.

**Radix Attention** (popularized by systems like **vLLM** and **SGLang**) uses a **Radix Tree** (also known as a Patricia Trie) to manage the KV cache. This allows for:
1.  **Automatic Prefix Sharing**: Identical prefixes across different requests share the same physical KV blocks.
2.  **Efficient Eviction**: Least Recently Used (LRU) or Least Frequently Used (LFU) eviction policies can be applied at the node level.
3.  **Dynamic Memory Management**: Blocks are allocated and freed dynamically as requests complete or new prefixes are added.

> **Crucial Distinction**: Radix Attention is a **cache management strategy**, not an attention kernel. The attention kernel (e.g., FlashAttention) still computes attention over the KV cache. Radix Attention determines *which* KV blocks are reused and *how* they are stored in GPU memory.

---

## 2. Core Concepts

### 2.1 The KV Cache and Blocks
In modern LLM serving, the KV cache is divided into fixed-size **blocks** (e.g., 16 tokens per block). Each block contains the Key and Value tensors for a sequence of tokens.

- **Block**: A contiguous chunk of GPU memory storing KV pairs for `block_size` tokens.
- **Block Table**: A mapping from logical token positions to physical block IDs.

### 2.2 Radix Tree Structure
A Radix Tree is a compressed trie where:
- **Edges** are labeled with sequences of tokens (not single tokens).
- **Nodes** represent shared prefixes.
- **Leaves** (or internal nodes with children) represent the end of a shared prefix or a unique continuation.

Each node in the tree points to a list of **physical KV blocks** that store the KV cache for the token sequence represented by the path from the root to that node.

### 2.3 Reference Counting
Each KV block (or node) has a **reference count** (`ref_count`). This counts how many active requests are currently using that block. A block can only be evicted if `ref_count == 0`.

---

## 3. Radix Tree Operations

### 3.1 Prefix Matching
When a new request arrives with a prompt `P`, the system traverses the Radix Tree to find the longest prefix of `P` that already exists in the cache.

**Algorithm**:
1. Start at the root.
2. Compare the current token sequence with the edge labels of child nodes.
3. If a match is found, move to the child node and continue.
4. If a partial match is found, split the edge (see 3.2).
5. If no match is found, stop. The matched path represents the reusable KV cache.

### 3.2 Node Splitting
If a new request shares a prefix with an existing node but diverges before the end of the node’s token sequence, the node must be **split**.

**Example**:
- Existing node: `["Hello", "world", "how", "are", "you"]`
- New request: `["Hello", "world", "how", "is", "it"]`

The common prefix is `["Hello", "world", "how"]`. The existing node is split into:
1. Parent node: `["Hello", "world", "how"]`
2. Child node 1: `["are", "you"]` (original continuation)
3. Child node 2: `["is", "it"]` (new continuation)

The KV blocks for the parent node are shared. The child nodes have their own KV blocks.

### 3.3 Sharing Immutable KV Blocks
KV blocks are **immutable** once written. This means:
- If two requests share a prefix, they point to the same physical blocks.
- If a request continues beyond the shared prefix, new blocks are allocated for the new tokens.
- This immutability simplifies concurrency and avoids race conditions.

### 3.4 Eviction Policy
When GPU memory is full, the system must evict unused blocks. Common policies:
- **LRU (Least Recently Used)**: Evict blocks that haven’t been accessed recently.
- **LFU (Least Frequently Used)**: Evict blocks with the lowest reference count or access frequency.

Eviction is performed on **leaf nodes** or nodes with `ref_count == 0`. If a node is evicted, its parent’s reference count is decremented. If the parent’s `ref_count` becomes 0, it may also be evicted (cascading eviction).

---

## 4. Worked Example

### Scenario
- **Block Size**: 2 tokens
- **Initial State**: Empty Radix Tree, empty KV cache.

### Step 1: Request A arrives with prompt `["A", "B", "C", "D"]`
1. **Prefix Match**: No match in tree.
2. **Allocate Blocks**:
   - Block 0: `["A", "B"]`
   - Block 1: `["C", "D"]`
3. **Insert into Tree**:
   - Root → Node 1 (`["A", "B", "C", "D"]`) → Blocks [0, 1]
   - `ref_count` for Node 1 = 1

### Step 2: Request B arrives with prompt `["A", "B", "E", "F"]`
1. **Prefix Match**:
   - Compare `["A", "B", "E", "F"]` with Node 1 (`["A", "B", "C", "D"]`).
   - Common prefix: `["A", "B"]`.
2. **Split Node 1**:
   - Create Parent Node 2: `["A", "B"]` → Blocks [0]
   - Create Child Node 3: `["C", "D"]` → Blocks [1] (original continuation)
   - Create Child Node 4: `["E", "F"]` → New Blocks [2, 3]
3. **Update Reference Counts**:
   - Node 2 (`["A", "B"]`): `ref_count = 2` (used by A and B)
   - Node 3 (`["C", "D"]`): `ref_count = 1` (used by A)
   - Node 4 (`["E", "F"]`): `ref_count = 1` (used by B)

### Step 3: Request A completes
1. **Decrement Reference Counts**:
   - Node 2: `ref_count = 1`
   - Node 3: `ref_count = 0`
2. **Eviction Check**:
   - Node 3 has `ref_count = 0`. It is a leaf. Evict Node 3 and its blocks [1].
   - Node 2 still has `ref_count = 1`, so it remains.

### Step 4: Request C arrives with prompt `["A", "B", "C", "G"]`
1. **Prefix Match**:
   - Match `["A", "B"]` with Node 2.
   - Next tokens `["C", "G"]` do not match any child of Node 2 (Node 3 was evicted).
2. **Allocate New Blocks**:
   - Block 4: `["C", "G"]`
3. **Insert into Tree**:
   - Node 2 → Child Node 5: `["C", "G"]` → Blocks [4]
   - `ref_count` for Node 5 = 1
   - `ref_count` for Node 2 = 2 (used by B and C)

---

## 5. Pseudocode

### 5.1 Radix Tree Node Structure
```python
class RadixNode:
    def __init__(self, tokens: List[int], blocks: List[int]):
        self.tokens = tokens  # Token sequence represented by this node
        self.blocks = blocks  # Physical KV block IDs for these tokens
        self.children = {}    # Map from first token of child sequence to child node
        self.ref_count = 0    # Number of active requests using this node
        self.last_access_time = time.time()  # For LRU eviction
```

### 5.2 Prefix Matching and Insertion
```python
def match_and_insert(root: RadixNode, prompt: List[int], block_allocator) -> Tuple[List[int], RadixNode]:
    """
    Matches the longest prefix of `prompt` in the radix tree.
    Returns the list of matched block IDs and the node where matching stopped.
    If the prompt is not fully matched, inserts the remaining tokens as a new node.
    """
    current_node = root
    matched_blocks = []
    remaining_tokens = prompt[:]
    
    while remaining_tokens:
        # Find child node that matches the first token of remaining_tokens
        first_token = remaining_tokens[0]
        if first_token not in current_node.children:
            break
        
        child_node = current_node.children[first_token]
        
        # Check how many tokens match between remaining_tokens and child_node.tokens
        match_len = 0
        for i in range(min(len(remaining_tokens), len(child_node.tokens))):
            if remaining_tokens[i] == child_node.tokens[i]:
                match_len += 1
            else:
                break
        
        if match_len == 0:
            break
        
        # Partial or full match
        if match_len < len(child_node.tokens):
            # Split the child node
            split_node = split_node(child_node, match_len, block_allocator)
            current_node.children[first_token] = split_node
            current_node = split_node
            matched_blocks.extend(split_node.blocks)
            remaining_tokens = remaining_tokens[match_len:]
        else:
            # Full match of child node
            current_node = child_node
            matched_blocks.extend(child_node.blocks)
            remaining_tokens = remaining_tokens[match_len:]
        
        current_node.ref_count += 1
        current_node.last_access_time = time.time()
    
    # If there are remaining tokens, create a new node
    if remaining_tokens:
        new_blocks = block_allocator.allocate(len(remaining_tokens))
        new_node = RadixNode(remaining_tokens, new_blocks)
        new_node.ref_count = 1
        new_node.last_access_time = time.time()
        current_node.children[remaining_tokens[0]] = new_node
        matched_blocks.extend(new_blocks)
    
    return matched_blocks, current_node
```

### 5.3 Node Splitting
```python
def split_node(node: RadixNode, split_index: int, block_allocator) -> RadixNode:
    """
    Splits a node at `split_index`.
    Returns the new parent node (which contains the first `split_index` tokens).
    """
    # Create new parent node with the first `split_index` tokens
    parent_tokens = node.tokens[:split_index]
    parent_blocks = node.blocks[:split_index // block_size]  # Assuming blocks align with tokens
    
    # Create new child node with the remaining tokens
    child_tokens = node.tokens[split_index:]
    child_blocks = node.blocks[split_index // block_size:]
    
    new_parent = RadixNode(parent_tokens, parent_blocks)
    new_child = RadixNode(child_tokens, child_blocks)
    
    # Transfer children from original node to new child
    new_child.children = node.children
    
    # Add new child to new parent
    new_parent.children[child_tokens[0]] = new_child
    
    # Update reference counts
    new_parent.ref_count = node.ref_count
    new_child.ref_count = node.ref_count
    
    return new_parent
```

### 5.4 Eviction
```python
def evict(root: RadixNode, block_allocator):
    """
    Evicts nodes with ref_count == 0, starting from leaves.
    Uses LRU policy.
    """
    # Collect all leaf nodes with ref_count == 0
    leaves_to_evict = []
    def collect_leaves(node):
        if not node.children and node.ref_count == 0:
            leaves_to_evict.append(node)
        for child in node.children.values():
            collect_leaves(child)
    
    collect_leaves(root)
    
    # Sort by last_access_time (LRU)
    leaves_to_evict.sort(key=lambda n: n.last_access_time)
    
    for node in leaves_to_evict:
        # Free blocks
        block_allocator.free(node.blocks)
        # Remove from parent
        parent = find_parent(root, node)
        if parent:
            del parent.children[node.tokens[0]]
            parent.ref_count -= 1
            # If parent now has ref_count == 0 and no children, it becomes a leaf
            # and may be evicted in the next iteration
```

---

## 6. Scheduling Concurrent Requests

Radix Attention integrates with the scheduler to maximize cache hits:

1. **Batching**: Group requests with similar prefixes.
2. **Preemption**: If a high-priority request needs memory, evict low-priority requests’ blocks.
3. **Chunked Prefill**: For long prompts, split the prefill into chunks. The first chunk may hit the cache, while subsequent chunks are computed.

---

## 7. Handling Divergent Conversation Histories

In multi-turn conversations, the history grows. Radix Attention handles this naturally:

- **Turn 1**: User asks `Q1`. Response `A1` is generated. The KV cache for `Q1 + A1` is stored in the tree.
- **Turn 2**: User asks `Q2`. The prompt is `Q1 + A1 + Q2`. The system matches `Q1 + A1` from the cache and only computes KV for `Q2`.
- **Branching**: If the user edits their previous message, the tree splits, and new branches are created. Old branches are evicted if no longer referenced.

---

## 8. Cache Management vs. Attention Kernel

| Aspect | Radix Attention (Cache Management) | Attention Kernel (e.g., FlashAttention) |
|--------|------------------------------------|-----------------------------------------|
| **Purpose** | Determine which KV blocks to reuse | Compute attention scores over KV blocks |
| **Data Structure** | Radix Tree | GPU Memory (Blocks) |
| **Operation** | Match, Split, Evict | Matrix Multiplication, Softmax |
| **Granularity** | Block-level (e.g., 16 tokens) | Token-level (within a block) |
| **Concurrency** | Reference counting, locking | Stateless (given KV blocks) |

The attention kernel receives a list of block IDs from the Radix Tree manager and computes attention over those blocks. The kernel does not know about the tree structure; it only sees a flat list of KV blocks.

---

## 9. Conclusion

Radix Attention provides an efficient, scalable way to manage KV caches in LLM serving by leveraging prefix sharing. By using a Radix Tree, it minimizes redundant computation, reduces memory usage, and improves throughput. The key challenges are efficient node splitting, accurate reference counting, and smart eviction policies. This approach is distinct from the attention kernel itself, which operates on the KV blocks provided by the cache manager.