"""Fixed correctness A/B. Canonical Rust serve + serve_harness, one load per arm.
Persist every completed row/request before the next question. No model tuning,
retry, output-limit escalation, or comparison to unrelated reference answers.
"""
from pathlib import Path
import os,sys,json,time,threading,subprocess,importlib.util,hashlib,traceback
ROOT=Path('/home/husrcf/Code/hipfire-fn-lru-prefill-20261029')
OUT=Path(__file__).resolve().parent
QC=Path('/home/husrcf/Code/hipfireQC')
PREVIOUS=QC/'tmpOutput/expert-lru-beta-20261025/prefill-restore-20261029'
MODEL=Path('/home/husrcf/.hipfire/models/qwen3.8-flash-next.mq4-xts')
COMMON={'HIPFIRE_MODELS_DIR':str(MODEL.parent),'HIPFIRE_MTP_MODE':'off','HIPFIRE_OFFLOAD_EXEC':'pcie','HIPFIRE_QWEN4_EXPERT_CACHE':'1','HIPFIRE_QWEN4_EXPERT_CACHE_TAIL_PERCENT':'50','HIPFIRE_QWEN4_EXPERT_CACHE_INFLIGHT':'64','HIPFIRE_QWEN4_DECODE_SHARE':'off','HIPFIRE_QWEN4_D2_DEFAULT':'0','HIPFIRE_PLE_FORMAT':'q4','HIPFIRE_PREFILL_CHUNK_ROWS':'4096','HIPFIRE_QWEN4_EXPERT_HOT_BUDGET_MIB':'18000','HIPFIRE_DN_STATE_EF':'1','HIPFIRE_NORMALIZE_PROMPT':'0','HIPFIRE_KERNEL_CACHE':str(PREVIOUS.parent/'update-f85ea28/shared-kernel-cache')}
# PREVIOUS.parent is expert-lru-beta-20261025; the cache is under update-f85ea28.
COMMON['HIPFIRE_KERNEL_CACHE']=str(QC/'tmpOutput/expert-lru-beta-20261025/update-f85ea28/shared-kernel-cache')

def sha(data):return hashlib.sha256(data).hexdigest()
def fixtures():
    raw=(QC/'longbench/longbench-hard30-pp32k.jsonl').read_bytes()
    lb=[json.loads(line) for line in raw.decode('utf-8').split('\n') if line.strip()]
    assert len(lb)==30
    for row in lb:assert hashlib.md5(row['prompt_no_think'].encode()).hexdigest()==row['prompt_no_think_md5']
    ld=json.loads((QC/'longdecode/questions.json').read_text());assert len(ld)==5
    return lb,ld

def worker(arm,suite):
    case=OUT/(arm if suite=='longbench' else arm+'-longdecode');case.mkdir(exist_ok=False)
    lb,ld=fixtures()
    for key in list(os.environ):
        if key.startswith('HIPFIRE_') or key in ('ROCR_VISIBLE_DEVICES','HIP_VISIBLE_DEVICES'):del os.environ[key]
    runtime=PREVIOUS/('runtime-'+arm)
    explicit=dict(COMMON,HIPFIRE_HOME=str(case/'parent-home'),HIPFIRE_CLI_BIN=str(runtime/'hipfire'),HIPFIRE_DAEMON_BIN=str(runtime/('daemon_lru_'+arm)))
    os.environ.update(explicit)
    manifest=json.loads((runtime/'MANIFEST.json').read_text())
    for name,binding in manifest['binaries'].items():assert sha((runtime/name).read_bytes())==binding['sha256']
    st=MODEL.stat();assert st.st_size==manifest['model']['size'] and st.st_mtime_ns==manifest['model']['mtime_ns']
    spec=importlib.util.spec_from_file_location('canonical_serve_harness',ROOT/'scripts/serve_harness.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    orig_spawn,orig_kill,orig_run,orig_send=m.spawn_serve,m._kill_serve,m.run,m.send
    launch_offset=None;phase=None;completed={};commands=[];observed=[];rows_per_phase={}
    def keep_after_success(cfg,home,log):
        nonlocal launch_offset
        offset=orig_spawn(cfg,home,log)
        if offset is not None:launch_offset=offset;m._kill_serve=lambda:None
        return offset
    def checked_run(cfg,args):
        assert launch_offset is not None
        m.apply_observed_kv_backend(cfg,m._serve_log_text(args.serve_log,launch_offset));m._assert_serve_path_proofs(cfg,args.serve_log,offset=launch_offset)
        offset=Path(args.serve_log).stat().st_size;cfg['_serve_log_offset']=offset
        rows=orig_run(cfg,args);m._assert_dflash_request_proofs(cfg,rows,args.serve_log,offset=offset)
        observed.append({'phase':phase,'harness_kv_metadata':[{k:r.get(k) for k in ('kv_mode','kv_backend','kv_backend_legacy','kv_backend_reason')} for r in rows]});return rows
    def checkpoint_send(cfg,messages,tools=None,max_tokens=None,max_think_tokens=None):
        body=m._request_body(cfg,messages,tools,max_tokens,max_think_tokens);wire=json.dumps(body,ensure_ascii=False).encode()
        row=orig_send(cfg,messages,tools,max_tokens,max_think_tokens)
        assert row['request_md5']==hashlib.md5(wire).hexdigest()
        prompt=messages[-1]['content'];row_copy=dict(row,prompt_md5=hashlib.md5(prompt.encode()).hexdigest())
        idx=len(completed.setdefault(phase,[]));taskid=lb[idx]['_id'] if phase=='longbench' else ld[idx]['genre'] if phase=='longdecode' else 'unscored-warmup'
        requestdir=case/'requests'/phase/(str(idx).zfill(2)+'-'+taskid);requestdir.mkdir(parents=True,exist_ok=False)
        (requestdir/'request.json').write_bytes(wire)
        (requestdir/'result.json').write_text(json.dumps(row_copy,ensure_ascii=False,indent=2)+'\n')
        (requestdir/'answer.md').write_text(row['assistant_content'])
        completed[phase].append(row_copy)
        temp=case/(phase+'.partial.tmp');temp.write_text(json.dumps(completed[phase],ensure_ascii=False,indent=2)+'\n');temp.replace(case/(phase+'.partial.json'))
        print(json.dumps({'arm':arm,'phase':phase,'completed':idx+1,'fixture_id':taskid,'gen':row.get('gen'),'finish':row.get('finish'),'wall_s':row.get('wall_s'),'prefill_ms':row.get('prefill_ms'),'prompt_md5':row_copy['prompt_md5'],'monotonic':time.monotonic()}),file=progress,flush=True)
        assert not row.get('stream_error') and row.get('terminal_count')==1 and row.get('saw_done') and row.get('post_terminal_bytes')==0,(phase,taskid,'transport terminal failure')
        assert row.get('finish') in ('stop','length'),(phase,taskid,'runtime error')
        return row
    m.spawn_serve=keep_after_success;m.run=checked_run;m.send=checkpoint_send
    (case/'longbench.prompts.json').write_text(json.dumps([{'genre':'lb-'+str(x['ordinal']).zfill(2),'prompt':x['prompt_no_think']} for x in lb],ensure_ascii=False)+'\n')
    # Local input corpora/request bodies are retained in QC only, not PR artifacts.
    (case/'longdecode.prompts.json').write_bytes((QC/'longdecode/questions.json').read_bytes())
    plans=[('warmup',16,['--prompt-file',str(ROOT/'benchmarks/prompts/fiction_lighthouse.txt')]),('longbench',512,['--prompts-file',str(case/'longbench.prompts.json')]),('longdecode',16384,['--prompts-file',str(case/'longdecode.prompts.json')])]
    plans=[plans[0]]+[p for p in plans if p[0]==suite]
    receipt={'arm':arm,'suite':suite,'settings':{'sampling':'greedy','temperature':0.0,'seed':123,'thinking':'off','speculation':'off','normalization':'off','max_seq':65536,'longbench_max_tokens':512,'longdecode_max_tokens':16384,'resident_budget_mib':18000},'env':explicit,'runtime_manifest':manifest,'commands':commands,'completed':{},'phase_results':[],'expected':{suite:30 if suite=='longbench' else 5},'fixture_hashes':{str(x.relative_to(QC)):sha(x.read_bytes()) for x in [QC/'longbench/longbench-hard30-pp32k.jsonl',QC/'longbench/longbench-hard30-pp32k.manifest.json',QC/'longdecode/questions.json']},'timing_claim':False,'protocol':'canonical serve_harness, suite-separated matched processes; independent questions, same warmup; canonical quality FAIL retained, no cap escalation','observed_backend_receipts':observed}
    (case/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
    stop=threading.Event();peaks={}
    def sample():
        with (case/'memory.jsonl').open('w') as out:
            while not stop.is_set():
                row={'time_monotonic':time.monotonic()}
                for kind in ('vram','gtt'):
                    try:row[kind+'_used_bytes']=int(Path('/sys/class/drm/card1/device/mem_info_'+kind+'_used').read_text())
                    except OSError:pass
                for k,v in row.items():
                    if k.endswith('_used_bytes'):peaks[k]=max(peaks.get(k,0),v)
                out.write(json.dumps(row)+'\n');out.flush();stop.wait(.1)
    thread=threading.Thread(target=sample,daemon=True);thread.start();start=time.monotonic();error=None
    with (case/'progress.jsonl').open('w',buffering=1) as progress:
        try:
            for index,(phase,cap,extra) in enumerate(plans):
                args=['scripts/serve_harness.py','--model',str(MODEL),'--tag','qwen3.8:flash-next','--registry',str(ROOT/'registry/models.json'),'--speculation','off','--thinking','off','--max-tokens',str(cap),'--max-seq','65536','--sampling','greedy','--seed','123','--mode','battery','--port','11588','--home',str(case/'home'),'--serve-warm-timeout-secs','1800','--serve-log',str(case/'serve.log'),'--out',str(case/(phase+'.json')),'--replay-route-proof-log']+extra
                if index:args+=['--no-spawn']
                commands.append(args);sys.argv=args;began=time.monotonic()
                print(json.dumps({'arm':arm,'phase':phase,'event':'start','monotonic':began}),flush=True)
                with (case/(phase+'.log')).open('w',buffering=1) as log:
                    savedout,savederr=sys.stdout,sys.stderr;sys.stdout=sys.stderr=log
                    try:m.main()
                    finally:sys.stdout,sys.stderr=savedout,savederr
                m._kill_serve=orig_kill
                rows_per_phase[phase]=json.loads((case/(phase+'.json')).read_text());receipt['completed'][phase]=len(completed[phase]);receipt['phase_results'].append({'phase':phase,'status':'PASS','elapsed_s':time.monotonic()-began})
                (case/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')
                print(json.dumps({'arm':arm,'phase':phase,'event':'pass','rows':len(completed[phase])}),flush=True)
        except BaseException as exc:
            error=repr(exc);receipt['failure']=error;(case/'driver-error.log').write_text(traceback.format_exc());raise
        finally:
            m._kill_serve=orig_kill;orig_kill();stop.set();thread.join();receipt.update(status='FAIL' if error else 'PASS',elapsed_seconds=time.monotonic()-start,observed_sampled_global_peaks=peaks,completed={k:len(v) for k,v in completed.items()});(case/'run.json').write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':
    if len(sys.argv)>1:worker(sys.argv[1],sys.argv[2])
    else:
        results=[]
        for arm,suite in [('new','longbench'),('old','longdecode'),('new','longdecode')]:
            r=subprocess.run([sys.executable,str(Path(__file__).resolve()),arm,suite],cwd=ROOT)
            case=OUT/(arm if suite=='longbench' else arm+'-longdecode')
            entry={'arm':arm,'suite':suite,'canonical_exit_code':r.returncode}
            if r.returncode:
                receipt=json.loads((case/'run.json').read_text())
                rows=json.loads((case/(suite+'.partial.json')).read_text())
                complete=len(rows)==(30 if suite=='longbench' else 5)
                healthy=all(not x.get('stream_error') and x.get('saw_done') and x.get('terminal_count')==1 and x.get('post_terminal_bytes')==0 and x.get('finish') in ('stop','length') for x in rows)
                quality_only='produced a token attractor' in receipt.get('failure','')
                entry.update(full_suite_emitted=complete,transport_healthy=healthy,canonical_quality_failure_retained=quality_only)
                results.append(entry);(OUT/'suite-matrix.json').write_text(json.dumps(results,indent=2)+'\n')
                if not (complete and healthy and quality_only):raise SystemExit(r.returncode)
                print(json.dumps({'event':'continue_independent_suite_after_recorded_canonical_quality_failure',**entry}),flush=True)
            else:
                results.append(entry);(OUT/'suite-matrix.json').write_text(json.dumps(results,indent=2)+'\n')
        raise SystemExit(1 if any(x['canonical_exit_code'] for x in results) else 0)
