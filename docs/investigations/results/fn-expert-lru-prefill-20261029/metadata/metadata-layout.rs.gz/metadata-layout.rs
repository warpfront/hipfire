#![allow(dead_code)]
use hipfire_dispatch::pipeline::sealed_moe::{ExpertMetadata,ExpertResource,ExpertTable,ExpertBindingCache};
use rdna_compute::{GpuTensor,DType};
struct ProjectionLayout { tensor:GpuTensor,dtype:DType,m:usize,k:usize,row_stride:usize,host_mapped:bool }
struct LiveTensorLayout { ptr:usize,byte_capacity:usize,tail:usize,shape:Box<[usize]>,dtype:DType }
struct LiveWeightLayout {buffer:LiveTensorLayout,dtype:DType,m:usize,k:usize,row_stride:usize}
#[no_mangle] pub static SIZE_EXPERT_METADATA:usize=std::mem::size_of::<ExpertMetadata>();
#[no_mangle] pub static SIZE_EXPERT_RESOURCE:usize=std::mem::size_of::<ExpertResource>();
#[no_mangle] pub static SIZE_EXPERT_TABLE:usize=std::mem::size_of::<ExpertTable>();
#[no_mangle] pub static SIZE_BINDING_CACHE:usize=std::mem::size_of::<ExpertBindingCache>();
#[no_mangle] pub static SIZE_GPU_TENSOR:usize=std::mem::size_of::<GpuTensor>();
#[no_mangle] pub static SIZE_PROJECTION_LAYOUT:usize=std::mem::size_of::<ProjectionLayout>();
#[no_mangle] pub static SIZE_LIVE_WEIGHT_LAYOUT:usize=std::mem::size_of::<LiveWeightLayout>();
#[no_mangle] pub static SIZE_WEIGHT_REF:usize=std::mem::size_of::<hipfire_dispatch::families::gemv::WeightRef>();
fn main() {}
