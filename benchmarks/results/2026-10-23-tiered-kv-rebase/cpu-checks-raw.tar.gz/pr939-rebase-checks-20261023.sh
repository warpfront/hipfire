#!/usr/bin/env bash
set -uo pipefail
cd /home/husrcf/Code/ProtBind/hipfireTMP/hipfire-tiered-kv || exit 2
while IFS= read -r var; do unset "$var"; done < <(compgen -e | rg '^HIPFIRE_' || true)
export ROCR_VISIBLE_DEVICES=-1 HIP_VISIBLE_DEVICES=-1
HIPFIRE_HOME=$(mktemp -d /tmp/pr939-rebase-home.XXXXXX)
HIPFIRE_LOCK_DIR=$(mktemp -d /tmp/pr939-rebase-lock.XXXXXX)
export HIPFIRE_HOME HIPFIRE_LOCK_DIR
pr939_failed=0
run() {
    local label=$1
    shift
    "$@" > "/tmp/pr939-rebase-${label}-20261023.log" 2>&1
    local result=$?
    printf '%s\t%s\n' "$label" "$result"
    if (( result != 0 )); then pr939_failed=1; fi
}
git rev-parse HEAD
git rev-parse origin/beta
run workspace-examples cargo check --workspace --examples --locked
run lab-examples cargo check --locked -p hipfire-arch-qwen35 --features lab --example qwen35_tiered_kv_oracle --example qwen35_tiered_prefill_oracle
run positions cargo test --locked -p hipfire-arch-qwen35 --features lab --lib positioned
run carrier cargo test --locked -p hipfire-arch-qwen35 --features lab --lib carrier::tests
run storage cargo test --locked -p hipfire-runtime --features lab --lib tiered_kv
run example-tests cargo test --locked -p hipfire-arch-qwen35 --features lab --example qwen35_tiered_prefill_oracle
run recording cargo test --locked -p railgun-cert --lib
run dispatch cargo test --locked -p hipfire-dispatch --lib
run python python3 -m unittest scripts/test_compare_tiered_kv_oracles.py scripts/test_compare_tiered_prefill_oracles.py scripts/test_tiered_kv_vram_guard.py
run workspace-lib cargo test --workspace --lib --locked --no-fail-fast
run precommit bash scripts/pre-commit-ci.sh origin/beta
exit "$pr939_failed"
