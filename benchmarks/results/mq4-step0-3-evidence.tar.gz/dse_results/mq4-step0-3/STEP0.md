# Step 0 — fixed identities and observed routes

Upstream beta HEAD at campaign start: 8d302c342f5abacfa455b0bb347b37c4c6b411b6. Clean worktree hipfire-mq3-latest-repro. Experimental worktree hipfire-mq4-step0-3 is based on it, with packed patch38d68e211; later wide edits are separately frozen with source.diff and binary hash. Do not read mutable target/release as a pinned test identity.

GPU1: W7900 gfx1100, PCI0000:9e:00.0. Linux7.0.0-34-generic, HIP7.15.26333-0000000 under /opt/rocm/core-10.0. GPU lock respected; no simultaneous GPU workloads in this campaign.

## Models (local artifacts, unchanged)

| Model | SHA256 | MD5 | Indexed dtype counts |
|---|---|---|---|
| Qwen3.6-27B MQ4 | 86a5f80fd29d545abb1093dead242725ced6d68b8607c6d566d897b1a82442dc | e42a489edf0be1b144307f2869b73b93 | qt13:497, qt3:49, qt1:673 |
| Qwen3.8-27B MQ4-XT | 9f91556f7e0431a077d03756a7102d0154108757289e6e5fe9a2d204c0c9eeb7 | e45d15bfe0c9a87132697101d17cbed6 | qt44:497, qt3:49, qt1:305 |

Counts alone are not proof of runtime dtype; examples of Q8 tensors include embedding and LA conv1d. Runtime all-projection checks gate widened admission. XT is an older local artifact, not claimed as the current canonical XT registry pin. Cross-model ratios are not format-only causal evidence.

## Route distinction

Default gfx1100 large-batch ordinary MQ4:
- QKVZA/QKV/gate-up: should_use_mmq>=128, shared Q8_1 packing then MMQ SETs.
- Residual wo/down: gemm_hfq4g256_residual -> should_use_mmq -> MMQ residual.
- Main scratch ceil(K/128)*rows*144; 153MiB for K17408/rows8192.
- 2..127-row tails can fall back to FP16/ksplit; these need separate bounded scratch accounting.

XT: V2-only prepared IU4 producers and widened/lean admission; exact path predicates are not shared by simply changing a dtype guard. Ordinary MQ4 remains full PBS and segmented Q8/EF GDN; no V2 producer or GDN scan admission is expanded.

MQ3 registry checkpoint failure reproduced on clean beta and tracked at https://github.com/warpfront/hipfire/issues/789. It does not block this MQ4-only campaign.

Following user correction, do not add further XT ablation stages. Apply changes directly to MQ4, one at a time, and verify both PP and TG before retaining them.
