# Step 2 — ordinary MQ4 packed prefill, verification in progress

Source: beta 8d302c342 plus opt-in packed patch 38d68e211. Exact pinned daemon: /tmp/mq4-packed-38d68e211/daemon SHA256 300f37cf3634440860f90e33183ce7bdb1b859c6f75bed45d2d9fd9ce520e589. New wide-MQ4 edits are NOT in this binary.

Same Qwen3.6-27B MQ4, PP8192 prompt, chunk512, max_seq16384, Q8/VMM, stateQ8, AR, verifygraph0. One fresh process per sample, three complete prompt warmups, packed flag0/1/1/0. Both SET and ADD route markers observed for packed.

| Arm | PP tok/s | Decode tok/s | Generated tokens |
|---|---:|---:|---:|
| native A1 | 792.1 | 37.0 | 212 |
| packed B1 | 964.2 | 37.0 | 229 |
| packed B2 | 962.9 | 36.9 | 229 |
| native A2 | 789.0 | 37.0 | 212 |

PP means790.55→963.55 (+21.88%). Decode rates are context only: EOS lengths differ, so matched-length TG512 follow-up is REQUIRED before claiming no regression. Both completions are readable; the requested linked-list reversal code is correct. Text differs; no bit-exact or quality-neutral claim.

100ms sysfs VRAM samples (device0000:9e:00.0), NOT allocator-exact peak: native17,237,073,920/17,237,082,112B; packed17,241,559,040B both runs. Approximately4.3MiB difference. Raw results: results/mq4-step2-packed-abba, unchanged logs.

Synthetic actual-shape microbench (attribution only, includes activation preparation):
- M17408/K5120/N512 SET: incumbent1778.160us, packed1210.462us.
- M5120/K17408/N512 ADD: incumbent2087.984us, packed1347.711us.
- Synthetic non-exact activations show relativeL2 differences0.00966/0.01375 versus incumbent. Both are finite. This is not CPU-oracle equivalence or a numerical-accuracy pass: grouping/rounding differs and requires E2E quality checks. The earlier exactly-representable CPU layout oracle remains a separate test.

Disposition: measured prefill improvement, NOT production-ready. Pending matched-length decode, serve/state checks, Redline and broader quality evidence.

## Matched-length decode follow-up

Same pinned binary, chunk512 ABBA, adaptive_kv_long_prefill.txt (936 rendered tokens), three complete warmups, TG512. Results in results/mq4-step2-decode512-abba; hashes verified. Native38.3/38.2 versus packed38.0/38.1 tok/s (means38.25→38.05, -0.52%). All four emit512 tokens. Text is stable within each arm but differs across arms. No large decode regression observed; small sub-percent change is not claimed as mathematical equivalence.

Short-prompt PP values582.8/684.5 versus748.4/747.4 are NOT used as a speedup claim: native first measured PP is unstable relative to its warmups. The authoritative prefill result remains matched PP8192 above. Readable technical review output is limited fluency evidence, not a comprehensive quality gate.
