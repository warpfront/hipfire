# Step 3: native MQ4 wide prefill

Experimental, default-off. Native MQ4 only; packed FFN disabled.
Binary: `/tmp/mq4-wide-step3/daemon`, SHA256
`e91f59e48bc23b927f1a72e96609e4c51549035dc53b8014a5cc71bfe9813ac8`.

## 512 versus 1024 rows

Raw evidence: `results/mq4-step3-1024-abba`. All per-arm raw SHA256
manifests verified after completion. PP8192, 3 full warmups and 1 measured
request per process, fresh-process ABBA. Each measured response emitted
212 tokens, stopped naturally below the 256-token cap.

| Arm | PP tok/s | Decode tok/s | Sampled peak VRAM bytes |
|---|---:|---:|---:|
| 512 A1 | 790.1 | 36.9 | 17249067008 |
| 1024 B1 | 848.9 | 36.9 | 17624317952 |
| 1024 B2 | 847.4 | 36.9 | 17624317952 |
| 512 A2 | 788.4 | 36.9 | 17237069824 |

Mean PP 789.25 -> 848.15 tok/s (+7.46%). Decode unchanged at the
reported resolution. Telemetry peaks are sampled device usage, not exact
allocator peaks. This is one prompt, not broad quality validation.

## 512 versus 2048 rows

Raw evidence: `results/mq4-step3-2048-abba`, audited with
`summarize_mq4_abba.py`. Same protocol as above.

| Arm | PP tok/s | Decode tok/s | Sampled peak VRAM bytes |
|---|---:|---:|---:|
| 512 A1 | 793.2 | 36.9 | 17237065728 |
| 2048 B1 | 863.5 | 37.0 | 18423869440 |
| 2048 B2 | 849.8 | 36.9 | 18423873536 |
| 512 A2 | 787.6 | 36.9 | 17237069824 |

Mean PP 790.4 -> 856.65 tok/s (+8.38%); decode 36.9 -> 36.95
(+0.14%, not a meaningful speed claim). All four measured outputs are
identical, 212 tokens, SHA256
`3bd1dc7c7d94e0b4d5a494b2e70e95bb29b2bdb830ed2d87add094ed0309c42b`.
Raw checksums match; actual wide receipts show 2048/commit_stride512.
Candidate PP has 13.7 tok/s spread, retained rather than discarded.
Sampled peak VRAM increases about 1.11 GiB.

## State-boundary comparison: native 512 versus 2048

Evidence: `results/mq4-state-boundary-2048`; runner
`run_mq4_state_boundary.py`; pinned oracle SHA256
`3e64afd7b223a7815a814c6f75931bbe85b117c3422becb4ff42ee75252dceca`.
Oracle compiled successfully; CPU decode unit tests 2/2 passed.

Rows 513, 1025, 8193, each followed by four teacher-forced continuation
tokens. Each comparison has 646 numeric records, zero differing values,
zero nonfinite values. The 8193 comparison also explicitly reports zero
raw byte mismatches. Wide execution receipts confirm admitted 2048 and
commit_stride 512. Compared logits, valid-prefix Q8 K/V, all LA Q8 state
codes/scales, EF, conv, and reconstructed state/state+EF before and after
continuation. This covers those states and inputs, not arbitrary long
generation or serving lifecycle correctness.

## 512 versus 4096 rows

Raw evidence: `results/mq4-step3-4096-abba`, checksum and receipt audit
completed with `summarize_mq4_abba.py`.

| Arm | PP tok/s | Decode tok/s | Sampled peak VRAM bytes |
|---|---:|---:|---:|
| 512 A1 | 790.2 | 36.9 | 17234382848 |
| 4096 B1 | 871.5 | 36.9 | 19723632640 |
| 4096 B2 | 870.6 | 36.9 | 19723632640 |
| 512 A2 | 789.1 | 36.9 | 17725530112 |

Means: PP 789.65 -> 871.05 (+10.31%), decode unchanged (36.9).
All four measured texts identical, 212 tokens, same SHA256 as previous
native chunk runs. Wide receipts confirm 4096/commit_stride512. Sampled
baseline VRAM peak varies between arms; do not infer exact allocator costs.

## 512 versus 8192 rows

Raw evidence: `results/mq4-step3-8192-abba`, checksum/receipt/text audit
completed with `summarize_mq4_abba.py`.

| Arm | PP tok/s | Decode tok/s | Sampled peak VRAM bytes |
|---|---:|---:|---:|
| 512 A1 | 796.9 | 36.9 | 17234411520 |
| 8192 B1 | 875.3 | 37.0 | 22773260288 |
| 8192 B2 | 873.6 | 36.9 | 22773272576 |
| 512 A2 | 789.1 | 36.8 | 19944316928 |

Mean PP 793.0 -> 874.45 (+10.27%); decode 36.85 -> 36.95 (+0.27%,
not a meaningful standalone speed claim). All four measured outputs remain
identical at 212 tokens. Wide receipt: 8192/commit_stride512.
Candidate peak is ~21.21 GiB versus ~18.37 GiB for the earlier 4096 run.
Baseline peak varies substantially, so these are device samples rather
than exact allocation deltas. Across sessions, 8192's throughput is only
~0.4% above 4096; do not claim that difference is a robust gain.

Next: build and validate packed/wide composition; do not run further XT ablations.
2048 state-boundary checks are complete. Serving checks, longer decode,
larger-rung state checks and combined packed/wide validation remain pending.
No production promotion.
