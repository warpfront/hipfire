# Step 1 — measured XT chunk effect

Clean beta 8d302c342f5abacfa455b0bb347b37c4c6b411b6, W7900 GPU1 gfx1100.
Daemon md5 9be9932d44ac1a07736a11be6bf7b5f6.
XT model md5 e45d15bfe0c9a87132697101d17cbed6; ordinary MQ4 model md5 e42a489edf0be1b144307f2869b73b93 (not run in this stage).
Prompt md5 739779001c736cf8a87219d0bd148780. Q8 KV/VMM, max_seq16384, stateQ8 EF default, no speculation, verifygraph0, TG256.

Fresh-process ABBA. Three full PP8192/TG256 warmups per process, reset between requests, shared kernel cache. First cold warmup is excluded. Raw evidence: results/mq4-step1-xt-abba. All raw stdout/stderr/request hashes verified after process exit.

| Run | Requested chunk | PP tok/s | Decode tok/s | Generated |
|---|---:|---:|---:|---:|
| A1 | 512 | 1601.5 | 37.2 | 256 |
| B1 | 8192 | 1731.3 | 37.0 | 256 |
| B2 | 8192 | 1710.0 | 36.9 | 256 |
| A2 | 512 | 1547.0 | 36.8 | 256 |

Means: PP1574.25→1720.65 (+9.30%); TG37.00→36.95 (-0.14%, inside observed within-arm spread).
All four measured text hashes: bce6f7394489c062e0e22572e464f3140997bd6d4b4239be482c95c1e8de80a1.
Decoded text is readable code/explanation, length-capped. This synthetic prompt is not a quality benchmark. Output parity supports this one configuration only.

Interpretation: widened scheduling is material but does not explain the roughly2x cross-model XT-vs-MQ4 deployment gap. Width changes may also select lean PBS and changed recurrent scheduling, so this is the integrated chunk route effect, not a pure GEMM-only ablation. No production change was made.

Limitations: two fresh-process samples per arm; monotonic clock/thermal drift is visible in A1/A2. No continuous VRAM telemetry for this stage; later stages add it. Do not claim a peak memory number from this run. Next: native MQ4 chunk512 packed-off/on, no wide-MQ4 code active.
