# MQ4 Step 0–3, 2026-09-29

Scope: gfx1100 W7900, ordinary Qwen3.6-27B MQ4 prefill. XT is a within-model control for chunk effects, NOT format-only causal evidence across model generations.

Baseline: clean upstream beta 8d302c342. Pinned daemon /tmp/mq3-beta-8d302c342/daemon. Prior baseline da629b75d results are historical for this campaign.

Historical sequence already executed (each stage independently verified):

0. Fix binary/model/prompt identities and runtime route. MQ3 failure tracked separately in #789.
1. XT chunk512/8192, fresh-process ABBA, 3 full PP8192 warmups, then measured PP8192 + TG256. Keep all raw stdout, stderr and requests.
2. Original MQ4 chunk512 incumbent versus opt-in packed FFN, actual-shape microbench plus E2E ABBA. No wide-chunk candidate in this comparison.
3. Original MQ4 native kernels, widened rungs 1024/2048/4096/8192, retaining 512-row recurrent commit semantics. No packed flag. Audit memory/capability predicates before admitting each rung. Compare against chunk512, validate quality/reset and decode at each stage.

Acceptance: a prefill gain must exceed paired observed spread and must not conceal a decode regression. Every warmup and measured request records prefill/decode speeds and emitted count. Different emitted counts are not comparable decode measurements. Long decoded output is inspected before keeping candidates. GPU dispatch/Redline and serve checks are required before promotion, not inferred from benchmark completion.

No production/default change from exploratory results. No raw artifact rewriting. Parameter ranges are the existing staged rungs; do not widen beyond8192 automatically.

## User-corrected execution order

Apply the identified differences to ordinary MQ4 first, then measure the
combined candidate against ordinary MQ4's incumbent. Do not start another
XT ablation or delay this direct test behind component ablations. Investigate
components only if the direct result is ambiguous or regresses.

The final direct matrix is `final-mq4-tg1024.json`: same ordinary MQ4 model,
exact PP8192 prompt, TG1024, native512 versus packed4096, fresh-process ABBA.
Every arm records decode alongside prefill. The separate MQ4V2 one-arm run
is compatibility coverage, not another XT optimisation/ablation campaign.
