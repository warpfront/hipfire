# Final candidate validation (in progress)

The previous performance/serving binary stays immutable. Final source adds
MQ4V2/packed safety guards: no lean PBS for packed FFN, fallback for explicit
lean owners, additional packed scratch budget beside V2 IU4, and minimum
512-row scratch reservation with packed-only opt-in. Defaults unchanged.
Do not silently attribute old raw results to this new binary.

Final build: `/tmp/mq4-final-step3/daemon`
SHA256 `7fd4f6840b5989df255a7d4e0f6426fb869e9481adc5f5eb5db27874a89a673c`.
State oracle: `/tmp/mq4-final-step3/mq4_prefill_state_oracle`
SHA256 `bfea01933785c2f64e6934ee70e213296d7b4f06e63b42d1030c4edc5542766e`.
Both built with flash-attn-ck enabled; state comparisons use the same binary
on both arms. Tracked source diff preserved next to binaries.

Prefill unit module: 62 passed, 6 ignored (before final minimum reservation
change; final rerun remains required). Diff whitespace check passes.

Running `results/mq4-final-packed-state`: packed512 vs packed4096, rows
4096/4097/8193, four teacher-forced continuation tokens. Requires executed
chunk receipts and packed SET/ADD markers, not merely enabled flags.

Pending: inspect state reports, native larger-rung state check, final
decode/perf recheck, MQ4V2 compatibility smoke, serving lifecycle and
Redline/capture checks. No production promotion or PR yet.

## Boundary finding: 4097 rows

4096 packed512/packed4096: all 646 numeric records exact, no nonfinite.
4097: wide planner used 4095+2, neither eligible for packed, while legacy
512 used seven packed512 segments then 511+2. The harness correctly exposed
the missing packed marker but its expectation assumed aligned execution.
Both raw dumps completed; CPU comparison saved separately at
`/tmp/mq4-final-4097-compare.jsonl`: 632/646 records differ, no nonfinite;
logit argmax agrees at measured positions, but differences are substantial.
This is not declared a pass or hidden by relaxing the assertion.

Fix in progress: packed-aware grouping coalesces only full legacy512
segments and retains identical irregular tails (4097 -> 3584+511+2).
Exhaustive CPU test compares recurrent commit lengths AND per-segment
packed/native route for all lengths 2..16385 and every wide rung. Native
non-packed scheduling is unchanged. New binary/retest needed; old artifacts
remain untouched. The original state runner stopped before 8193; it did not
test that case.

Tail-fix unit module: 63 passed, 6 ignored; release build succeeds.
Pinned daemon `/tmp/mq4-tail-step3/daemon`, SHA256
`1006155d92a091002e7eb7ad53792b5dda2d54135ccccab43ffc1671493709ed`.
Oracle SHA256
`c7b8e19aa0e7e6a486d355399446ad4466df007f5a1b4cb1615f64edcace8803`.
Retest in `results/mq4-tail-packed-state`, rows4097/8193, started with
fresh directories. Earlier 4096 exact result remains pre-tail-fix evidence;
the aligned4096 schedule is unchanged, but new results must be identified
with the new binary.

Tail-fix GPU state results complete: 4097 and 8193 each have 646 comparison
records, zero numeric differences, zero raw-byte mismatches, zero nonfinite
values. Includes all dumped KV/recurrent state and four teacher-forced
continuation logits. 4097 wide logs explicitly show packed SET/ADD at N3584.
This resolves the diagnosed chunk-dependent quantization-path mismatch on
these boundary cases; it does not make packed identical to native MQ4.

Final same-binary performance recheck started: `results/mq4-tail-final-abba`,
PP8192/TG1024, native512 versus packed4096, 3 warmups and fresh-process ABBA.

Remaining checks queued in tmux `mq4-tail-remaining` with the same GPU lock,
waiting for `mq4-tail-final-abba` to release it. Runner:
`run_mq4_tail_remaining.sh`. In order: native512/native8192 state at 8193
rows, one-arm MQ4V2 packed compatibility smoke, then final combined-only
five-prompt serving battery (existing native serving evidence stays intact).
Each writes a new output directory; no old raw results are overwritten.
Redline/capture and serving lifecycle checks are still pending separately.

## Final direct ordinary-MQ4 ABBA complete

Source: `results/mq4-tail-final-abba`, final tail-fixed daemon SHA256
`1006155d92a091002e7eb7ad53792b5dda2d54135ccccab43ffc1671493709ed`.
Read-only `summarize_mq4_abba.py` verifies every raw-file hash, raw done
event against derived measurement, PP8192 with zero cached tokens, admitted
chunk/commit-stride receipts and executed packed SET/ADD markers.

| Arm | PP tok/s | Decode tok/s | Emitted tokens |
|---|---:|---:|---:|
| A native512 | 784.7 | 36.7 | 1024 |
| B packed4096 | 1051.7 | 36.7 | 1024 |
| B packed4096 | 1050.9 | 36.6 | 1024 |
| A native512 | 784.9 | 36.7 | 1024 |

Means: PP784.8 ->1051.3 (+33.9577%); decode36.70 ->36.65 (-0.1362%).
One prompt, two fresh-process measurements per arm; not a broad quality gate.
Each process performed three full warmups, excluded from these means.
Within-arm text SHA256 repeats exactly; cross-arm text differs. Hashes match
the earlier long-decode run, whose factual/formula errors were documented
for BOTH arms. No claim that quantized packed activation is lossless.
Sampled device peak: native17384370176 B; candidate19726008320 B (~2.18 GiB
additional). These are device samples, not a precise allocator attribution.

After ABBA, `mq4-tail-gates` won the shared lock and began Redline/PM4
capture+shadow, followed by three related serving turns beginning with a
long KV-cache prompt. `mq4-tail-remaining` is still queued; order changed
through normal flock scheduling, with no overlapping GPU tests.

## Capture and lifecycle findings

Candidate cold prefill capture refused before parity with
`wide gfx11 FA2 Q16 scratch must be grown before graph capture/recording`.
Raw evidence: `results/mq4-tail-gates/redline-harness.log` and
`redline-daemon.log`. No pass is claimed. A clean-beta full-harness control
and candidate decode-only multi-position PM4 check are queued under
`run_mq4_capture_control.sh`; this separates cold-capture preparation from
the changed prefill path. Do not assume baseline fault before that result.

Related-turn serving completed: context6029/7084/7456, cached0/4096/7418,
generated1024/333/607, finish length/stop/stop. No attractor, empty output,
stream error, or extra terminal event. Text read in full: coherent discourse
and correct GQA cache formula in turn2, but turn1 has an incorrect numerical
example (32*32*4096*8*128*2*2 is 16GiB, not 1GiB) and overstates KV caching
as making the whole per-token computation O(1); turn3 conflates radix and
paged storage concepts. This is bounded lifecycle/coherence evidence only,
not factual-quality or numerical-equivalence proof. Timings include cold
JIT and are not performance evidence. Raw JSON unchanged at
`results/mq4-tail-gates/chain/combined/results.json`.

Native MQ4 larger-rung state coverage complete on the final oracle:
`results/mq4-tail-native8192-state/8193-compare.jsonl` has 646 records,
zero numeric differences, zero nonfinite values, and zero mismatches across
the 454 raw-byte-comparable records. The other 192 records are derived
dequantized comparisons and have `raw_byte_mismatches: null` (not a failure
count). Both arms cover 8193 prefill rows plus four teacher-forced decode
steps, native512 versus native8192, packed OFF. MQ4V2 smoke now running.

MQ4V2 compatibility smoke complete at `results/mq4-tail-v2-smoke`:
PP8192, cached0, TG256. Final raw-file SHA256 manifest verified. Receipt
requested/admitted4096, recurrent stride512; both executed markers show
format=mq4v2, gate/up17408x5120 and down5120x17408 at N4096. Measured
PP1267.0/TG36.4 tok/s is a single compatibility sample on the old local XT
artifact, NOT canonical XT performance evidence or a cross-model speedup.
Final combined-only five-genre serving is now running.

Final five-genre serving complete (`results/mq4-tail-serving/combined`):
all five have cached0, contexts6014/6024/6037/6029/6027, gen1024,
one terminal event, no stream error/empty/attractor. Text inspected in full.
Snake/Tetris are coherent but truncated code, story is coherent, KV explanation
retains the arithmetic/complexity errors already seen in the chain. Radix
explanation is broadly coherent but its pseudocode is incomplete and does
not implement the compression/eviction semantics it describes. This passes
the bounded non-collapse/lifecycle check, not a quality-neutrality claim.

Clean beta reproduces the identical cold FA2 Q16 scratch rejection:
`results/mq4-tail-capture-control/baseline-harness.log`. Candidate decode-only
stock harness passes: stable659-launch/16-kernel capture, hashfe4c3ec486001342,
16 AQL contracts, four-position retained-PM4/HIP/blob bit parity including
GDN frame. Report `candidate-decode.json`, pass=true. This is decode
non-regression coverage; it does not validate cold prefill capture.
Both baseline/candidate warmed full capture now running under the explicitly
logged `redline_warmed_control.py` adapter. No source or old logs modified.

Warmed full capture complete: baseline and candidate both pass=true.
Each has stable prefill512 capture1332/20/b78d91b25ecfa468 and decode
659/16/fe4c3ec486001342; 16 AQL contracts and four-position PM4/HIP/blob
bit parity plus GDN-frame parity. Source is
`results/mq4-tail-warmed-capture/{baseline,candidate}.json`; extra warmup
requests/responses are separately preserved in `*-warmup.jsonl`.
Captured prefill deliberately falls back to the legacy/capture-safe route,
so this proves safe exclusion/non-regression, not capture of packed wide
prefill. Ordinary packed/wide execution is covered by daemon ABBA, state
oracles, and serving above. No outstanding GPU checks in this campaign.
