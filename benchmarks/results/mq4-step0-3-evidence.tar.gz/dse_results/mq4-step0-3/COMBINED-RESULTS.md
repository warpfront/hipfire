# Packed512 versus packed4096

Evidence: `results/mq4-combined4096-abba`, audited with
`summarize_mq4_abba.py`. Binary and source identities in manifest and
COMBINATION-AUDIT.md. PP8192, 3 full warmups, fresh-process ABBA, same
Qwen3.6-27B MQ4/Q8 VMM/AR configuration. Packed SET and ADD markers verified.

| Arm | PP tok/s | Decode tok/s | Tokens |
|---|---:|---:|---:|
| packed512 A1 | 964.5 | 36.9 | 229 |
| packed4096 B1 | 1057.8 | 36.9 | 229 |
| packed4096 B2 | 1056.9 | 36.8 | 229 |
| packed512 A2 | 961.2 | 36.9 | 229 |

PP means 962.85 -> 1057.35 (+9.81%). Decode 36.9 -> 36.85 (-0.14%).
All four measured texts identical, SHA256
`4cc97075a068e0551e841425dc6725801868877d0d702db06c381f300533b7ed`.
This equality is within packed; packed and native are not bit-identical.

Compared with historical same-campaign native ~790 tok/s, combined is
roughly 34% faster, but a direct native/combined ABBA with longer output
is still needed for the final claim. Started separately in
`results/mq4-combined-tg1024-abba`: exact calibrated PP8192, tutorial task,
1024-token cap. No speed/quality claim from that run until it completes.
State, serving and kernel regression checks remain pending. Default off.

## Initial long-decode text inspection (not final ABBA)

First native and candidate measurements both emit 1024 tokens, truncated by
the cap. They remain structured prose, but both have technical errors:
native conflates radix prefix reuse with PagedAttention and visibly revises
its derivation; candidate gives an incorrect `2 * B * L * d_h^2` KV memory
formula (missing context length and KV-head count). Candidate and native
texts differ. Do not describe this as knowledge correctness or quality
neutrality. Further serving tasks are needed; one sampled answer does not
isolate a systematic quality regression, nor rule one out.

## Direct native512 versus combined4096: PP8192 / TG1024 ABBA

Completed `results/mq4-combined-tg1024-abba`, all raw checksums and route
markers verified. Exact calibrated prompt SHA256
`a2312bc708f9c63a73ab6dbb893cf34fce475413c77f8b0b377de5a84a0e381d`.
Calibration requests excluded. Three full warmups per fresh process.

| Arm | PP tok/s | Decode tok/s | Tokens |
|---|---:|---:|---:|
| native A1 | 781.2 | 36.6 | 1024 |
| combined B1 | 1049.8 | 36.6 | 1024 |
| combined B2 | 1051.5 | 36.7 | 1024 |
| native A2 | 784.5 | 36.7 | 1024 |

PP means 782.85 -> 1050.65 (+34.21%); decode both 36.65 tok/s.
Text hashes stable within arms, different across arms; not bit-exact.
This confirms speed improvement on this input and no observed long-decode
speed regression. It does not establish quality neutrality. Five long-input
serving tasks now run separately in `results/mq4-serving-ab`.

## Serving quality A/B

`results/mq4-serving-ab` completed with the pinned combined binary, before
the subsequent MQ4V2 lean-buffer guards. Native and combined each completed
5/5 tasks (Snake, Tetris, story, KV cache, Radix Attention). Corresponding
request/prompt MD5s match. Inputs 6014/6024/6037/6029/6027 tokens, all
cached=0; all ten generations reached the 1024-token cap. No attractors,
empty responses or stream errors. Combined log confirms 4096 commit512 and
packed SET/ADD. Both full transcripts were read.

Observed coherent task-directed code/prose, not executable full programs:
code is truncated. Story remains narrative; KV/Radix explanations have
knowledge limitations. In this realistic KV prompt, combined states the
correct general KV memory formula and consistent examples; native states
the formula but miscalculates its example. This does not overturn the
earlier candidate error or establish aggregate quality neutrality. It is
limited fluency/state-lifecycle evidence. Serving timings are not used for
speed claims because they include HTTP and first-request JIT effects.
