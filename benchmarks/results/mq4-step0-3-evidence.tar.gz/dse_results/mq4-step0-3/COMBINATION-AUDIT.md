# Packed + wide MQ4: pre-implementation audit

The completed native-wide experiments kept packed OFF. Combined-route
measurements are now recorded in COMBINED-RESULTS.md; additive speedup
must not be assumed.

Source inspected at `perf/mq4-step0-3` (parent 38d68e211 + wide diff):

- `rdna-compute/src/packed_mq4.rs::gemm_packed_impl` always quantizes
  fresh input, calls `reserve_packed_mq4`, then SET/ADD. No pointer-based
  activation cache crosses projections.
- `scratch.rs::reserve_packed_mq4` shares the same `q8_1_mmq_x_scratch`
  slot budgeted by `native_mq4_projection_deficit`: ceil(K/128)*144*N.
  It does not add a second persistent activation buffer. Max K=17408.
- Prefill gate/up writes separate F32 planes, down explicitly computes
  SwiGLU/FWHT into F32 before packed ADD. Full PBS is required; V2 lean
  PBS/IU4 prepared producer contracts cannot be assumed for MQ4.
- Packed admission requires N divisible by 256 and exact shapes.
  Irregular tails fall back to incumbent native dispatch; the existing
  small-tail FP16/deterministic-partial reservation must stay.
- Graph capture / replay recording are explicitly excluded by packed
  admission; widened ordinary admission also excludes these routes.

The pinned native-wide binary deliberately rejects `packed_mq4_prefill`.
The working source now removes only that incompatibility and updates the
unit guard expectation. Unit tests 2/2 pass and daemon build passes. GPU
validation is in progress. Pinned binary `/tmp/mq4-combined-step3/daemon`,
SHA256 `ab220442964ccb93d054b3d2dbd36fe580b91cb1a4a31d1cd698b51335bce7e2`.
The packed512/packed4096 ABBA uses `step3-mq4-packed4096.json` and writes
`results/mq4-combined4096-abba`, with required packed SET/ADD markers. Keep a
separate pinned binary and require both wide receipt and packed SET/ADD
markers. Compare combined against packed512 and the clean native baseline,
with matched long decode. Do not mutate the pinned native-wide binary.

Numerical warning: packed differs from native (activation rounding/grouping),
so exact state equality is not expected against native. Compare packed512
against packed-wide for chunk effects, and use serving/coherence checks for
the overall packed change. MQ4V2 compatibility remains separately guarded
and does not inherit native-MQ4 evidence.
