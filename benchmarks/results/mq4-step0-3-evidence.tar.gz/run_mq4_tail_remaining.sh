#!/usr/bin/env bash
set -euo pipefail
campaign=/home/husrcf/Code/ProtBind/hipfireTMP
repo="$campaign/hipfire-mq4-step0-3"
source "$repo/scripts/gpu-lock.sh"
GPU_LOCK_TIMEOUT=1800 gpu_acquire mq4-tail-remaining
export LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib
python3 -u "$campaign/run_mq4_state_boundary.py" \
  --binary /tmp/mq4-tail-step3/mq4_prefill_state_oracle \
  --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
  --prompt "$campaign/results/mq4-combined-tg1024-abba/prompt.txt" \
  --out "$campaign/results/mq4-tail-native8192-state" --gpu 1 --wide 8192 --rows 8193
python3 -u "$campaign/pp8192_native_matrix.py" "$repo" \
  /tmp/mq4-tail-step3/daemon "$campaign/results/mq4-tail-v2-smoke" 1 \
  "$campaign/final-mq4v2-smoke.json"
python3 -u "$campaign/run_mq4_serving_ab.py" --root "$repo" \
  --binary /tmp/mq4-tail-step3/daemon --cli /tmp/mq4-wide-step3/hipfire \
  --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
  --prompts "$campaign/mq4-long-input-battery-v2.json" \
  --out "$campaign/results/mq4-tail-serving" --gpu 1 --arms combined
