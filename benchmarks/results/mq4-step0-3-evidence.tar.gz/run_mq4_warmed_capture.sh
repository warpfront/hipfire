#!/usr/bin/env bash
set -u
base=/home/husrcf/Code/ProtBind/hipfireTMP
repo="$base/hipfire-mq4-step0-3"
out="$base/results/mq4-tail-warmed-capture"
source "$repo/scripts/gpu-lock.sh"
GPU_LOCK_TIMEOUT=3600 gpu_acquire mq4-tail-warmed-capture || exit
mkdir "$out" || exit
for arm in baseline candidate; do
  binary=/tmp/mq3-beta-8d302c342/daemon
  enabled=0
  if [[ "$arm" == candidate ]]; then
    binary=/tmp/mq4-tail-step3/daemon
    enabled=1
  fi
  env -i PATH="$PATH" HOME=/home/husrcf LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib \
    HIP_VISIBLE_DEVICES=1 HIPFIRE_HOME="$out/$arm-home" HIPFIRE_VERIFY_GRAPH=0 \
    HIPFIRE_GFX1100_PACKED_MQ4_PREFILL="$enabled" \
    HIPFIRE_GFX1100_MQ4_WIDE_PREFILL="$enabled" HIPFIRE_PREFILL_CHUNK_ROWS=4096 \
    HIPFIRE_DN_STATE_EF=1 \
    python3 "$base/redline_warmed_control.py" "$out/$arm-warmup.jsonl" \
    --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 --daemon "$binary" \
    --prefill 512 --decode-context 512 --max-seq 2048 --kv-mode q8 \
    --capture-repeats 2 --measure-repeats 3 --decode-iterations 100 \
    --shadow-iterations 4 --pm4 --timeout 600 \
    --out "$out/$arm.json" --log "$out/$arm-daemon.log" \
    > "$out/$arm-harness.log" 2>&1
  printf '%s exit=%s\n' "$arm" "$?"
done
