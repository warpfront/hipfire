#!/usr/bin/env python3
"""Final capture and related-turn checks; no performance claims from these runs."""
import json
import os
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
repo = base / 'hipfire-mq4-step0-3'
out = base / 'results/mq4-tail-gates'
if not os.environ.get('HIPFIRE_GPU_LOCK_OWNER'):
    raise SystemExit('run under gpu-lock.sh')
out.mkdir(exist_ok=False)
env = {k: v for k, v in os.environ.items()
       if not k.startswith('HIPFIRE_') and k != 'ROCR_VISIBLE_DEVICES'}
env.update(HIP_VISIBLE_DEVICES='1', HIPFIRE_HOME=str(out / 'redline-home'),
           HIPFIRE_GFX1100_PACKED_MQ4_PREFILL='1',
           HIPFIRE_GFX1100_MQ4_WIDE_PREFILL='1', HIPFIRE_PREFILL_CHUNK_ROWS='4096',
           HIPFIRE_VERIFY_GRAPH='0', HIPFIRE_DN_STATE_EF='1')
cmd = ['python3', str(repo / 'scripts/redline_daemon_harness.py'),
       '--model', '/home/husrcf/.hipfire/models/qwen3.6-27b.mq4',
       '--daemon', '/tmp/mq4-tail-step3/daemon', '--prefill', '512',
       '--decode-context', '512', '--max-seq', '2048', '--kv-mode', 'q8',
       '--capture-repeats', '2', '--measure-repeats', '3',
       '--decode-iterations', '100', '--shadow-iterations', '4', '--pm4',
       '--timeout', '600', '--out', str(out / 'redline.json'),
       '--log', str(out / 'redline-daemon.log')]
(out / 'redline-request.json').write_text(json.dumps({'command': cmd, 'environment': {
    k: v for k, v in env.items() if k.startswith(('HIP', 'LD_LIBRARY_PATH'))}}, indent=2))
with (out / 'redline-harness.log').open('x') as log:
    result = subprocess.run(cmd, cwd=repo, env=env, stdout=log,
                            stderr=subprocess.STDOUT, timeout=1800)
print('Redline exit:', result.returncode, flush=True)
# Preserve a failure report and still run the independent lifecycle check.
battery = json.loads((base / 'mq4-long-input-battery-v2.json').read_text())
prompts = [next(r for r in battery if r['genre'] == 'kv-cache'),
           {'genre': 'followup', 'prompt': 'Continue the previous explanation: how does grouped-query attention change the KV cache size? Give the correct formula.'},
           {'genre': 'followup', 'prompt': 'Now connect that explanation to radix-tree prefix sharing. Explain which cached state can be shared safely and which state must remain request-local.'}]
fixture = out / 'chain-prompts.json'
fixture.write_text(json.dumps(prompts, ensure_ascii=False, indent=2))
cmd = ['python3', str(base / 'run_mq4_serving_ab.py'), '--root', str(repo),
       '--binary', '/tmp/mq4-tail-step3/daemon', '--cli', '/tmp/mq4-wide-step3/hipfire',
       '--model', '/home/husrcf/.hipfire/models/qwen3.6-27b.mq4',
       '--prompts', str(fixture), '--out', str(out / 'chain'),
       '--gpu', '1', '--arms', 'combined', '--mode', 'chain']
subprocess.run(cmd, check=True)
raise SystemExit(result.returncode)
