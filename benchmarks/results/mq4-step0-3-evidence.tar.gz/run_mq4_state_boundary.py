#!/usr/bin/env python3
"""Developer-only state comparison; run under gpu-lock, not beside timings."""
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--out', type=Path, required=True)
p.add_argument('--binary', type=Path, required=True)
p.add_argument('--model', type=Path, required=True)
p.add_argument('--prompt', type=Path, required=True)
p.add_argument('--gpu', default='1')
p.add_argument('--wide', type=int, default=2048, choices=[1024, 2048, 4096, 8192])
p.add_argument('--rows', type=int, nargs='+', default=[513, 1025, 8193])
p.add_argument('--packed', action='store_true', help='enable packed in BOTH arms')
a = p.parse_args()
if not os.environ.get('HIPFIRE_GPU_LOCK_OWNER'):
    p.error('run under scripts/gpu-lock.sh')
a.out.mkdir(parents=True, exist_ok=False)

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(8 << 20), b''):
            h.update(chunk)
    return h.hexdigest()

env = {k: v for k, v in os.environ.items()
       if not k.startswith('HIPFIRE_') and k != 'ROCR_VISIBLE_DEVICES'}
env.update(HIP_VISIBLE_DEVICES=a.gpu, HIPFIRE_VERIFY_GRAPH='0',
           HIPFIRE_GFX1100_PACKED_MQ4_PREFILL='1' if a.packed else '0',
           HIPFIRE_KERNEL_CACHE=str(a.out.resolve() / 'kernel-cache'))
(a.out / 'manifest.json').write_text(json.dumps({
    'binary': str(a.binary), 'binary_sha256': digest(a.binary),
    'model': str(a.model), 'model_sha256': digest(a.model),
    'prompt': str(a.prompt), 'prompt_sha256': digest(a.prompt),
    'rows': a.rows, 'continuation': 4, 'wide': a.wide, 'gpu': a.gpu, 'packed': a.packed,
    'note': 'Numerical diagnostic, not a performance or broad quality gate.'
}, indent=2))
for rows in a.rows:
    for label, chunk, enabled in [('base', 512, '0'), ('wide', a.wide, '1')]:
        run_env = dict(env, HIPFIRE_PREFILL_CHUNK_ROWS=str(chunk),
                       HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=enabled)
        prefix = a.out / f'{rows}-{label}'
        command = [str(a.binary), 'dump', str(a.model), str(a.prompt),
                   str(rows), '4', str(prefix)]
        prefix.with_suffix('.request.json').write_text(json.dumps({
            'command': command,
            'environment': {k: v for k, v in run_env.items()
                            if k.startswith(('HIP', 'LD_LIBRARY_PATH'))}
        }, indent=2))
        with prefix.with_suffix('.stdout.log').open('x') as out, \
             prefix.with_suffix('.stderr.log').open('x') as err:
            subprocess.run(command, env=run_env, stdout=out, stderr=err,
                           timeout=1800, check=True)
        log = prefix.with_suffix('.stderr.log').read_text()
        receipts = re.findall(r'prefill_chunk: requested=(\d+) admitted=(\d+) commit_stride=(\w+)', log)
        if not receipts or int(receipts[-1][1]) != chunk:
            raise RuntimeError(f'{rows}/{label}: expected chunk {chunk}, got {receipts}')
        if chunk > 512 and receipts[-1][2] != '512':
            raise RuntimeError(f'{rows}/{label}: wrong recurrent commit stride')
        # A short non-tiled input legitimately stays on native fallback.
        # Packed-aware grouping preserves legacy 512-row packed segments.
        full_packed = rows // 512 - int(rows % 512 == 1)
        if a.packed and (full_packed > 0 or rows % 512 == 256):
            for epilogue in ('false', 'true'):
                if not re.search(r'\[packed-mq4\] admitted format=mq4 .*add=' + epilogue, log):
                    raise RuntimeError(f'{rows}/{label}: missing packed add={epilogue}')
        print(rows, label, 'dump complete', flush=True)
    report = a.out / f'{rows}-compare.jsonl'
    with report.open('x') as out:
        subprocess.run([str(a.binary), 'compare', str(a.out / f'{rows}-base'),
                        str(a.out / f'{rows}-wide')], env=env, stdout=out,
                       timeout=300, check=True)
    print(rows, 'comparison complete; inspect metrics before judging', flush=True)
