#!/usr/bin/env bash
set -u
repo=/home/husrcf/Code/ProtBind/hipfireTMP/hipfire-mq4-step0-3
out=/home/husrcf/Code/ProtBind/hipfireTMP/results/mq4-tail-capture-control
source "$repo/scripts/gpu-lock.sh"
GPU_LOCK_TIMEOUT=3600 gpu_acquire mq4-tail-capture-control || exit
mkdir "$out" || exit
env -i PATH="$PATH" HOME=/home/husrcf LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib \
 HIP_VISIBLE_DEVICES=1 HIPFIRE_HOME="$out/baseline-home" HIPFIRE_VERIFY_GRAPH=0 \
 python3 "$repo/scripts/redline_daemon_harness.py" \
 --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
 --daemon /tmp/mq3-beta-8d302c342/daemon --prefill 512 --decode-context 512 \
 --max-seq 2048 --kv-mode q8 --capture-repeats 2 --measure-repeats 3 \
 --decode-iterations 100 --shadow-iterations 4 --pm4 --timeout 600 \
 --out "$out/baseline.json" --log "$out/baseline-daemon.log" > "$out/baseline-harness.log" 2>&1
baseline_rc=$?
env -i PATH="$PATH" HOME=/home/husrcf LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib \
 HIP_VISIBLE_DEVICES=1 HIPFIRE_HOME="$out/candidate-home" HIPFIRE_VERIFY_GRAPH=0 \
 HIPFIRE_GFX1100_PACKED_MQ4_PREFILL=1 HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=1 \
 HIPFIRE_PREFILL_CHUNK_ROWS=4096 HIPFIRE_DN_STATE_EF=1 \
 python3 "$repo/scripts/redline_daemon_harness.py" \
 --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
 --daemon /tmp/mq4-tail-step3/daemon --skip-prefill --decode-context 512 \
 --max-seq 2048 --kv-mode q8 --capture-repeats 2 --measure-repeats 3 \
 --decode-iterations 100 --shadow-iterations 4 --pm4 --timeout 600 \
 --out "$out/candidate-decode.json" --log "$out/candidate-daemon.log" > "$out/candidate-harness.log" 2>&1
candidate_rc=$?
printf 'baseline_full_exit=%s candidate_decode_exit=%s\n' "$baseline_rc" "$candidate_rc"
