#!/usr/bin/env python3
"""Read-only CPU reconstruction from GPU-produced MQ4/Q8 bytes; JSON to stdout."""
import json
from pathlib import Path
import re
import sys
import numpy as np

def metrics(a, b):
    a, b = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    return dict(max_abs=float(np.max(np.abs(a-b))),
                relative_l2=float(np.linalg.norm(a-b) / max(np.linalg.norm(b), 1e-30)))

for path in sorted(Path(sys.argv[1]).iterdir()):
    if not path.is_dir():
        continue
    m, k, n = map(int, re.fullmatch(r'm(\d+)-k(\d+)-n(\d+)', path.name).groups())
    w = np.memmap(path/'weights.bin', dtype=np.uint8, mode='r', shape=(m,k//256,136))
    x = np.memmap(path/'input.bin', dtype='<f4', mode='r', shape=(n,k))
    rows = [0,1,31,32,63,64,m//2,m-1]
    tokens = [0,1,127,128,255,256,n-1]
    ideal, outputs, contracts = [], {}, {}
    weight_rows = {}
    for r in rows:
        scale = np.ascontiguousarray(w[r,:,:4]).view('<f4').reshape(-1).astype(np.float16).astype(np.float64)
        zero = np.ascontiguousarray(w[r,:,4:8]).view('<f4').reshape(-1).astype(np.float16).astype(np.float64)
        nib = np.stack((w[r,:,8:]&15,w[r,:,8:]>>4),axis=-1).reshape(-1).astype(np.int32)
        weight_rows[r] = (scale,zero,nib)
    for t in tokens:
        for r in rows:
            sc,zp,q = weight_rows[r]
            ideal.append(float(np.sum((np.repeat(sc,256)*q+np.repeat(zp,256))*x[t].astype(np.float64))))
    details = {}
    for arm in ['native','packed']:
        raw = np.memmap(path/f'{arm}-activation.bin',dtype=np.uint8,mode='r',shape=(k//128,n,144))
        out = np.memmap(path/f'{arm}-output.bin',dtype='<f4',mode='r',shape=(n,m))
        outputs[arm], contracts[arm] = [], []
        scales, quant = [], []
        for t in tokens:
            ds = np.ascontiguousarray(raw[:,t,:16]).view('<f2').reshape(k//32,2).astype(np.float64)
            qx = np.ascontiguousarray(raw[:,t,16:]).view(np.int8).reshape(k//32,32).astype(np.int32)
            scales.append(ds[:,0]); quant.append(qx)
            for r in rows:
                sc,zp,qw = weight_rows[r]
                dots = np.sum(qw.reshape(-1,32)*qx,axis=1,dtype=np.int64)
                contracts[arm].append(float(np.sum(np.repeat(sc,8)*ds[:,0]*dots+np.repeat(zp,8)*ds[:,1])))
                outputs[arm].append(float(out[t,r]))
        details[arm] = dict(gpu_vs_own_quantized_contract=metrics(outputs[arm],contracts[arm]),
                            gpu_vs_unquantized_activation=metrics(outputs[arm],ideal),
                            contract_vs_unquantized_activation=metrics(contracts[arm],ideal))
        if arm == 'native':
            native_scales, native_quant = np.array(scales), np.array(quant)
        else:
            details['activation_scale_differences'] = int(np.count_nonzero(native_scales!=np.array(scales)))
            details['activation_code_differences'] = int(np.count_nonzero(native_quant!=np.array(quant)))
    details['gpu_cross_route'] = metrics(outputs['packed'],outputs['native'])
    details['cpu_contract_cross_route'] = metrics(contracts['packed'],contracts['native'])
    native_bytes = np.memmap(path/'native-activation.bin',dtype=np.uint8,mode='r')
    packed_bytes = np.memmap(path/'packed-activation.bin',dtype=np.uint8,mode='r')
    native_y = np.memmap(path/'native-output.bin',dtype='<f4',mode='r')
    packed_y = np.memmap(path/'packed-output.bin',dtype='<f4',mode='r')
    details['all_activation_bytes_exact'] = bool(np.array_equal(native_bytes,packed_bytes))
    details['all_output_values_exact'] = bool(np.array_equal(native_y,packed_y))
    print(json.dumps(dict(shape=[m,k,n],sampled_elements=len(ideal),**details)),flush=True)
    if '--require-native-exact' in sys.argv:
        assert details['all_activation_bytes_exact'], 'activation contract mismatch'
        assert details['all_output_values_exact'], 'native versus packed output mismatch'
