# Native versus packed drift investigation (2026-09-29)

This is a new diagnostic, not an amendment of old raw measurements or an
assertion that the previous default-off candidate is quality-neutral.

Source difference: native `quantize_q8_1_mmq_ds4` reduces amax with shuffle
offsets4/2/1 over eight lanes (32 elements); packed quantizer uses16/8/4/2/1
over32 lanes (128 elements). Both preserve sums per32 elements. Packed's
group128 consumer combines integer products before applying one shared scale.
Merely changing the quantizer back to group32 without changing the consumer
would be incorrect: the group128 consumer reads only one of four scales.

Independent CPU reconstruction uses GPU-produced DS4 bytes, actual nibble
weights and f16-rounded metadata. On each actual FFN shape, 56 sampled
outputs across token and row tile boundaries:

| Shape | Native GPU vs own contract relL2 | Packed GPU vs own contract relL2 | GPU cross-route relL2 | CPU contract cross-route relL2 |
|---|---:|---:|---:|---:|
| M17408 K5120 N512 | 1.84e-7 | 8.66e-8 | 0.00791323 | 0.00791323 |
| M5120 K17408 N512 | 4.50e-7 | 1.16e-7 | 0.01147497 | 0.01147495 |

Evidence: `results/mq4-drift-oracle/cpu-report.jsonl`, dump files and
`mq4_drift_cpu_oracle.py`. Added optional numerical-only dump mode to
`bench_packed_mq4_shapes`; existing outputs are not overwritten.

Interpretation: this sampled synthetic test reproduces inter-route error
through the changed activation quantization and does not indicate a packed
layout/GEMM arithmetic defect. It is not an exhaustive oracle or proof about
real activation distributions. On this synthetic input packed happens to be
closer to the unquantized activation reference; do not infer general quality
improvement OR degradation from group size alone.

Running real-model cross-route state check: same final pinned oracle,
Qwen3.6-27B MQ4, 512 prefill rows, chunk512 on both, four identical forced
continuation tokens, only packed flag changes. Output directory:
`results/mq4-drift-real512`. This rules out width and divergent generated
tokens as explanations when locating the earliest differing state layer.

Real-model run completed,646 records. At prefill, layer00 codes/scales/EF/
conv and reconstructed states are exactly equal. Layer01 already differs:
conv relL2=0.00983298; dequantized recurrent state=0.0123030;
state+EF=0.00578280. This brackets the first changed computation after
layer00's recurrent update and before layer01's update, consistent with
the changed layer00 FFN. It is not evidence of initially leaking recurrent
state. No generated-token divergence is involved because inputs are forced.

Full prefill logits: maxAbs5.56087, RMSE0.60956, relL2=0.197712. First four
forced continuation positions have relL2=0.11934/0.09109/0.06038/0.19791.
Argmax agrees at all five sampled positions, but that does NOT justify
calling these tiny rounding differences or guarantee long greedy agreement.

Next causal check: preserve the packed row/tile arrangement but restore
native per32 activation scales AND the matching per32 dot/scale consumer.
Quantizer-only modification is invalid. Compare numerical drift first, then
repeat decode/prefill throughput. No production kernel was changed during
this diagnostic; previous candidate remains default-off, not promoted.
