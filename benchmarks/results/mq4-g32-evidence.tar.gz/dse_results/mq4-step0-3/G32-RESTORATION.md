# G32 restoration, 2026-09-29 (validation in progress)

User requested retaining packed layout while restoring native activation
precision. Candidate changes only amax reduction to32 elements and selects
the matching per32 dot/scale/zero-correction consumer. X256/Y64, quad-row
weight loads and nibble permutation remain intact. MQ4V2 uses the same G32
activation producer and its own unchanged weight metadata interpretation.
The old quantizer symbol name remains for source/ABI continuity; it no
longer describes activation grouping.

Pinned daemon: `/tmp/mq4-g32-step3/daemon`, SHA256
`144ede4dae37ce0fe6522f60aa9d343c37fdec0545fefdee3735e1633cac08fd`.
Source delta and oracle binaries are beside it. Old G128 binaries/results
are unchanged. No defaults enabled or previous claims silently updated.

## Numeric evidence completed

- Synthetic actual FFN shapes (M17408/K5120 and M5120/K17408, N512):
  ALL activation bytes and ALL output values exactly match native MMQ.
  Sampled56-element CPU oracle agrees with both routes to floating-point
  accumulation precision. Cross-route relL2 and maxAbs are both zero.
- Real Qwen3.6-27B MQ4 at512 rows, both chunk512:646 records exactly equal,
  covering KV/recurrent state, prefill logits, four forced decode steps.
- Same model at8193 rows, native512 versus packed4096:646 records exactly
  equal, including raw comparable records and continuation. No nonfinite.

Sources: `results/mq4-g32-oracle`, `results/mq4-g32-real`.
Runner stops if any strict equality check fails; it has now advanced to
PP8192/TG1024 fresh-process ABBA, same prompt/config as the prior G128 test.
No speed claim for this G32 candidate yet. Old +33.96% is not transferable.

First formal A/B observation (not the completed ABBA): native786.6/36.7,
packed912.3/36.7 tok/s (PP/TG). Candidate warm1024-token text matches the
measured baseline text. Wait for all four measurements and raw hash audit
before treating this as the final performance/equality result.

## Final direct ABBA

Raw manifests/hashes, cache0, executed routes and output lengths verified by
`summarize_mq4_abba.py results/mq4-g32-abba`.

| Arm | PP8192 tok/s | TG1024 tok/s |
|---|---:|---:|
| native512 A | 786.6 | 36.7 |
| packed4096 B | 912.3 | 36.7 |
| packed4096 B | 913.9 | 36.7 |
| native512 A | 784.6 | 36.7 |

Means785.6 ->913.1 PP (+16.2296%); decode unchanged36.7. All four1024-token
texts SHA256 `40802e747e178a63122b58cef56874c68ff7fae0c4e26ec6828cae917d5f4139`.
This is fixture-bound equality, not a proof for every input/model/architecture.
Sampled device peak remains about2.18GiB above native512 due to wide scratch.
Do not report historical G1281051.3 tok/s as a precision-preserving result.

## Final auxiliary checks

Warmed capture (`results/mq4-g32-capture/report.json`) pass=true:
prefill1332/20/b78d91b25ecfa468, decode659/16/fe4c3ec486001342,
16 contracts and four-position HIP/PM4/blob/GDN-frame parity. Captured
execution intentionally uses the existing fallback, not the packed kernel.
Extra warmups logged separately; baseline cold-capture limitation unchanged.

MQ4V2 smoke (`results/mq4-g32-v2-smoke`): PP8192/TG256 complete, actual
packed SET/ADD N4096 receipts, raw hashes verified. Single observed
PP1141.0/TG36.8 tok/s is compatibility evidence only. Text read: coherent
linked-list explanation/code fragment, but the model incorrectly calls hash
map lookups worst-case O(1); this is not a factual accuracy gate.

Release build succeeds; packed admission unit test1/1 passes; whitespace
check passes. No default enabled, registry altered, or branch pushed.
