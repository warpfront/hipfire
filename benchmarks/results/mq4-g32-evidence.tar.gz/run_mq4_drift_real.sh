#!/usr/bin/env bash
set -euo pipefail
base=/home/husrcf/Code/ProtBind/hipfireTMP
repo="$base/hipfire-mq4-step0-3"
out="$base/results/mq4-drift-real512"
source "$repo/scripts/gpu-lock.sh"
GPU_LOCK_TIMEOUT=10 gpu_acquire mq4-drift-real
mkdir "$out"
export HIP_VISIBLE_DEVICES=1 LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib
export HIPFIRE_PREFILL_CHUNK_ROWS=512 HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=0
export HIPFIRE_VERIFY_GRAPH=0 HIPFIRE_DN_STATE_EF=1
for arm in native packed; do
  export HIPFIRE_GFX1100_PACKED_MQ4_PREFILL=0
  if [[ "$arm" == packed ]]; then export HIPFIRE_GFX1100_PACKED_MQ4_PREFILL=1; fi
  /tmp/mq4-tail-step3/mq4_prefill_state_oracle dump \
    /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
    "$base/results/mq4-tail-final-abba/prompt.txt" 512 4 "$out/$arm" \
    > "$out/$arm.stdout.log" 2> "$out/$arm.stderr.log"
done
/tmp/mq4-tail-step3/mq4_prefill_state_oracle compare "$out/native" "$out/packed" \
  > "$out/compare.jsonl"
