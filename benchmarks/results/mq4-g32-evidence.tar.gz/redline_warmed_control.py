#!/usr/bin/env python3
"""Explicit diagnostic adapter: warm each shape before the stock capture harness.

No engine or stock harness edits. Records every extra request and response in
a NEW JSONL file. This tests warmed capture, not cold-capture safety.
Usage: python redline_warmed_control.py NEW_WARMUP_LOG [stock harness args...]
"""
import importlib.util
import json
from pathlib import Path
import sys

log_path = Path(sys.argv.pop(1))
source = Path(__file__).resolve().parent / 'hipfire-mq4-step0-3/scripts/redline_daemon_harness.py'
spec = importlib.util.spec_from_file_location('redline_stock', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original = module.Daemon

with log_path.open('x') as log:
    class WarmedDaemon(original):
        def __init__(self, *args, **kwargs):
            self.warmed = set()
            super().__init__(*args, **kwargs)

        def request(self, message):
            if message.get('redline_capture'):
                warm = {k: v for k, v in message.items() if not k.startswith('redline_')}
                key = json.dumps(warm, sort_keys=True)
                if key not in self.warmed:
                    response = super().request(warm)
                    log.write(json.dumps({'request': warm, 'response': response}) + '\n')
                    log.flush()
                    self.warmed.add(key)
            return super().request(message)

    module.Daemon = WarmedDaemon
    module.main()
