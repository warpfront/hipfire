#!/usr/bin/env python3
"""Local, raw-evidence-preserving PP8192 native daemon comparison."""
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import threading
import time
import sys
import re

root, binary, output, gpu = map(str, sys.argv[1:5])
campaign = json.loads(Path(sys.argv[5]).read_text()) if len(sys.argv)>5 else {}
root, binary, output = Path(root), Path(binary), Path(output)
output.mkdir(parents=True, exist_ok=False)
base = (root / 'benchmarks/prompts/ttft_5900.txt').read_text()
model_dir = Path.home() / '.hipfire/models'
models = {'xt': 'qwen3.8-27b.mq4-xt', 'mq4': 'qwen3.6-27b.mq4', 'mq3': 'qwen3.6-27b.mq3'}
cases = campaign.get('cases', [{'model':x, 'name':x, 'env':{}} for x in
                               ['xt', 'mq4', 'mq4', 'xt', 'xt', 'mq3', 'mq3', 'xt']])
order = [c['name'] for c in cases]
prompt = Path(campaign['prompt']).read_text() if campaign.get('prompt') else None
decode_cap = campaign.get('decode_cap', 128)
expected_pp = campaign.get('expected_pp', 8192)

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''): h.update(block)
    return h.hexdigest()

def identity(path):
    sha256, md5 = hashlib.sha256(), hashlib.md5()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            sha256.update(block); md5.update(block)
    return {'path':str(path), 'sha256':sha256.hexdigest(), 'md5':md5.hexdigest()}

manifest = {'binary': str(binary), 'binary_sha256': sha(binary), 'order': order,
            'binary_identity':identity(binary),
            'models': {k: identity(model_dir/v) for k,v in models.items()
                       if k in {c['model'] for c in cases}},
            'pp': expected_pp, 'max_seq': 16384, 'warmups': 3, 'runs_per_process': 1,
            'decode_cap': decode_cap, 'gpu': gpu, 'campaign':campaign,
            'note': 'XT is Qwen3.8; MQ4/MQ3 are Qwen3.6. Not a format-only causal comparison.'}
(output/'manifest.json').write_text(json.dumps(manifest, indent=2))
if prompt is not None:
    (output/'prompt.txt').write_text(prompt)

for arm, case in enumerate(cases):
    label = case['model']
    folder = output / f"{arm:02}-{case['name']}"
    folder.mkdir()
    env = {k:v for k,v in os.environ.items() if not k.startswith('HIPFIRE_')}
    env.pop('ROCR_VISIBLE_DEVICES', None)
    env.update(HIP_VISIBLE_DEVICES=gpu, HIPFIRE_VERIFY_GRAPH='0',
               HIPFIRE_GFX1100_PACKED_MQ4_PREFILL='0',
               HIPFIRE_HOME=str(folder/'config'),
               HIPFIRE_KERNEL_CACHE=str(output/'kernel-cache'))
    env.update(case.get('env', {}))
    (folder/'environment.json').write_text(json.dumps(
        {k:v for k,v in env.items() if k.startswith(('HIPFIRE_', 'HIP_', 'ROCR_', 'LD_LIBRARY_PATH'))},indent=2))
    telemetry_stop = threading.Event()
    def telemetry():
        device = campaign.get('telemetry_device')
        if not device:
            return
        with (folder/'telemetry.jsonl').open('w') as f:
            while not telemetry_stop.is_set():
                sample = {'time_ns':time.time_ns()}
                for name in ('mem_info_vram_used', 'gpu_busy_percent'):
                    try: sample[name] = int((Path(device)/name).read_text())
                    except (OSError, ValueError): sample[name] = None
                f.write(json.dumps(sample)+'\n'); f.flush()
                telemetry_stop.wait(0.1)
    telemetry_thread = threading.Thread(target=telemetry, daemon=True)
    telemetry_thread.start()
    stderr = open(folder/'stderr.log','w')
    raw = open(folder/'stdout.jsonl','w')
    requests = open(folder/'requests.jsonl','w')
    proc = subprocess.Popen([str(binary)], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=stderr, text=True, bufsize=1, env=env)
    inbox = queue.Queue()
    def reader():
        for line in proc.stdout:
            raw.write(line); raw.flush()
            try: inbox.put(json.loads(line))
            except json.JSONDecodeError: pass
        inbox.put(None)
    thread = threading.Thread(target=reader, daemon=True)
    thread.start()
    def request(req, terminal, timeout=900):
        line=json.dumps(req)
        requests.write(line+'\n'); requests.flush()
        proc.stdin.write(line+'\n'); proc.stdin.flush()
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            try: r=inbox.get(timeout=min(10,deadline-time.monotonic()))
            except queue.Empty: continue
            if r is None: raise RuntimeError('daemon exited')
            if r.get('type') == 'commit_ready':
                control = json.dumps({'type':'commit', 'id':r['id'],
                                      'attempt_id':r['attempt_id']})
                requests.write(control+'\n'); requests.flush()
                proc.stdin.write(control+'\n'); proc.stdin.flush()
            if r.get('type') in ('error','aborted'): raise RuntimeError(r)
            if r.get('type') in terminal: return r
        raise TimeoutError(req['type'])
    def generate(text, tag, cap):
        request({'type':'reset','attempt_id':1}, {'reset'})
        return request({'type':'generate','id':tag,'attempt_id':1,'prompt':text,
                        'temperature':0.0,'top_p':1.0,'repeat_penalty':1.1,
                        'max_tokens':cap,'max_think_tokens':1,
                        'assistant_prefix':'closed_think','reasoning_effort':'none'}, {'done'})
    def check_pp(done):
        count=done.get('prefill_tokens')
        if count != expected_pp or done.get('cached_tokens',0) != 0:
            raise RuntimeError(f'Not full uncached PP{expected_pp}: {done}')
        if 'expected_admitted' in case:
            receipts = re.findall(r'prefill_chunk: requested=\d+ admitted=(\d+) commit_stride=(\w+)',
                                  (folder/'stderr.log').read_text())
            if not receipts or int(receipts[-1][0]) != case['expected_admitted']:
                raise RuntimeError(f'Unexpected chunk admission: {receipts}')
            if case['expected_admitted'] > 512 and receipts[-1][1] != '512':
                raise RuntimeError(f'Unexpected recurrent commit stride: {receipts[-1]}')
        if case.get('expected_packed'):
            log = (folder/'stderr.log').read_text()
            packed_format = re.escape(case.get('packed_format', 'mq4'))
            for epilogue in ('false', 'true'):
                if not re.search(r'\[packed-mq4\] admitted format=' + packed_format + r' .*add=' + epilogue, log):
                    raise RuntimeError(f'Missing packed MQ4 add={epilogue} route')
    try:
        request({'type':'load','model':str(model_dir/models[label]),
                 'params':{'max_seq':16384,'kv_mode':'q8','kv_backend':'vmm',
                           'state_quant':'q8','dflash_mode':'off','mtp_mode':'off',
                           'dspark_mode':'off','speculation':'off','tp':1,'pp':1}}, {'loaded'})
        if prompt is None:
            # Count actual rendered tokens, not raw text tokens. Calibration
            # is discarded; the sealed prompt is then reused byte-for-byte.
            padding=2283
            for attempt in range(4):
                candidate=base+' a'*padding+campaign.get('prompt_suffix', '')
                d=generate(candidate,f'calibrate-{attempt}',1)
                count=d.get('prefill_tokens')
                if not isinstance(count,int): raise RuntimeError(d)
                if count==8192:
                    prompt=candidate
                    break
                padding += 8192-count
                if padding<0: raise RuntimeError('base prompt too long')
            if prompt is None: raise RuntimeError('PP8192 calibration did not converge')
            (output/'prompt.txt').write_text(prompt)
            (output/'prompt-identity.json').write_text(json.dumps({
                'md5':hashlib.md5(prompt.encode()).hexdigest(),
                'sha256':hashlib.sha256(prompt.encode()).hexdigest(),'rendered_tokens':8192},indent=2))
        for warm in range(3):
            d=generate(prompt,f'warm-{warm}',decode_cap)
            check_pp(d)
            print(arm,case['name'],'warm',warm,'PP',d.get('prefill_tok_s'),
                  'TG',d.get('decode_tok_s'),'tokens',d.get('tokens'),flush=True)
        done=generate(prompt,'measure',decode_cap)
        check_pp(done)
        # Derived index kept separate from untouched stdout/stderr evidence.
        (folder/'measurement.json').write_text(json.dumps(done,indent=2))
        print(arm,case['name'],'MEASURE','PP',done.get('prefill_tok_s'),
              'TG',done.get('decode_tok_s'),'tokens',done.get('tokens'),flush=True)
    finally:
        proc.stdin.close()
        try: proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.terminate(); proc.wait(timeout=20)
        thread.join(timeout=10)
        raw.close(); stderr.close(); requests.close()
        telemetry_stop.set()
        telemetry_thread.join(timeout=5)
        (folder/'raw-sha256.json').write_text(json.dumps({
            n:sha(folder/n) for n in ['stdout.jsonl','stderr.log','requests.jsonl']},indent=2))
