#!/usr/bin/env bash
# Diagnostic continuation of no-gpu-ci.sh AFTER its failed rdna-compute --lib
# command. Not a replacement gate; does not turn the original failure green.
set -uo pipefail
out=${1:?absolute NEW evidence directory required}
mkdir "$out" || exit 2
while IFS= read -r var; do unset "$var"; done < <(compgen -e | rg '^HIPFIRE_' || true)
export ROCR_VISIBLE_DEVICES=-1 HIP_VISIBLE_DEVICES=-1 HIPFIRE_TEST_REQUIRE_ROCM=0
export HIPFIRE_LOCK_DIR
HIPFIRE_LOCK_DIR=$(mktemp -d /tmp/tiered-supp-locks.XXXXXX)
export HIPFIRE_HOME
HIPFIRE_HOME=$(mktemp -d /tmp/tiered-supp-home.XXXXXX)
failed=0
run() {
    local name=$1
    shift
    printf 'RUN %s\n' "$name"
    "$@" > "$out/$name.log" 2>&1
    local code=$?
    printf '%s\t%s\n' "$name" "$code" >> "$out/status.tsv"
    printf 'EXIT %s %s\n' "$code" "$name"
    if (( code != 0 )); then failed=$((failed + 1)); fi
}
run launcher-abi cargo test --locked -p rdna-compute --test all_launcher_abi
run cpu-lib cargo test --locked -p hipfire-cpu --lib
run engine-decide cargo test --locked -p hipfire-engine --lib decide
run generate-decide cargo test --locked -p hipfire-generate --lib decide
run qwen-moe-prefill cargo test --locked -p hipfire-arch-qwen35 --lib moe_prefill
run control-plane cargo test --locked -p hipfire-config -p hipfire-registry -p hipfire-client -p hipfire-cli -p hipfire-tui
run pm-audit cargo test --locked -p peacemaker-isa --features toolchain --lib audit::
run pm-cost cargo test --locked -j 8 -p peacemaker-isa --features toolchain --lib cost_lint::
run pm-author cargo test --locked -p peacemaker-author
run python-cpu python3 -m pytest tests scripts/test_astrea.py autoresearch/ar/tests scripts/hw-gate/tests scripts/test_registry_gen_ornith.py scripts/test_registry_gen_vision.py scripts/test_registry_gen_coverage.py scripts/test_registry_gen_decider.py scripts/test_lmx_corpus.py scripts/test_ck_runtime_bundle.py scripts/test_check_changelog.py scripts/test_kernel_idproof.py scripts/test_agentic_gate_driver.py scripts/test_post_land_smoke.py scripts/test_post_land_smoke_orchestrator.py
run redline-python python3 -m unittest tools.redline.tests.test_product_bench tools.redline.tests.test_golden tools.redline.tests.test_serve_diff tools.redline.tests.test_lower tools.redline.tests.test_dispatch_profile
run jev-python python3 -m unittest discover -s scripts/jev_eval -p 'test_*.py'
run install-python python3 scripts/test_install_revision.py
run uninstall-python python3 scripts/test_uninstall.py
run gpu-lock bash scripts/test-gpu-lock.sh
run fmt-sweep bash scripts/test-fmt-sweep-rebase.sh
run env-docs python3 scripts/check-env-docs.py
run lifecycle python3 scripts/check-lifecycle.py
run no-leaked-processes bash -c 'if leaked=$(pgrep -af "(^| )$PWD/target/[^ ]*/(hipfire|daemon)( |$)"); then echo "$leaked"; exit 1; fi'
printf 'Diagnostic continuation: %s failed stages; original CI remains FAILED.\n' "$failed"
if (( failed != 0 )); then exit 1; fi
