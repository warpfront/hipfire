#!/usr/bin/env bash
set -euo pipefail
base=/home/husrcf/Code/ProtBind/hipfireTMP
repo="$base/hipfire-mq4-step0-3"
bin=/tmp/mq4-g32-registry
out="$base/results/mq4-g32-registry-check"
mkdir "$out"
source "$repo/scripts/gpu-lock.sh"
GPU_LOCK_TIMEOUT=10 gpu_acquire mq4-g32-registry-check
export HIP_VISIBLE_DEVICES=1 LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib
export HIPFIRE_VERIFY_GRAPH=0 HIPFIRE_DN_STATE_EF=1
export HIPFIRE_GFX1100_PACKED_MQ4_PREFILL=1
for rows in 512 8193; do
  export HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=0 HIPFIRE_PREFILL_CHUNK_ROWS=512
  if [[ "$rows" == 8193 ]]; then
    export HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=1 HIPFIRE_PREFILL_CHUNK_ROWS=4096
  fi
  "$bin/mq4_prefill_state_oracle" dump \
    /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
    "$base/results/mq4-tail-final-abba/prompt.txt" "$rows" 4 "$out/$rows-packed" \
    > "$out/$rows.stdout.log" 2> "$out/$rows.stderr.log"
  "$bin/mq4_prefill_state_oracle" compare "$base/results/mq4-g32-real/$rows-packed" "$out/$rows-packed" \
    > "$out/$rows-compare.jsonl"
  python3 -c 'import json,sys; r=[json.loads(l) for l in open(sys.argv[1])]; assert len(r)==646; assert all(x["max_abs"]==0 and not x["raw_byte_mismatches"] and x["nonfinite_a"]==x["nonfinite_b"]==0 for x in r); print(sys.argv[1],"646 records exact",flush=True)' "$out/$rows-compare.jsonl"
done
python3 "$base/pp8192_native_matrix.py" "$repo" "$bin/daemon" \
  "$base/results/mq4-g32-registry-pair" 1 "$base/mq4-g32-third-pair.json"
python3 "$base/summarize_mq4_abba.py" "$base/results/mq4-g32-registry-pair" --pair
printf 'REGISTRY_GPU_CHECK_COMPLETE\n'
