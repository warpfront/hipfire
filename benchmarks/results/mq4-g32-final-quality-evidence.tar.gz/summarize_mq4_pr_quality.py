#!/usr/bin/env python3
"""Read-only audit of final G32 quality evidence. JSON output is derived."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

root = Path(sys.argv[1])
lb = root / 'mq4-g32-pr-longbench'
arms = {}
for arm in ('native', 'packed'):
    folder = lb / arm
    for name, digest in json.loads((folder / 'raw-sha256.json').read_text()).items():
        assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == digest
    rows = [json.loads(line) for line in (folder / 'results.jsonl').open()]
    assert len(rows) == 30 and len({r['ordinal'] for r in rows}) == 30
    assert all(r['done']['type'] == 'done' and r['done'].get('cached_tokens', 0) == 0 for r in rows)
    loaded = json.loads((folder / 'loaded.json').read_text())
    assert loaded['kv_backend'] == 'vmm' and not loaded['kv_backend_legacy']
    arms[arm] = rows
assert [r['ordinal'] for r in arms['native']] == [r['ordinal'] for r in arms['packed']]
lb_summary = {arm: {
    'completed': len(rows), 'correct': sum(r['correct'] for r in rows),
    'parseable': sum(r['pred'] is not None for r in rows),
    'generated_tokens': sum(r['done']['tokens'] for r in rows),
    'max_generated_tokens': max(r['done']['tokens'] for r in rows),
    'median_prefill': statistics.median(r['done']['prefill_tok_s'] for r in rows),
    'median_decode': statistics.median(r['done']['decode_tok_s'] for r in rows),
} for arm, rows in arms.items()}
lb_summary['identical_text_pairs'] = sum(
    a['prediction'] == b['prediction'] for a,b in zip(arms['native'], arms['packed']))
assert lb_summary['identical_text_pairs'] == 30

long = root / 'mq4-g32-pr-longdecode'
a = json.loads((long / 'native/results.json').read_text())
b = json.loads((long / 'combined/results.json').read_text())
assert len(a) == len(b) == 5
long_summary = []
for name, x, y in zip(('snake', 'tetris', 'story', 'kv-cache', 'radix-attention'), a, b):
    assert x['prompt_md5'] == y['prompt_md5']
    assert x['assistant_content'] == y['assistant_content']
    for row in (x,y):
        assert row['finish'] == 'stop' and not row['attractor'] and not row['empty']
        assert not row['stream_error'] and row['kv_backend'] == 'vmm' and not row['kv_backend_legacy']
    long_summary.append({'scenario':name, 'tokens': x['gen'], 'identical':True,
                         'native_decode':x['decode_tok_s'], 'packed_decode':y['decode_tok_s']})
print(json.dumps({'longbench':lb_summary, 'long_decode':long_summary,
                  'note':'Quality evidence only; these runs are not warmed timing comparisons.'}, indent=2))
