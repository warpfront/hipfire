#!/usr/bin/env python3
"""Sequential serving quality evidence, never used for kernel perf claims."""
import argparse
import json
import os
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--binary', type=Path, required=True)
p.add_argument('--cli', type=Path, required=True)
p.add_argument('--model', type=Path, required=True)
p.add_argument('--prompts', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--gpu', default='1')
p.add_argument('--max-tokens', type=int, default=1024)
p.add_argument('--max-seq', type=int, default=16384)
p.add_argument('--timeout', type=int, default=1800)
p.add_argument('--arms', nargs='+', choices=['native', 'combined'],
               default=['native', 'combined'])
p.add_argument('--mode', choices=['battery', 'chain'], default='battery')
a = p.parse_args()
if not os.environ.get('HIPFIRE_GPU_LOCK_OWNER'):
    p.error('run under gpu-lock.sh')
a.out.mkdir(parents=True, exist_ok=False)
for arm, enabled, chunk in [('native', '0', '512'), ('combined', '1', '4096')]:
    if arm not in a.arms:
        continue
    d = a.out / arm
    d.mkdir()
    env = {k: v for k, v in os.environ.items()
           if not k.startswith('HIPFIRE_') and k != 'ROCR_VISIBLE_DEVICES'}
    env.update(HIP_VISIBLE_DEVICES=a.gpu, HIPFIRE_CLI_BIN=str(a.cli),
               HIPFIRE_DAEMON_BIN=str(a.binary), HIPFIRE_VERIFY_GRAPH='0',
               HIPFIRE_GFX1100_PACKED_MQ4_PREFILL=enabled,
               HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=enabled,
               HIPFIRE_PREFILL_CHUNK_ROWS=chunk,
               HIPFIRE_KERNEL_CACHE=str(a.out / 'kernel-cache'))
    cmd = ['python3', str(a.root / 'scripts/serve_harness.py'),
           '--model', str(a.model), '--kv', 'q8', '--kv-backend', 'vmm',
           '--speculation', 'off', '--sampling', 'greedy', '--thinking', 'off',
           '--thinking-effort', 'none', '--max-seq', str(a.max_seq), '--max-tokens', str(a.max_tokens),
           '--mode', a.mode, '--prompts-file', str(a.prompts), '--port', '11893',
           '--serve-warm-timeout-secs', '600', '--home', str(d / 'home'),
           '--serve-log', str(d / 'serve.log'), '--out', str(d / 'results.json')]
    (d / 'request.json').write_text(json.dumps(dict(command=cmd, environment={
        k: v for k, v in env.items() if k.startswith(('HIP', 'LD_LIBRARY_PATH'))}), indent=2))
    with (d / 'harness.log').open('x') as log:
        subprocess.run(cmd, cwd=a.root, env=env, stdout=log,
                       stderr=subprocess.STDOUT, timeout=a.timeout, check=True)
    print(arm, 'serving battery complete; inspect text and route before judging', flush=True)
