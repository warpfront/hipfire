#!/usr/bin/env bash
set -u
root=/home/husrcf/Code/ProtBind/hipfireTMP/hipfire-mq4-step0-3
base=/home/husrcf/Code/ProtBind/hipfireTMP/hipfire-mq3-latest-repro
out=/home/husrcf/Code/ProtBind/hipfireTMP/results/mq4-g32-pr-extra-cpu
mkdir "$out" || exit 1
export CARGO_TARGET_DIR=/home/husrcf/Code/ProtBind/hipfireTMP/hipfire-packed-mq4-beta/target
export CARGO_BUILD_JOBS=4
run_check() {
    local name="$1"
    shift
    "$@" > "$out/$name.log" 2>&1
    local rc=$?
    printf '%s\t%s\n' "$name" "$rc" | tee -a "$out/status.tsv"
}
cd "$root" || exit 1
run_check product-build cargo build --release --locked -p hipfire-daemon -p hipfire-cli
run_check workspace-units-all cargo test --release --lib --workspace --locked --no-fail-fast
run_check python-suite python3 -m pytest tests scripts/test_astrea.py autoresearch/ar/tests
run_check redline-python python3 -m unittest tools.redline.tests.test_product_bench tools.redline.tests.test_golden tools.redline.tests.test_serve_diff tools.redline.tests.test_lower tools.redline.tests.test_dispatch_profile
run_check install-revision python3 scripts/test_install_revision.py
run_check uninstall python3 scripts/test_uninstall.py
run_check maps-touched python3 scripts/check-crate-maps.py --check rdna-compute hipfire-arch-qwen35
run_check diff-check git diff --check
cd "$base" || exit 1
run_check baseline-identity git rev-parse HEAD
run_check baseline-loader cargo test --release --locked -p hipfire-loader --lib explicit_unsupported_vmm_preserves_active_model
run_check baseline-example cargo check --release --locked -p saddle-lab --example kx3_foldfree_probe
run_check baseline-ratchets bash scripts/leanup-ratchets.sh
run_check baseline-env-docs python3 scripts/check-env-docs.py
run_check baseline-maps python3 scripts/check-crate-maps.py --check
printf 'EXTRA_CPU_COMPLETE\n'
