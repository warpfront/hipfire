#!/usr/bin/env bash
set -euo pipefail
cd /home/husrcf/Code/ProtBind/hipfireTMP
source hipfire-mq4-step0-3/scripts/gpu-lock.sh
GPU_LOCK_TIMEOUT=10 gpu_acquire mq4-g32-pr-quality
export LD_LIBRARY_PATH=/opt/rocm/core-10.0/lib
python3 run_mq4_g32_longbench.py \
  --binary /tmp/mq4-g32-step3/daemon \
  --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
  --dataset /home/husrcf/.hipfire/datasets/longbench-v2/longbench-hard30-pp32k.jsonl \
  --manifest /home/husrcf/.hipfire/datasets/longbench-v2/longbench-hard30-pp32k.manifest.json \
  --gpu 1 --out results/mq4-g32-pr-longbench
python3 run_mq4_serving_ab.py \
  --root /home/husrcf/Code/ProtBind/hipfireTMP/hipfire-mq4-step0-3 \
  --binary /tmp/mq4-g32-step3/daemon --cli /tmp/mq4-wide-step3/hipfire \
  --model /home/husrcf/.hipfire/models/qwen3.6-27b.mq4 \
  --prompts /home/husrcf/Code/ProtBind/hipfireTMP/mq4-long-input-battery-v2.json \
  --out /home/husrcf/Code/ProtBind/hipfireTMP/results/mq4-g32-pr-longdecode \
  --gpu 1 --max-seq 65536 --max-tokens 32768 --timeout 18000
printf 'QUALITY_CAMPAIGN_COMPLETE\n'
