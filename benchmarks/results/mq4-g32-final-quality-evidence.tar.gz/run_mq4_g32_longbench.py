#!/usr/bin/env python3
"""Frozen G32 quality A/B; append-only protocol evidence, not a perf gate."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

from longbench_hard30_eval import Daemon, load_rows, extract_choice, collect_generation_channels, sha256


class RecordedDaemon(Daemon):
    def __init__(self, binary, folder, env):
        self.raw = (folder / 'stdout.jsonl').open('x')
        self.requests = (folder / 'requests.jsonl').open('x')
        super().__init__(binary, folder / 'stderr.log', env)

    def _read(self):
        for line in self.proc.stdout:
            self.raw.write(line)
            self.raw.flush()
            try:
                self.rows.put(json.loads(line))
            except json.JSONDecodeError:
                self.rows.put({'type': 'protocol_error', 'line': line})

    def send(self, row):
        self.requests.write(json.dumps(row, ensure_ascii=False) + '\n')
        self.requests.flush()
        super().send(row)

    def close(self):
        super().close()
        self.reader.join(timeout=5)
        self.raw.close()
        self.requests.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--binary', type=Path, required=True)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--dataset', type=Path, required=True)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--gpu', default='1')
    a = p.parse_args()
    if not os.environ.get('HIPFIRE_GPU_LOCK_OWNER'):
        p.error('gpu-lock.sh required')
    rows, manifest = load_rows(a.dataset, a.manifest)
    if len(rows) != 30:
        raise ValueError('expected the complete hard30 subset')
    a.out.mkdir(parents=True, exist_ok=False)
    identity = {'binary_sha256': sha256(a.binary), 'model_sha256': sha256(a.model),
                'dataset_sha256': sha256(a.dataset), 'manifest': manifest,
                'max_seq': 65536, 'max_tokens': 32768, 'thinking': False,
                'state_quant': 'q8', 'kv_mode': 'q8', 'kv_backend': 'vmm',
                'gpu': a.gpu, 'purpose': 'quality A/B, not a warmed performance gate'}
    (a.out / 'manifest.json').write_text(json.dumps(identity, indent=2))
    for arm, flag, chunk in [('native', '0', '512'), ('packed', '1', '4096')]:
        folder = a.out / arm
        folder.mkdir()
        env = {k: v for k, v in os.environ.items()
               if not k.startswith('HIPFIRE_') and k != 'ROCR_VISIBLE_DEVICES'}
        env.update(HIP_VISIBLE_DEVICES=a.gpu, HIPFIRE_HOME=str(folder / 'home'),
                   HIPFIRE_VERIFY_GRAPH='0', HIPFIRE_GFX1100_PACKED_MQ4_PREFILL=flag,
                   HIPFIRE_GFX1100_MQ4_WIDE_PREFILL=flag,
                   HIPFIRE_PREFILL_CHUNK_ROWS=chunk,
                   HIPFIRE_KERNEL_CACHE=str(a.out / 'kernel-cache'))
        (folder / 'environment.json').write_text(json.dumps({
            k: v for k, v in env.items() if k.startswith(('HIP', 'ROCR', 'LD_LIBRARY_PATH'))}, indent=2))
        daemon = RecordedDaemon(a.binary, folder, env)
        def req(message, terminal, timeout=3600):
            done, events = daemon.request(message, terminal | {'error', 'aborted'}, timeout)
            if done['type'] in {'error', 'aborted'}:
                raise RuntimeError(done)
            return done, events
        try:
            loaded, _ = req({'type': 'load', 'model': str(a.model), 'params': {
                'max_seq': 65536, 'kv_mode': 'q8', 'kv_backend': 'vmm',
                'state_quant': 'q8', 'dflash_mode': 'off', 'mtp_mode': 'off',
                'dspark_mode': 'off', 'speculation': 'off', 'tp': 1, 'pp': 1}}, {'loaded'})
            (folder / 'loaded.json').write_text(json.dumps(loaded, indent=2))
            with (folder / 'results.jsonl').open('x') as results:
                for row in rows:
                    req({'type': 'reset', 'attempt_id': 1}, {'reset'}, 60)
                    prompt = row['prompt_no_think']
                    started = time.monotonic()
                    done, events = req({'type': 'generate', 'id': f"lb-{row['ordinal']}",
                        'attempt_id': 1, 'prompt': prompt, 'temperature': 0.0,
                        'top_p': 1.0, 'repeat_penalty': 1.1, 'max_tokens': 32768,
                        'max_think_tokens': 1, 'assistant_prefix': 'closed_think',
                        'reasoning_effort': 'none'}, {'done'})
                    channels = collect_generation_channels(events)
                    pred = extract_choice(channels['prediction'])
                    result = {'ordinal': row['ordinal'], 'gold': row['answer'],
                              'pred': pred, 'correct': pred == row['answer'].upper(),
                              'prompt_md5': hashlib.md5(prompt.encode()).hexdigest(),
                              'wall_s': time.monotonic() - started, 'done': done, **channels}
                    results.write(json.dumps(result, ensure_ascii=False) + '\n')
                    results.flush()
                    print(arm, row['ordinal'], 'answer', pred, 'correct', result['correct'],
                          'tokens', done.get('tokens'), 'PP', done.get('prefill_tok_s'),
                          'TG', done.get('decode_tok_s'), flush=True)
                    if done.get('cached_tokens', 0) != 0:
                        raise RuntimeError('unexpected prefix reuse')
        finally:
            daemon.close()
            (folder / 'raw-sha256.json').write_text(json.dumps({
                n: sha256(folder / n) for n in ['stdout.jsonl', 'stderr.log', 'requests.jsonl']}, indent=2))


if __name__ == '__main__':
    main()
