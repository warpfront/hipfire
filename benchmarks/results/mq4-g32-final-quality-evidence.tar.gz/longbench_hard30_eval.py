#!/usr/bin/env python3
"""Resumable LongBench-v2 hard-subset evaluator for the hipfire JSONL daemon."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import queue
import re
import signal
import statistics
import subprocess
import threading
import time
from collections import Counter, defaultdict
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def percentile(values: list[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = round((len(ordered) - 1) * fraction)
    return ordered[index]


def extract_choice(text: str) -> str | None:
    patterns = (
        r"the\s+correct\s+answer\s+is\s*\(?\s*([ABCD])(?![A-Za-z])\s*\)?",
        r"(?:答案|选项)\s*(?:是|为|：|:)\s*\(?\s*([ABCD])(?![A-Za-z])\s*\)?",
        r"\(([ABCD])\)",
        r"\b([ABCD])\b",
    )
    for pattern in patterns:
        matches = re.findall(pattern, text, flags=re.IGNORECASE)
        if matches:
            return matches[-1].upper()
    return None


def collect_generation_channels(events: list[dict]) -> dict:
    """Keep visible answer and hidden reasoning separate.

    Qwen emits one diagnostic reasoning frame only when the daemon was started
    with HIPFIRE_CAPTURE_REASONING=1. Other architectures may stream multiple
    ordinary reasoning frames, so concatenation is intentional.
    """
    visible_parts = [
        event.get("text", "") for event in events if event.get("type") == "token"
    ]
    if not visible_parts:
        visible_parts = [
            event.get("text", "")
            for event in events
            if event.get("type") == "committed" and isinstance(event.get("text"), str)
        ]
    reasoning_events = [event for event in events if event.get("type") == "reasoning"]
    visible = "".join(visible_parts)
    reasoning = "".join(event.get("text", "") for event in reasoning_events)
    boundaries = [
        int(event["token_boundary"])
        for event in reasoning_events
        if event.get("token_boundary") is not None
    ]
    return {
        "prediction": visible,
        "prediction_sha256": hashlib.sha256(visible.encode()).hexdigest(),
        "visible_chars": len(visible),
        "visible_event_count": len(visible_parts),
        "reasoning": reasoning,
        "reasoning_sha256": hashlib.sha256(reasoning.encode()).hexdigest(),
        "reasoning_chars": len(reasoning),
        "reasoning_event_count": len(reasoning_events),
        # Includes the token that completes </think>; this is an exact stream
        # boundary, not a claim that every token belonged to reasoning text.
        "reasoning_token_boundary": boundaries[-1] if boundaries else None,
    }


class Daemon:
    def __init__(self, binary: Path, stderr_path: Path, env: dict[str, str]):
        self.stderr_file = stderr_path.open("w", buffering=1)
        self.proc = subprocess.Popen(
            [str(binary)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=self.stderr_file,
            text=True,
            bufsize=1,
            env=env,
            start_new_session=True,
        )
        assert self.proc.stdin is not None
        assert self.proc.stdout is not None
        self.rows: queue.Queue[dict] = queue.Queue()
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()

    def _read(self) -> None:
        assert self.proc.stdout is not None
        for line in self.proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                self.rows.put(json.loads(line))
            except json.JSONDecodeError:
                self.rows.put({"type": "protocol_error", "line": line})

    def send(self, row: dict) -> None:
        if self.proc.poll() is not None:
            raise RuntimeError(f"daemon exited with code {self.proc.returncode}")
        assert self.proc.stdin is not None
        self.proc.stdin.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
        self.proc.stdin.flush()

    def wait(self, terminal: set[str], timeout: float) -> tuple[dict, list[dict]]:
        deadline = time.monotonic() + timeout
        events: list[dict] = []
        while time.monotonic() < deadline:
            try:
                event = self.rows.get(timeout=min(1.0, max(0.01, deadline - time.monotonic())))
            except queue.Empty:
                if self.proc.poll() is not None:
                    break
                continue
            events.append(event)
            if event.get("type") == "commit_ready":
                self.send({
                    "type": "commit",
                    "id": event.get("id"),
                    "attempt_id": event.get("attempt_id"),
                })
                continue
            if event.get("type") in terminal:
                return event, events
        raise TimeoutError(
            f"daemon timeout/exited waiting for {sorted(terminal)}; "
            f"rc={self.proc.poll()} last={events[-5:]}"
        )

    def request(self, row: dict, terminal: set[str], timeout: float) -> tuple[dict, list[dict]]:
        self.send(row)
        return self.wait(terminal, timeout)

    def close(self) -> None:
        try:
            if self.proc.poll() is None:
                self.send({"type": "unload"})
                self.wait({"unloaded", "error"}, 120)
        except Exception:
            pass
        try:
            if self.proc.stdin:
                self.proc.stdin.close()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(self.proc.pid, signal.SIGTERM)
            self.proc.wait(timeout=10)
        self.stderr_file.close()


def load_rows(dataset: Path, manifest_path: Path) -> tuple[list[dict], dict]:
    manifest = json.loads(manifest_path.read_text())
    actual_sha = sha256(dataset)
    expected_sha = manifest.get("sample_sha256")
    if expected_sha and actual_sha != expected_sha:
        raise ValueError(f"dataset SHA-256 mismatch: {actual_sha} != {expected_sha}")
    # JSON strings may legally contain Unicode line/paragraph separators.  Python's
    # splitlines() treats those characters as record boundaries even though the
    # dataset writer only delimits records with ASCII LF.
    rows = [json.loads(line) for line in dataset.read_text().split("\n") if line.strip()]
    if len(rows) != manifest.get("sample_count", len(rows)):
        raise ValueError("dataset row count does not match manifest")
    for row in rows:
        prompt = row["prompt_no_think"]
        expected_md5 = row.get("prompt_no_think_md5")
        if expected_md5 and hashlib.md5(prompt.encode()).hexdigest() != expected_md5:
            raise ValueError(f"prompt MD5 mismatch for ordinal {row.get('ordinal')}")
    return rows, manifest


def make_summary(results: list[dict], config: dict) -> dict:
    valid = [row for row in results if not row.get("error")]
    correct = [row for row in valid if row.get("correct")]
    by_domain: dict[str, dict] = {}
    grouped: defaultdict[str, list[dict]] = defaultdict(list)
    for row in valid:
        grouped[row["domain"]].append(row)
    for domain, rows in sorted(grouped.items()):
        hits = sum(bool(row.get("correct")) for row in rows)
        by_domain[domain] = {"n": len(rows), "correct": hits, "accuracy": hits / len(rows)}

    def stats(key: str) -> dict:
        values = [float(row[key]) for row in valid if row.get(key) is not None]
        return {
            "n": len(values),
            "min": min(values) if values else None,
            "median": statistics.median(values) if values else None,
            "p90": percentile(values, 0.90),
            "max": max(values) if values else None,
        }

    return {
        "completed": len(results),
        "valid": len(valid),
        "errors": len(results) - len(valid),
        "correct": len(correct),
        "accuracy": len(correct) / len(valid) if valid else None,
        "prediction_counts": dict(sorted(Counter(row.get("pred") or "INVALID" for row in valid).items())),
        "by_domain": by_domain,
        "prefill_tokens": stats("prefill_tokens"),
        "prefill_tok_s": stats("prefill_tok_s"),
        "prefill_ms": stats("prefill_ms"),
        "decode_tok_s": stats("decode_tok_s"),
        "reasoning_chars": stats("reasoning_chars"),
        "reasoning_token_boundary": stats("reasoning_token_boundary"),
        "post_reasoning_tokens": stats("post_reasoning_tokens"),
        "visible_chars": stats("visible_chars"),
        "ttft_ms": stats("ttft_ms"),
        "wall_s": stats("wall_s"),
        "config": config,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--daemon", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--draft", type=Path)
    parser.add_argument("--sidecar", type=Path)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--physical-gpu", default="0")
    parser.add_argument("--max-seq", type=int, default=32768)
    parser.add_argument("--kv-mode", default="q8")
    parser.add_argument("--physical-cap", type=int, default=2048)
    parser.add_argument("--budget", type=int, default=2048)
    parser.add_argument("--beta", type=int, default=128)
    parser.add_argument("--handoff-tokens", type=int, default=8192)
    parser.add_argument("--adaptive", default="balanced")
    parser.add_argument(
        "--mode", choices=("baseline", "adaptive", "staged"), default="staged"
    )
    parser.add_argument("--state-quant", default="fp32")
    parser.add_argument(
        "--retain-policy",
        choices=("triattn", "recent", "recent-after-score"),
        default="triattn",
    )
    parser.add_argument("--max-tokens", type=int, default=64)
    parser.add_argument("--thinking", action="store_true")
    parser.add_argument("--max-think-tokens", type=int, default=768)
    parser.add_argument(
        "--speculation", choices=("off", "dflash", "dspark"), default="off"
    )
    parser.add_argument(
        "--dflash-adaptive-b", action=argparse.BooleanOptionalAction, default=True
    )
    parser.add_argument("--timeout", type=float, default=1800)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument(
        "--ordinals",
        help="comma-separated dataset ordinals to run (applied before --limit)",
    )
    args = parser.parse_args()

    rows, manifest = load_rows(args.dataset, args.manifest)
    if args.ordinals:
        wanted = {int(value) for value in args.ordinals.split(",")}
        rows = [row for row in rows if int(row["ordinal"]) in wanted]
        found = {int(row["ordinal"]) for row in rows}
        if missing := sorted(wanted - found):
            parser.error(f"unknown dataset ordinals: {missing}")
    if args.limit:
        rows = rows[: args.limit]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    results_path = args.out_dir / "results.jsonl"
    summary_path = args.out_dir / "summary.json"
    config_path = args.out_dir / "config.json"

    existing: list[dict] = []
    if results_path.exists():
        existing = [json.loads(line) for line in results_path.read_text().split("\n") if line.strip()]
        # Re-evaluate stored text with the current parser so a resumed run does
        # not preserve an older scorer bug (the raw prediction is authoritative).
        for result in existing:
            if not result.get("error") and "prediction" in result:
                result["pred"] = extract_choice(result["prediction"])
                result["correct"] = result["pred"] == str(result.get("gold", "")).upper()
        results_path.write_text(
            "".join(json.dumps(result, ensure_ascii=False) + "\n" for result in existing)
        )
    completed = {int(row["ordinal"]) for row in existing if not row.get("error")}

    if args.mode == "staged" and args.sidecar is None:
        parser.error("--sidecar is required in staged mode")
    if args.speculation == "dflash" and args.draft is None:
        parser.error("--draft is required with --speculation dflash")
    load_params = {
        "max_seq": args.max_seq,
        "kv_mode": args.kv_mode,
        "kv_backend": "vmm",
        "kv_adaptive": args.adaptive if args.mode != "baseline" else "off",
        "state_quant": args.state_quant,
        "dflash_mode": "auto" if args.speculation == "dflash" else "off",
        "mtp_mode": "off",
        "dspark_mode": "on" if args.speculation == "dspark" else "off",
        "tp": 1,
        "pp": 1,
    }
    if args.mode == "staged":
        load_params.update({
            "cask": False,
            "cask_sidecar": str(args.sidecar),
            "cask_budget": args.budget,
            "cask_beta": args.beta,
            "cask_handoff_tokens": args.handoff_tokens,
            "cask_retain_policy": args.retain_policy,
        })
    if args.speculation == "dflash":
        load_params["draft"] = str(args.draft)
        load_params["dflash_adaptive_b"] = args.dflash_adaptive_b
    config = {
        "dataset": str(args.dataset),
        "dataset_sha256": sha256(args.dataset),
        "manifest": str(args.manifest),
        "manifest_sha256": sha256(args.manifest),
        "manifest_content": manifest,
        "daemon": str(args.daemon),
        "model": str(args.model),
        "model_sha256": sha256(args.model),
        "draft": str(args.draft) if args.draft else None,
        "draft_sha256": sha256(args.draft) if args.draft else None,
        "mode": args.mode,
        "sidecar": str(args.sidecar) if args.sidecar else None,
        "sidecar_sha256": sha256(args.sidecar) if args.sidecar else None,
        "physical_gpu": args.physical_gpu,
        "load_params": load_params,
        "generation": {
            "temperature": 0.0,
            "top_p": 1.0,
            "repeat_penalty": 1.0,
            "max_tokens": args.max_tokens,
            "max_think_tokens": args.max_think_tokens if args.thinking else 1,
            "assistant_prefix": "open_think" if args.thinking else "closed_think",
        },
    }
    config_path.write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n")

    env = os.environ.copy()
    env.update({
        "ROCR_VISIBLE_DEVICES": str(args.physical_gpu),
        "HIP_VISIBLE_DEVICES": "0",
        "HIPFIRE_KV_PHYSICAL_CAP": str(args.physical_cap),
        "HIPFIRE_KV_ADAPTIVE": "off",
        "HIPFIRE_DFLASH_DRAFT": str(args.draft) if args.speculation == "dflash" else "",
        "HIPFIRE_CAPTURE_REASONING": "1" if args.thinking else "0",
    })
    daemon = Daemon(args.daemon, args.out_dir / "daemon.stderr.log", env)
    all_results = list(existing)
    try:
        loaded, _ = daemon.request(
            {"type": "load", "model": str(args.model), "params": config["load_params"]},
            {"loaded", "error"},
            args.timeout,
        )
        if loaded.get("type") != "loaded":
            raise RuntimeError(f"load failed: {loaded}")

        # Warm compilation and the decode path without consuming a dataset row.
        daemon.request({"type": "reset", "attempt_id": 1}, {"reset", "error"}, 60)
        warm_done, _ = daemon.request(
            {
                "type": "generate", "id": "warmup", "attempt_id": 0,
                "prompt": "Hello", **config["generation"], "max_tokens": 8,
                "max_think_tokens": 1, "assistant_prefix": "closed_think",
            },
            {"done", "error", "aborted"},
            args.timeout,
        )
        if warm_done.get("type") != "done":
            raise RuntimeError(f"warmup failed: {warm_done}")

        for row in rows:
            ordinal = int(row["ordinal"])
            if ordinal in completed:
                continue
            reset, _ = daemon.request(
                {"type": "reset", "attempt_id": ordinal + 2}, {"reset", "error"}, 60
            )
            if reset.get("type") == "error":
                raise RuntimeError(f"reset failed before ordinal {ordinal}: {reset}")
            request = {
                "type": "generate",
                "id": f"longbench-{ordinal:02d}",
                "attempt_id": ordinal + 1,
                "prompt": row["prompt_think" if args.thinking else "prompt_no_think"],
                **config["generation"],
            }
            started = time.monotonic()
            try:
                done, events = daemon.request(
                    request, {"done", "error", "aborted"}, args.timeout
                )
                wall_s = time.monotonic() - started
                channels = collect_generation_channels(events)
                prediction = channels["prediction"]
                result = {
                    "ordinal": ordinal,
                    "id": row.get("_id"),
                    "domain": row.get("domain"),
                    "sub_domain": row.get("sub_domain"),
                    "difficulty": row.get("difficulty"),
                    "raw_tokens_no_think": row.get("raw_tokens_no_think"),
                    "gold": str(row.get("answer", "")).upper(),
                    "pred": extract_choice(prediction),
                    **channels,
                    "correct": extract_choice(prediction) == str(row.get("answer", "")).upper(),
                    "wall_s": wall_s,
                    **{key: done.get(key) for key in (
                        "type", "finish_reason", "tokens", "tok_s", "prefill_tokens",
                        "prefill_ms", "prefill_tok_s", "decode_tok_s", "ttft_ms", "cached_tokens",
                    )},
                }
                boundary = result.get("reasoning_token_boundary")
                total_tokens = result.get("tokens")
                result["post_reasoning_tokens"] = (
                    int(total_tokens) - int(boundary)
                    if boundary is not None and total_tokens is not None
                    else None
                )
                if done.get("type") != "done":
                    result["error"] = done
            except Exception as exc:
                result = {
                    "ordinal": ordinal,
                    "id": row.get("_id"),
                    "domain": row.get("domain"),
                    "gold": str(row.get("answer", "")).upper(),
                    "error": repr(exc),
                    "wall_s": time.monotonic() - started,
                }
            with results_path.open("a") as output:
                output.write(json.dumps(result, ensure_ascii=False) + "\n")
            all_results.append(result)
            summary_path.write_text(json.dumps(make_summary(all_results, config), indent=2, ensure_ascii=False) + "\n")
            print(
                f"[{len(all_results):02d}/{len(rows):02d}] ordinal={ordinal} "
                f"gold={result.get('gold')} pred={result.get('pred')} "
                f"prefill={result.get('prefill_tok_s')} tok/s "
                f"decode={result.get('decode_tok_s')} tok/s correct={result.get('correct')}",
                flush=True,
            )
    finally:
        daemon.close()

    final_summary = make_summary(all_results, config)
    summary_path.write_text(json.dumps(final_summary, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(final_summary, indent=2, ensure_ascii=False))
    return 0 if final_summary["errors"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
