#!/usr/bin/env python3
"""Read-only ABBA audit; stdout is derived evidence, never rewritten raw logs."""
import hashlib
import json
from pathlib import Path
import re
import statistics
import sys

root = Path(sys.argv[1])
manifest = json.loads((root / 'manifest.json').read_text())
cases = manifest['campaign']['cases']
paired = '--pair' in sys.argv[2:]
if paired:
    assert len(cases) == 2, 'expected one explicitly requested pair'
    assert {c['name'] for c in cases} == {'native512', 'packed4096'}
else:
    assert len(cases) == 4, 'expected ABBA'
    assert cases[0] == cases[3] and cases[1] == cases[2], 'not ABBA'
arms = []
for i, case in enumerate(cases):
    folder = root / f"{i:02}-{case['name']}"
    for name, expected in json.loads((folder / 'raw-sha256.json').read_text()).items():
        assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == expected, name
    measurement = json.loads((folder / 'measurement.json').read_text())
    events = [json.loads(line) for line in (folder / 'stdout.jsonl').read_text().splitlines()
              if line.startswith('{')]
    done = [e for e in events if e.get('id') == 'measure' and e.get('type') == 'done']
    assert done == [measurement], 'derived measurement differs from raw'
    assert measurement['prefill_tokens'] == manifest['pp']
    assert measurement['cached_tokens'] == 0
    text = ''.join(e.get('text', '') for e in events
                   if e.get('id') == 'measure' and e.get('type') == 'token')
    receipt = re.findall(r'prefill_chunk: requested=(\d+) admitted=(\d+) commit_stride=(\w+)',
                         (folder / 'stderr.log').read_text())
    assert receipt, 'missing execution receipt'
    if case.get('expected_packed'):
        log = (folder / 'stderr.log').read_text()
        for epilogue in ('false', 'true'):
            assert re.search(r'\[packed-mq4\] admitted format=mq4 .*add=' + epilogue, log), 'missing packed route'
    if 'expected_admitted' in case:
        assert int(receipt[-1][1]) == case['expected_admitted']
        if case['expected_admitted'] > 512:
            assert receipt[-1][2] == '512'
    telemetry = folder / 'telemetry.jsonl'
    peak = max((json.loads(l).get('mem_info_vram_used') or 0
                for l in telemetry.read_text().splitlines()), default=0) if telemetry.exists() else None
    arms.append(dict(name=folder.name, prefill=measurement['prefill_tok_s'],
                     decode=measurement['decode_tok_s'], tokens=measurement['tokens'],
                     text_sha256=hashlib.sha256(text.encode()).hexdigest(),
                     receipt=receipt[-1], sampled_peak_vram=peak))

def means(key):
    ai = [i for i,c in enumerate(cases) if c['name'] == 'native512'] if paired else (0, 3)
    bi = [i for i,c in enumerate(cases) if c['name'] == 'packed4096'] if paired else (1, 2)
    a = statistics.mean(arms[i][key] for i in ai)
    b = statistics.mean(arms[i][key] for i in bi)
    return dict(baseline=a, candidate=b, change_percent=(b / a - 1) * 100)

same_length = len({arm['tokens'] for arm in arms}) == 1
print(json.dumps(dict(source=str(root), arms=arms, prefill=means('prefill'),
                      decode=means('decode') if same_length else None,
                      matched_decode_lengths=same_length,
                      identical_measured_text=len({arm['text_sha256'] for arm in arms}) == 1,
                      caveat=('One prompt, one measurement per arm; supplemental pair only.' if paired
                              else 'One prompt, two measurements per arm; not a broad quality gate.')), indent=2))
