#!/usr/bin/env bash
set -u
cd /home/husrcf/Code/ProtBind/hipfireTMP/hipfire-mq4-step0-3
export CARGO_TARGET_DIR=/home/husrcf/Code/ProtBind/hipfireTMP/hipfire-packed-mq4-beta/target
export CARGO_BUILD_JOBS=4
out=/home/husrcf/Code/ProtBind/hipfireTMP/results/mq4-g32-pr-cpu
mkdir "$out" || exit 1
run_check() {
    local name="$1"
    shift
    "$@" > "$out/$name.log" 2>&1
    local rc=$?
    printf '%s\t%s\n' "$name" "$rc" | tee -a "$out/status.tsv"
}
run_check build cargo build --release --workspace --all-targets --locked
run_check unit cargo test --release --lib --workspace --locked
run_check ratchets bash scripts/leanup-ratchets.sh
run_check crate-maps python3 scripts/check-crate-maps.py --check
run_check ratchet-diff bash scripts/ratchet-diff.sh origin/beta
run_check env-docs python3 scripts/check-env-docs.py
run_check whitespace git diff --check origin/beta...HEAD
printf 'CPU_CHECKS_COMPLETE\n'
